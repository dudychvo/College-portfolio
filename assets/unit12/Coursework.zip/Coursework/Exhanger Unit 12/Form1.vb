﻿Public Class Form1
    Dim tries As Integer = 3
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        'Declarate the variables for username and password
        Dim username As String = txtNameField.Text
        Dim password As String = txtPasswordField.Text
        If username = "" And password = "" Then
            'Check if the username and password aren't empty, if yes show message box with an error
            MsgBox("Please enter username and password in the fields")
        ElseIf (username <> "21vdudych" Or password <> "Ukraine2456#1") Then
            'Check if the username and password are incorrect, if yes show message box with an error
            MsgBox("Either username or password was incorrect")
            'Messagebox with an error
            txtNameField.Clear()
            txtPasswordField.Clear()
            txtNameField.Focus()
            tries = tries - 1
            txtAttempts.Text = "Attempts: " & tries
        ElseIf (username = "21vdudych" And password = "Ukraine2456#1") Then
            'Check if the username and password are correct, if yes show main program
            Form2.Show()
            Me.Hide()
        End If

        Do Until tries > 0
            'Loop for the users attemps. When attemps is 0, then messagebox appear and the whole progrma closes
            txtAttempts.Text = "Attempts: 0"
            MsgBox("Please, try again later")
            Application.Exit()
            End

        Loop
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles pcbLock.Click
        'Change the passwordChar for txtPasswordField and the picture if use.systemPasswordChar is false
        If (txtPasswordField.UseSystemPasswordChar = False) Then
            txtPasswordField.UseSystemPasswordChar = True
            pcbLock.Image = My.Resources.unlocking
        Else
            'Change the passwordChar for txtPasswordField and the picture if use.systemPasswordChar is true
            txtPasswordField.UseSystemPasswordChar = False
            pcbLock.Image = My.Resources.locking
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Test button
        txtNameField.Text = "21vdudych"
        txtPasswordField.Text = "Ukraine2456#1"
    End Sub
End Class
