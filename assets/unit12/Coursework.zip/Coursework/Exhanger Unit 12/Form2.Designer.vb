﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.lblTitleForMain = New System.Windows.Forms.Label()
        Me.lblFrom = New System.Windows.Forms.Label()
        Me.lblTo = New System.Windows.Forms.Label()
        Me.cboCurrencyFrom = New System.Windows.Forms.ComboBox()
        Me.cboCurrencyTo = New System.Windows.Forms.ComboBox()
        Me.btnRates = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnConvert = New System.Windows.Forms.Button()
        Me.btnFAQ = New System.Windows.Forms.Button()
        Me.txtConvertFrom = New System.Windows.Forms.TextBox()
        Me.txtConvertTo = New System.Windows.Forms.TextBox()
        Me.pnlRates = New System.Windows.Forms.Panel()
        Me.lblBRL = New System.Windows.Forms.Label()
        Me.lblBGN = New System.Windows.Forms.Label()
        Me.lblTRY = New System.Windows.Forms.Label()
        Me.lblPLN = New System.Windows.Forms.Label()
        Me.lblMDL = New System.Windows.Forms.Label()
        Me.lblUAH = New System.Windows.Forms.Label()
        Me.lblEUR = New System.Windows.Forms.Label()
        Me.lblCAD = New System.Windows.Forms.Label()
        Me.lblUSD = New System.Windows.Forms.Label()
        Me.lblGBP = New System.Windows.Forms.Label()
        Me.pcbBRL2 = New System.Windows.Forms.PictureBox()
        Me.pcbBRL1 = New System.Windows.Forms.PictureBox()
        Me.pcbTRY2 = New System.Windows.Forms.PictureBox()
        Me.pcbBGN2 = New System.Windows.Forms.PictureBox()
        Me.pcbBGN1 = New System.Windows.Forms.PictureBox()
        Me.txtBRLtoBRL = New System.Windows.Forms.TextBox()
        Me.txtBGNtoBRL = New System.Windows.Forms.TextBox()
        Me.txtTRYtoBRL = New System.Windows.Forms.TextBox()
        Me.txtPLNtoBRL = New System.Windows.Forms.TextBox()
        Me.txtMDLtoBRL = New System.Windows.Forms.TextBox()
        Me.txtUAHtoBRL = New System.Windows.Forms.TextBox()
        Me.txtEURtoBRL = New System.Windows.Forms.TextBox()
        Me.txtCADtoBRL = New System.Windows.Forms.TextBox()
        Me.txtUSDtoBRL = New System.Windows.Forms.TextBox()
        Me.txtGBRtoBRL = New System.Windows.Forms.TextBox()
        Me.pcbTRY1 = New System.Windows.Forms.PictureBox()
        Me.pcbPLN2 = New System.Windows.Forms.PictureBox()
        Me.pcbPLN1 = New System.Windows.Forms.PictureBox()
        Me.pcbMDL2 = New System.Windows.Forms.PictureBox()
        Me.pcbMDL1 = New System.Windows.Forms.PictureBox()
        Me.pcbUAH2 = New System.Windows.Forms.PictureBox()
        Me.pcbUAH1 = New System.Windows.Forms.PictureBox()
        Me.pcbCAD2 = New System.Windows.Forms.PictureBox()
        Me.pcbCAD1 = New System.Windows.Forms.PictureBox()
        Me.pcbUSD2 = New System.Windows.Forms.PictureBox()
        Me.pcbUSD1 = New System.Windows.Forms.PictureBox()
        Me.txtBRLtoBGN = New System.Windows.Forms.TextBox()
        Me.txtBRLtoTRY = New System.Windows.Forms.TextBox()
        Me.txtBRLtoPLN = New System.Windows.Forms.TextBox()
        Me.txtBRLtoMDL = New System.Windows.Forms.TextBox()
        Me.txtBRLtoUAH = New System.Windows.Forms.TextBox()
        Me.txtBRLtoEUR = New System.Windows.Forms.TextBox()
        Me.txtBRLtoCAD = New System.Windows.Forms.TextBox()
        Me.txtBRLtoUSD = New System.Windows.Forms.TextBox()
        Me.txtBGNtoBGN = New System.Windows.Forms.TextBox()
        Me.txtBGNtoTRY = New System.Windows.Forms.TextBox()
        Me.txtBGNtoPLN = New System.Windows.Forms.TextBox()
        Me.txtBGNtoMDL = New System.Windows.Forms.TextBox()
        Me.txtBGNtoUAH = New System.Windows.Forms.TextBox()
        Me.txtBGNtoEUR = New System.Windows.Forms.TextBox()
        Me.txtBGNtoCAD = New System.Windows.Forms.TextBox()
        Me.txtBGNtoUSD = New System.Windows.Forms.TextBox()
        Me.txtTRYtoBGN = New System.Windows.Forms.TextBox()
        Me.txtTRYtoTRY = New System.Windows.Forms.TextBox()
        Me.txtTRYtoPLN = New System.Windows.Forms.TextBox()
        Me.txtTRYtoMDL = New System.Windows.Forms.TextBox()
        Me.txtTRYtoUAH = New System.Windows.Forms.TextBox()
        Me.txtTRYtoEUR = New System.Windows.Forms.TextBox()
        Me.txtTRYtoCAD = New System.Windows.Forms.TextBox()
        Me.txtTRYtoUSD = New System.Windows.Forms.TextBox()
        Me.txtPLNtoBGN = New System.Windows.Forms.TextBox()
        Me.txtPLNtoTRY = New System.Windows.Forms.TextBox()
        Me.txtPLNtoPLN = New System.Windows.Forms.TextBox()
        Me.txtPLNtoMDL = New System.Windows.Forms.TextBox()
        Me.txtPLNtoUAH = New System.Windows.Forms.TextBox()
        Me.txtPLNtoEUR = New System.Windows.Forms.TextBox()
        Me.txtPLNtoCAD = New System.Windows.Forms.TextBox()
        Me.txtPLNtoUSD = New System.Windows.Forms.TextBox()
        Me.txtMDLtoBGN = New System.Windows.Forms.TextBox()
        Me.txtMDLtoTRY = New System.Windows.Forms.TextBox()
        Me.txtMDLtoPLN = New System.Windows.Forms.TextBox()
        Me.txtMDLtoMDL = New System.Windows.Forms.TextBox()
        Me.txtMDLtoUAH = New System.Windows.Forms.TextBox()
        Me.txtMDLtoEUR = New System.Windows.Forms.TextBox()
        Me.txtMDLtoCAD = New System.Windows.Forms.TextBox()
        Me.txtMDLtoUSD = New System.Windows.Forms.TextBox()
        Me.txtUAHtoBGN = New System.Windows.Forms.TextBox()
        Me.txtUAHtoTRY = New System.Windows.Forms.TextBox()
        Me.txtUAHtoPLN = New System.Windows.Forms.TextBox()
        Me.txtUAHtoMDL = New System.Windows.Forms.TextBox()
        Me.txtUAHtoUAH = New System.Windows.Forms.TextBox()
        Me.txtUAHtoEUR = New System.Windows.Forms.TextBox()
        Me.txtUAHtoCAD = New System.Windows.Forms.TextBox()
        Me.txtUAHtoUSD = New System.Windows.Forms.TextBox()
        Me.txtEURtoBGN = New System.Windows.Forms.TextBox()
        Me.txtEURtoTRY = New System.Windows.Forms.TextBox()
        Me.txtEURtoPLN = New System.Windows.Forms.TextBox()
        Me.txtEURtoMDL = New System.Windows.Forms.TextBox()
        Me.txtEURtoUAH = New System.Windows.Forms.TextBox()
        Me.txtEURtoEUR = New System.Windows.Forms.TextBox()
        Me.txtEURtoCAD = New System.Windows.Forms.TextBox()
        Me.txtEURtoUSD = New System.Windows.Forms.TextBox()
        Me.txtCADtoBGN = New System.Windows.Forms.TextBox()
        Me.txtCADtoTRY = New System.Windows.Forms.TextBox()
        Me.txtCADtoPLN = New System.Windows.Forms.TextBox()
        Me.txtCADtoMDL = New System.Windows.Forms.TextBox()
        Me.txtCADtoUAH = New System.Windows.Forms.TextBox()
        Me.txtCADtoEUR = New System.Windows.Forms.TextBox()
        Me.txtUSDtoBGN = New System.Windows.Forms.TextBox()
        Me.txtUSDtoTRY = New System.Windows.Forms.TextBox()
        Me.txtUSDtoPLN = New System.Windows.Forms.TextBox()
        Me.txtUSDtoMDL = New System.Windows.Forms.TextBox()
        Me.txtUSDtoUAH = New System.Windows.Forms.TextBox()
        Me.txtUSDtoEUR = New System.Windows.Forms.TextBox()
        Me.txtBRLtoGBR = New System.Windows.Forms.TextBox()
        Me.txtBGNtoGBR = New System.Windows.Forms.TextBox()
        Me.txtTRYtoGBR = New System.Windows.Forms.TextBox()
        Me.txtPLNtoGBR = New System.Windows.Forms.TextBox()
        Me.txtMDLtoGBR = New System.Windows.Forms.TextBox()
        Me.txtUAHtoGBR = New System.Windows.Forms.TextBox()
        Me.pcbEUR2 = New System.Windows.Forms.PictureBox()
        Me.pcbEUR1 = New System.Windows.Forms.PictureBox()
        Me.pcbGBR2 = New System.Windows.Forms.PictureBox()
        Me.pcbGBR1 = New System.Windows.Forms.PictureBox()
        Me.txtGBRtoBGN = New System.Windows.Forms.TextBox()
        Me.txtGBRtoTRY = New System.Windows.Forms.TextBox()
        Me.txtGBPtoPLN = New System.Windows.Forms.TextBox()
        Me.txtGBPtoMDL = New System.Windows.Forms.TextBox()
        Me.txtGBPtoUAH = New System.Windows.Forms.TextBox()
        Me.txtGBPtoEUR = New System.Windows.Forms.TextBox()
        Me.txtEURtoGBR = New System.Windows.Forms.TextBox()
        Me.btnCloseRate = New System.Windows.Forms.Button()
        Me.txtCADtoCAD = New System.Windows.Forms.TextBox()
        Me.txtCADtoUSD = New System.Windows.Forms.TextBox()
        Me.txtCADtoGBR = New System.Windows.Forms.TextBox()
        Me.txtUSDtoCAD = New System.Windows.Forms.TextBox()
        Me.txtUSDtoUSD = New System.Windows.Forms.TextBox()
        Me.txtUSDtoGBR = New System.Windows.Forms.TextBox()
        Me.txtGBPtoCAD = New System.Windows.Forms.TextBox()
        Me.txtGBPtoUSD = New System.Windows.Forms.TextBox()
        Me.txtGBPtoGBR = New System.Windows.Forms.TextBox()
        Me.pnlFAQ = New System.Windows.Forms.Panel()
        Me.txtCountriesCurrencies = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtTextForFAQ = New System.Windows.Forms.TextBox()
        Me.lblTextToFAQ = New System.Windows.Forms.Label()
        Me.btnCloseFAQ = New System.Windows.Forms.Button()
        Me.pcbCurrencyFrom = New System.Windows.Forms.PictureBox()
        Me.pcbCurrencyTo = New System.Windows.Forms.PictureBox()
        Me.pcbLogoExchanger = New System.Windows.Forms.PictureBox()
        Me.pnlRates.SuspendLayout()
        CType(Me.pcbBRL2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbBRL1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbTRY2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbBGN2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbBGN1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbTRY1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbPLN2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbPLN1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbMDL2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbMDL1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbUAH2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbUAH1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbCAD2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbCAD1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbUSD2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbUSD1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbEUR2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbEUR1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbGBR2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbGBR1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlFAQ.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbCurrencyFrom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbCurrencyTo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbLogoExchanger, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTitleForMain
        '
        Me.lblTitleForMain.AutoSize = True
        Me.lblTitleForMain.Font = New System.Drawing.Font("Nirmala UI", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitleForMain.Location = New System.Drawing.Point(291, 9)
        Me.lblTitleForMain.Name = "lblTitleForMain"
        Me.lblTitleForMain.Size = New System.Drawing.Size(349, 86)
        Me.lblTitleForMain.TabIndex = 1
        Me.lblTitleForMain.Text = "Exchanger"
        '
        'lblFrom
        '
        Me.lblFrom.AutoSize = True
        Me.lblFrom.Font = New System.Drawing.Font("Nirmala UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFrom.Location = New System.Drawing.Point(97, 156)
        Me.lblFrom.Name = "lblFrom"
        Me.lblFrom.Size = New System.Drawing.Size(144, 65)
        Me.lblFrom.TabIndex = 2
        Me.lblFrom.Text = "From"
        '
        'lblTo
        '
        Me.lblTo.AutoSize = True
        Me.lblTo.Font = New System.Drawing.Font("Nirmala UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTo.Location = New System.Drawing.Point(121, 308)
        Me.lblTo.Name = "lblTo"
        Me.lblTo.Size = New System.Drawing.Size(80, 65)
        Me.lblTo.TabIndex = 3
        Me.lblTo.Text = "To"
        '
        'cboCurrencyFrom
        '
        Me.cboCurrencyFrom.AutoCompleteCustomSource.AddRange(New String() {"1"})
        Me.cboCurrencyFrom.BackColor = System.Drawing.SystemColors.HighlightText
        Me.cboCurrencyFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCurrencyFrom.Font = New System.Drawing.Font("Nirmala UI", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCurrencyFrom.FormattingEnabled = True
        Me.cboCurrencyFrom.Items.AddRange(New Object() {"GBP - £", "USD - $", "CAD - C$", "EUR - €", "UAH - ₴", "MDL - L", "PLN - zł", "TRY - ₺", "BGN - Лв.", "BRL - R$"})
        Me.cboCurrencyFrom.Location = New System.Drawing.Point(358, 168)
        Me.cboCurrencyFrom.Name = "cboCurrencyFrom"
        Me.cboCurrencyFrom.Size = New System.Drawing.Size(169, 53)
        Me.cboCurrencyFrom.TabIndex = 4
        '
        'cboCurrencyTo
        '
        Me.cboCurrencyTo.AutoCompleteCustomSource.AddRange(New String() {"2"})
        Me.cboCurrencyTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCurrencyTo.Font = New System.Drawing.Font("Nirmala UI", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCurrencyTo.FormattingEnabled = True
        Me.cboCurrencyTo.Items.AddRange(New Object() {"GBP - £", "USD - $", "CAD - C$", "EUR - €", "UAH - ₴", "MDL - L", "PLN - zł", "TRY - ₺", "BGN - Лв.", "BRL - R$"})
        Me.cboCurrencyTo.Location = New System.Drawing.Point(358, 321)
        Me.cboCurrencyTo.Name = "cboCurrencyTo"
        Me.cboCurrencyTo.Size = New System.Drawing.Size(169, 53)
        Me.cboCurrencyTo.TabIndex = 5
        '
        'btnRates
        '
        Me.btnRates.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnRates.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRates.Font = New System.Drawing.Font("Nirmala UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRates.Location = New System.Drawing.Point(649, 433)
        Me.btnRates.Name = "btnRates"
        Me.btnRates.Size = New System.Drawing.Size(152, 71)
        Me.btnRates.TabIndex = 6
        Me.btnRates.Text = "Rates"
        Me.btnRates.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.Font = New System.Drawing.Font("Nirmala UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(87, 433)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(171, 71)
        Me.btnClear.TabIndex = 7
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnConvert
        '
        Me.btnConvert.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnConvert.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnConvert.Font = New System.Drawing.Font("Nirmala UI", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConvert.Location = New System.Drawing.Point(286, 462)
        Me.btnConvert.Name = "btnConvert"
        Me.btnConvert.Size = New System.Drawing.Size(322, 95)
        Me.btnConvert.TabIndex = 8
        Me.btnConvert.Text = "Convert"
        Me.btnConvert.UseVisualStyleBackColor = False
        '
        'btnFAQ
        '
        Me.btnFAQ.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnFAQ.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFAQ.Font = New System.Drawing.Font("Nirmala UI", 28.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFAQ.Location = New System.Drawing.Point(10, 534)
        Me.btnFAQ.Name = "btnFAQ"
        Me.btnFAQ.Size = New System.Drawing.Size(106, 64)
        Me.btnFAQ.TabIndex = 9
        Me.btnFAQ.Text = "FAQ"
        Me.btnFAQ.UseVisualStyleBackColor = False
        '
        'txtConvertFrom
        '
        Me.txtConvertFrom.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.txtConvertFrom.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtConvertFrom.Font = New System.Drawing.Font("Nirmala UI", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtConvertFrom.Location = New System.Drawing.Point(566, 167)
        Me.txtConvertFrom.MaxLength = 100
        Me.txtConvertFrom.Multiline = True
        Me.txtConvertFrom.Name = "txtConvertFrom"
        Me.txtConvertFrom.Size = New System.Drawing.Size(208, 54)
        Me.txtConvertFrom.TabIndex = 10
        '
        'txtConvertTo
        '
        Me.txtConvertTo.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.txtConvertTo.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtConvertTo.Cursor = System.Windows.Forms.Cursors.No
        Me.txtConvertTo.Font = New System.Drawing.Font("Nirmala UI", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtConvertTo.Location = New System.Drawing.Point(566, 319)
        Me.txtConvertTo.MaxLength = 100
        Me.txtConvertTo.Multiline = True
        Me.txtConvertTo.Name = "txtConvertTo"
        Me.txtConvertTo.ReadOnly = True
        Me.txtConvertTo.Size = New System.Drawing.Size(208, 54)
        Me.txtConvertTo.TabIndex = 11
        '
        'pnlRates
        '
        Me.pnlRates.Controls.Add(Me.lblBRL)
        Me.pnlRates.Controls.Add(Me.lblBGN)
        Me.pnlRates.Controls.Add(Me.lblTRY)
        Me.pnlRates.Controls.Add(Me.lblPLN)
        Me.pnlRates.Controls.Add(Me.lblMDL)
        Me.pnlRates.Controls.Add(Me.lblUAH)
        Me.pnlRates.Controls.Add(Me.lblEUR)
        Me.pnlRates.Controls.Add(Me.lblCAD)
        Me.pnlRates.Controls.Add(Me.lblUSD)
        Me.pnlRates.Controls.Add(Me.lblGBP)
        Me.pnlRates.Controls.Add(Me.pcbBRL2)
        Me.pnlRates.Controls.Add(Me.pcbBRL1)
        Me.pnlRates.Controls.Add(Me.pcbTRY2)
        Me.pnlRates.Controls.Add(Me.pcbBGN2)
        Me.pnlRates.Controls.Add(Me.pcbBGN1)
        Me.pnlRates.Controls.Add(Me.txtBRLtoBRL)
        Me.pnlRates.Controls.Add(Me.txtBGNtoBRL)
        Me.pnlRates.Controls.Add(Me.txtTRYtoBRL)
        Me.pnlRates.Controls.Add(Me.txtPLNtoBRL)
        Me.pnlRates.Controls.Add(Me.txtMDLtoBRL)
        Me.pnlRates.Controls.Add(Me.txtUAHtoBRL)
        Me.pnlRates.Controls.Add(Me.txtEURtoBRL)
        Me.pnlRates.Controls.Add(Me.txtCADtoBRL)
        Me.pnlRates.Controls.Add(Me.txtUSDtoBRL)
        Me.pnlRates.Controls.Add(Me.txtGBRtoBRL)
        Me.pnlRates.Controls.Add(Me.pcbTRY1)
        Me.pnlRates.Controls.Add(Me.pcbPLN2)
        Me.pnlRates.Controls.Add(Me.pcbPLN1)
        Me.pnlRates.Controls.Add(Me.pcbMDL2)
        Me.pnlRates.Controls.Add(Me.pcbMDL1)
        Me.pnlRates.Controls.Add(Me.pcbUAH2)
        Me.pnlRates.Controls.Add(Me.pcbUAH1)
        Me.pnlRates.Controls.Add(Me.pcbCAD2)
        Me.pnlRates.Controls.Add(Me.pcbCAD1)
        Me.pnlRates.Controls.Add(Me.pcbUSD2)
        Me.pnlRates.Controls.Add(Me.pcbUSD1)
        Me.pnlRates.Controls.Add(Me.txtBRLtoBGN)
        Me.pnlRates.Controls.Add(Me.txtBRLtoTRY)
        Me.pnlRates.Controls.Add(Me.txtBRLtoPLN)
        Me.pnlRates.Controls.Add(Me.txtBRLtoMDL)
        Me.pnlRates.Controls.Add(Me.txtBRLtoUAH)
        Me.pnlRates.Controls.Add(Me.txtBRLtoEUR)
        Me.pnlRates.Controls.Add(Me.txtBRLtoCAD)
        Me.pnlRates.Controls.Add(Me.txtBRLtoUSD)
        Me.pnlRates.Controls.Add(Me.txtBGNtoBGN)
        Me.pnlRates.Controls.Add(Me.txtBGNtoTRY)
        Me.pnlRates.Controls.Add(Me.txtBGNtoPLN)
        Me.pnlRates.Controls.Add(Me.txtBGNtoMDL)
        Me.pnlRates.Controls.Add(Me.txtBGNtoUAH)
        Me.pnlRates.Controls.Add(Me.txtBGNtoEUR)
        Me.pnlRates.Controls.Add(Me.txtBGNtoCAD)
        Me.pnlRates.Controls.Add(Me.txtBGNtoUSD)
        Me.pnlRates.Controls.Add(Me.txtTRYtoBGN)
        Me.pnlRates.Controls.Add(Me.txtTRYtoTRY)
        Me.pnlRates.Controls.Add(Me.txtTRYtoPLN)
        Me.pnlRates.Controls.Add(Me.txtTRYtoMDL)
        Me.pnlRates.Controls.Add(Me.txtTRYtoUAH)
        Me.pnlRates.Controls.Add(Me.txtTRYtoEUR)
        Me.pnlRates.Controls.Add(Me.txtTRYtoCAD)
        Me.pnlRates.Controls.Add(Me.txtTRYtoUSD)
        Me.pnlRates.Controls.Add(Me.txtPLNtoBGN)
        Me.pnlRates.Controls.Add(Me.txtPLNtoTRY)
        Me.pnlRates.Controls.Add(Me.txtPLNtoPLN)
        Me.pnlRates.Controls.Add(Me.txtPLNtoMDL)
        Me.pnlRates.Controls.Add(Me.txtPLNtoUAH)
        Me.pnlRates.Controls.Add(Me.txtPLNtoEUR)
        Me.pnlRates.Controls.Add(Me.txtPLNtoCAD)
        Me.pnlRates.Controls.Add(Me.txtPLNtoUSD)
        Me.pnlRates.Controls.Add(Me.txtMDLtoBGN)
        Me.pnlRates.Controls.Add(Me.txtMDLtoTRY)
        Me.pnlRates.Controls.Add(Me.txtMDLtoPLN)
        Me.pnlRates.Controls.Add(Me.txtMDLtoMDL)
        Me.pnlRates.Controls.Add(Me.txtMDLtoUAH)
        Me.pnlRates.Controls.Add(Me.txtMDLtoEUR)
        Me.pnlRates.Controls.Add(Me.txtMDLtoCAD)
        Me.pnlRates.Controls.Add(Me.txtMDLtoUSD)
        Me.pnlRates.Controls.Add(Me.txtUAHtoBGN)
        Me.pnlRates.Controls.Add(Me.txtUAHtoTRY)
        Me.pnlRates.Controls.Add(Me.txtUAHtoPLN)
        Me.pnlRates.Controls.Add(Me.txtUAHtoMDL)
        Me.pnlRates.Controls.Add(Me.txtUAHtoUAH)
        Me.pnlRates.Controls.Add(Me.txtUAHtoEUR)
        Me.pnlRates.Controls.Add(Me.txtUAHtoCAD)
        Me.pnlRates.Controls.Add(Me.txtUAHtoUSD)
        Me.pnlRates.Controls.Add(Me.txtEURtoBGN)
        Me.pnlRates.Controls.Add(Me.txtEURtoTRY)
        Me.pnlRates.Controls.Add(Me.txtEURtoPLN)
        Me.pnlRates.Controls.Add(Me.txtEURtoMDL)
        Me.pnlRates.Controls.Add(Me.txtEURtoUAH)
        Me.pnlRates.Controls.Add(Me.txtEURtoEUR)
        Me.pnlRates.Controls.Add(Me.txtEURtoCAD)
        Me.pnlRates.Controls.Add(Me.txtEURtoUSD)
        Me.pnlRates.Controls.Add(Me.txtCADtoBGN)
        Me.pnlRates.Controls.Add(Me.txtCADtoTRY)
        Me.pnlRates.Controls.Add(Me.txtCADtoPLN)
        Me.pnlRates.Controls.Add(Me.txtCADtoMDL)
        Me.pnlRates.Controls.Add(Me.txtCADtoUAH)
        Me.pnlRates.Controls.Add(Me.txtCADtoEUR)
        Me.pnlRates.Controls.Add(Me.txtUSDtoBGN)
        Me.pnlRates.Controls.Add(Me.txtUSDtoTRY)
        Me.pnlRates.Controls.Add(Me.txtUSDtoPLN)
        Me.pnlRates.Controls.Add(Me.txtUSDtoMDL)
        Me.pnlRates.Controls.Add(Me.txtUSDtoUAH)
        Me.pnlRates.Controls.Add(Me.txtUSDtoEUR)
        Me.pnlRates.Controls.Add(Me.txtBRLtoGBR)
        Me.pnlRates.Controls.Add(Me.txtBGNtoGBR)
        Me.pnlRates.Controls.Add(Me.txtTRYtoGBR)
        Me.pnlRates.Controls.Add(Me.txtPLNtoGBR)
        Me.pnlRates.Controls.Add(Me.txtMDLtoGBR)
        Me.pnlRates.Controls.Add(Me.txtUAHtoGBR)
        Me.pnlRates.Controls.Add(Me.pcbEUR2)
        Me.pnlRates.Controls.Add(Me.pcbEUR1)
        Me.pnlRates.Controls.Add(Me.pcbGBR2)
        Me.pnlRates.Controls.Add(Me.pcbGBR1)
        Me.pnlRates.Controls.Add(Me.txtGBRtoBGN)
        Me.pnlRates.Controls.Add(Me.txtGBRtoTRY)
        Me.pnlRates.Controls.Add(Me.txtGBPtoPLN)
        Me.pnlRates.Controls.Add(Me.txtGBPtoMDL)
        Me.pnlRates.Controls.Add(Me.txtGBPtoUAH)
        Me.pnlRates.Controls.Add(Me.txtGBPtoEUR)
        Me.pnlRates.Controls.Add(Me.txtEURtoGBR)
        Me.pnlRates.Controls.Add(Me.btnCloseRate)
        Me.pnlRates.Controls.Add(Me.txtCADtoCAD)
        Me.pnlRates.Controls.Add(Me.txtCADtoUSD)
        Me.pnlRates.Controls.Add(Me.txtCADtoGBR)
        Me.pnlRates.Controls.Add(Me.txtUSDtoCAD)
        Me.pnlRates.Controls.Add(Me.txtUSDtoUSD)
        Me.pnlRates.Controls.Add(Me.txtUSDtoGBR)
        Me.pnlRates.Controls.Add(Me.txtGBPtoCAD)
        Me.pnlRates.Controls.Add(Me.txtGBPtoUSD)
        Me.pnlRates.Controls.Add(Me.txtGBPtoGBR)
        Me.pnlRates.Location = New System.Drawing.Point(1, -1)
        Me.pnlRates.Name = "pnlRates"
        Me.pnlRates.Size = New System.Drawing.Size(898, 610)
        Me.pnlRates.TabIndex = 12
        Me.pnlRates.Visible = False
        '
        'lblBRL
        '
        Me.lblBRL.AutoSize = True
        Me.lblBRL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBRL.Location = New System.Drawing.Point(814, 15)
        Me.lblBRL.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBRL.Name = "lblBRL"
        Me.lblBRL.Size = New System.Drawing.Size(38, 21)
        Me.lblBRL.TabIndex = 131
        Me.lblBRL.Text = "BRL"
        '
        'lblBGN
        '
        Me.lblBGN.AutoSize = True
        Me.lblBGN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBGN.Location = New System.Drawing.Point(740, 15)
        Me.lblBGN.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBGN.Name = "lblBGN"
        Me.lblBGN.Size = New System.Drawing.Size(44, 21)
        Me.lblBGN.TabIndex = 130
        Me.lblBGN.Text = "BGN"
        '
        'lblTRY
        '
        Me.lblTRY.AutoSize = True
        Me.lblTRY.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTRY.Location = New System.Drawing.Point(658, 15)
        Me.lblTRY.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTRY.Name = "lblTRY"
        Me.lblTRY.Size = New System.Drawing.Size(39, 21)
        Me.lblTRY.TabIndex = 129
        Me.lblTRY.Text = "TRY"
        '
        'lblPLN
        '
        Me.lblPLN.AutoSize = True
        Me.lblPLN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPLN.Location = New System.Drawing.Point(585, 15)
        Me.lblPLN.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblPLN.Name = "lblPLN"
        Me.lblPLN.Size = New System.Drawing.Size(41, 21)
        Me.lblPLN.TabIndex = 128
        Me.lblPLN.Text = "PLN"
        '
        'lblMDL
        '
        Me.lblMDL.AutoSize = True
        Me.lblMDL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMDL.Location = New System.Drawing.Point(497, 15)
        Me.lblMDL.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblMDL.Name = "lblMDL"
        Me.lblMDL.Size = New System.Drawing.Size(45, 21)
        Me.lblMDL.TabIndex = 127
        Me.lblMDL.Text = "MDL"
        '
        'lblUAH
        '
        Me.lblUAH.AutoSize = True
        Me.lblUAH.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUAH.Location = New System.Drawing.Point(419, 15)
        Me.lblUAH.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblUAH.Name = "lblUAH"
        Me.lblUAH.Size = New System.Drawing.Size(45, 21)
        Me.lblUAH.TabIndex = 126
        Me.lblUAH.Text = "UAH"
        '
        'lblEUR
        '
        Me.lblEUR.AutoSize = True
        Me.lblEUR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEUR.Location = New System.Drawing.Point(328, 15)
        Me.lblEUR.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEUR.Name = "lblEUR"
        Me.lblEUR.Size = New System.Drawing.Size(41, 21)
        Me.lblEUR.TabIndex = 125
        Me.lblEUR.Text = "EUR"
        '
        'lblCAD
        '
        Me.lblCAD.AutoSize = True
        Me.lblCAD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCAD.Location = New System.Drawing.Point(243, 13)
        Me.lblCAD.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCAD.Name = "lblCAD"
        Me.lblCAD.Size = New System.Drawing.Size(43, 21)
        Me.lblCAD.TabIndex = 124
        Me.lblCAD.Text = "CAD"
        '
        'lblUSD
        '
        Me.lblUSD.AutoSize = True
        Me.lblUSD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUSD.Location = New System.Drawing.Point(164, 13)
        Me.lblUSD.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblUSD.Name = "lblUSD"
        Me.lblUSD.Size = New System.Drawing.Size(43, 21)
        Me.lblUSD.TabIndex = 123
        Me.lblUSD.Text = "USD"
        '
        'lblGBP
        '
        Me.lblGBP.AutoSize = True
        Me.lblGBP.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGBP.Location = New System.Drawing.Point(86, 13)
        Me.lblGBP.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblGBP.Name = "lblGBP"
        Me.lblGBP.Size = New System.Drawing.Size(41, 21)
        Me.lblGBP.TabIndex = 122
        Me.lblGBP.Text = "GBR"
        '
        'pcbBRL2
        '
        Me.pcbBRL2.Image = Global.Exhanger_Unit_12.My.Resources.Resources.BRL
        Me.pcbBRL2.Location = New System.Drawing.Point(17, 492)
        Me.pcbBRL2.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbBRL2.Name = "pcbBRL2"
        Me.pcbBRL2.Size = New System.Drawing.Size(46, 31)
        Me.pcbBRL2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbBRL2.TabIndex = 121
        Me.pcbBRL2.TabStop = False
        '
        'pcbBRL1
        '
        Me.pcbBRL1.Image = Global.Exhanger_Unit_12.My.Resources.Resources.BRL
        Me.pcbBRL1.Location = New System.Drawing.Point(811, 41)
        Me.pcbBRL1.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbBRL1.Name = "pcbBRL1"
        Me.pcbBRL1.Size = New System.Drawing.Size(46, 31)
        Me.pcbBRL1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbBRL1.TabIndex = 120
        Me.pcbBRL1.TabStop = False
        '
        'pcbTRY2
        '
        Me.pcbTRY2.Image = Global.Exhanger_Unit_12.My.Resources.Resources._TRY
        Me.pcbTRY2.Location = New System.Drawing.Point(17, 396)
        Me.pcbTRY2.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbTRY2.Name = "pcbTRY2"
        Me.pcbTRY2.Size = New System.Drawing.Size(46, 28)
        Me.pcbTRY2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbTRY2.TabIndex = 119
        Me.pcbTRY2.TabStop = False
        '
        'pcbBGN2
        '
        Me.pcbBGN2.Image = Global.Exhanger_Unit_12.My.Resources.Resources.BGN
        Me.pcbBGN2.Location = New System.Drawing.Point(17, 448)
        Me.pcbBGN2.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbBGN2.Name = "pcbBGN2"
        Me.pcbBGN2.Size = New System.Drawing.Size(46, 28)
        Me.pcbBGN2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbBGN2.TabIndex = 118
        Me.pcbBGN2.TabStop = False
        '
        'pcbBGN1
        '
        Me.pcbBGN1.Image = Global.Exhanger_Unit_12.My.Resources.Resources.BGN
        Me.pcbBGN1.Location = New System.Drawing.Point(736, 41)
        Me.pcbBGN1.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbBGN1.Name = "pcbBGN1"
        Me.pcbBGN1.Size = New System.Drawing.Size(46, 28)
        Me.pcbBGN1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbBGN1.TabIndex = 117
        Me.pcbBGN1.TabStop = False
        '
        'txtBRLtoBRL
        '
        Me.txtBRLtoBRL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBRLtoBRL.Location = New System.Drawing.Point(814, 488)
        Me.txtBRLtoBRL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBRLtoBRL.MaxLength = 15
        Me.txtBRLtoBRL.Multiline = True
        Me.txtBRLtoBRL.Name = "txtBRLtoBRL"
        Me.txtBRLtoBRL.Size = New System.Drawing.Size(55, 30)
        Me.txtBRLtoBRL.TabIndex = 116
        Me.txtBRLtoBRL.Text = "1"
        '
        'txtBGNtoBRL
        '
        Me.txtBGNtoBRL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBGNtoBRL.Location = New System.Drawing.Point(814, 444)
        Me.txtBGNtoBRL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBGNtoBRL.MaxLength = 15
        Me.txtBGNtoBRL.Multiline = True
        Me.txtBGNtoBRL.Name = "txtBGNtoBRL"
        Me.txtBGNtoBRL.Size = New System.Drawing.Size(55, 30)
        Me.txtBGNtoBRL.TabIndex = 115
        Me.txtBGNtoBRL.Text = "2.87"
        '
        'txtTRYtoBRL
        '
        Me.txtTRYtoBRL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTRYtoBRL.Location = New System.Drawing.Point(814, 396)
        Me.txtTRYtoBRL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTRYtoBRL.MaxLength = 15
        Me.txtTRYtoBRL.Multiline = True
        Me.txtTRYtoBRL.Name = "txtTRYtoBRL"
        Me.txtTRYtoBRL.Size = New System.Drawing.Size(55, 30)
        Me.txtTRYtoBRL.TabIndex = 114
        Me.txtTRYtoBRL.Text = "0.27"
        '
        'txtPLNtoBRL
        '
        Me.txtPLNtoBRL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPLNtoBRL.Location = New System.Drawing.Point(814, 353)
        Me.txtPLNtoBRL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPLNtoBRL.MaxLength = 15
        Me.txtPLNtoBRL.Multiline = True
        Me.txtPLNtoBRL.Name = "txtPLNtoBRL"
        Me.txtPLNtoBRL.Size = New System.Drawing.Size(55, 30)
        Me.txtPLNtoBRL.TabIndex = 113
        Me.txtPLNtoBRL.Text = "1.15"
        '
        'txtMDLtoBRL
        '
        Me.txtMDLtoBRL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMDLtoBRL.Location = New System.Drawing.Point(814, 310)
        Me.txtMDLtoBRL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMDLtoBRL.MaxLength = 15
        Me.txtMDLtoBRL.Multiline = True
        Me.txtMDLtoBRL.Name = "txtMDLtoBRL"
        Me.txtMDLtoBRL.Size = New System.Drawing.Size(55, 30)
        Me.txtMDLtoBRL.TabIndex = 112
        Me.txtMDLtoBRL.Text = "0.27"
        '
        'txtUAHtoBRL
        '
        Me.txtUAHtoBRL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUAHtoBRL.Location = New System.Drawing.Point(814, 266)
        Me.txtUAHtoBRL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUAHtoBRL.MaxLength = 15
        Me.txtUAHtoBRL.Multiline = True
        Me.txtUAHtoBRL.Name = "txtUAHtoBRL"
        Me.txtUAHtoBRL.Size = New System.Drawing.Size(55, 30)
        Me.txtUAHtoBRL.TabIndex = 111
        Me.txtUAHtoBRL.Text = "0.14"
        '
        'txtEURtoBRL
        '
        Me.txtEURtoBRL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEURtoBRL.Location = New System.Drawing.Point(814, 223)
        Me.txtEURtoBRL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEURtoBRL.MaxLength = 15
        Me.txtEURtoBRL.Multiline = True
        Me.txtEURtoBRL.Name = "txtEURtoBRL"
        Me.txtEURtoBRL.Size = New System.Drawing.Size(55, 30)
        Me.txtEURtoBRL.TabIndex = 110
        Me.txtEURtoBRL.Text = "5.43"
        '
        'txtCADtoBRL
        '
        Me.txtCADtoBRL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCADtoBRL.Location = New System.Drawing.Point(811, 177)
        Me.txtCADtoBRL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCADtoBRL.MaxLength = 15
        Me.txtCADtoBRL.Multiline = True
        Me.txtCADtoBRL.Name = "txtCADtoBRL"
        Me.txtCADtoBRL.Size = New System.Drawing.Size(55, 30)
        Me.txtCADtoBRL.TabIndex = 109
        Me.txtCADtoBRL.Text = "3.79"
        '
        'txtUSDtoBRL
        '
        Me.txtUSDtoBRL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUSDtoBRL.Location = New System.Drawing.Point(811, 139)
        Me.txtUSDtoBRL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUSDtoBRL.MaxLength = 15
        Me.txtUSDtoBRL.Multiline = True
        Me.txtUSDtoBRL.Name = "txtUSDtoBRL"
        Me.txtUSDtoBRL.Size = New System.Drawing.Size(55, 30)
        Me.txtUSDtoBRL.TabIndex = 108
        Me.txtUSDtoBRL.Text = "5.14"
        '
        'txtGBRtoBRL
        '
        Me.txtGBRtoBRL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGBRtoBRL.Location = New System.Drawing.Point(814, 85)
        Me.txtGBRtoBRL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtGBRtoBRL.MaxLength = 15
        Me.txtGBRtoBRL.Multiline = True
        Me.txtGBRtoBRL.Name = "txtGBRtoBRL"
        Me.txtGBRtoBRL.Size = New System.Drawing.Size(55, 30)
        Me.txtGBRtoBRL.TabIndex = 107
        Me.txtGBRtoBRL.Text = "6.17"
        '
        'pcbTRY1
        '
        Me.pcbTRY1.Image = Global.Exhanger_Unit_12.My.Resources.Resources._TRY
        Me.pcbTRY1.Location = New System.Drawing.Point(654, 41)
        Me.pcbTRY1.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbTRY1.Name = "pcbTRY1"
        Me.pcbTRY1.Size = New System.Drawing.Size(46, 28)
        Me.pcbTRY1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbTRY1.TabIndex = 106
        Me.pcbTRY1.TabStop = False
        '
        'pcbPLN2
        '
        Me.pcbPLN2.Image = Global.Exhanger_Unit_12.My.Resources.Resources.PLN
        Me.pcbPLN2.Location = New System.Drawing.Point(17, 354)
        Me.pcbPLN2.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbPLN2.Name = "pcbPLN2"
        Me.pcbPLN2.Size = New System.Drawing.Size(46, 28)
        Me.pcbPLN2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbPLN2.TabIndex = 105
        Me.pcbPLN2.TabStop = False
        '
        'pcbPLN1
        '
        Me.pcbPLN1.Image = Global.Exhanger_Unit_12.My.Resources.Resources.PLN
        Me.pcbPLN1.Location = New System.Drawing.Point(581, 41)
        Me.pcbPLN1.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbPLN1.Name = "pcbPLN1"
        Me.pcbPLN1.Size = New System.Drawing.Size(46, 28)
        Me.pcbPLN1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbPLN1.TabIndex = 104
        Me.pcbPLN1.TabStop = False
        '
        'pcbMDL2
        '
        Me.pcbMDL2.Image = Global.Exhanger_Unit_12.My.Resources.Resources.MDL
        Me.pcbMDL2.Location = New System.Drawing.Point(17, 314)
        Me.pcbMDL2.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbMDL2.Name = "pcbMDL2"
        Me.pcbMDL2.Size = New System.Drawing.Size(46, 28)
        Me.pcbMDL2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbMDL2.TabIndex = 103
        Me.pcbMDL2.TabStop = False
        '
        'pcbMDL1
        '
        Me.pcbMDL1.Image = Global.Exhanger_Unit_12.My.Resources.Resources.MDL
        Me.pcbMDL1.Location = New System.Drawing.Point(494, 41)
        Me.pcbMDL1.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbMDL1.Name = "pcbMDL1"
        Me.pcbMDL1.Size = New System.Drawing.Size(46, 28)
        Me.pcbMDL1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbMDL1.TabIndex = 102
        Me.pcbMDL1.TabStop = False
        '
        'pcbUAH2
        '
        Me.pcbUAH2.Image = Global.Exhanger_Unit_12.My.Resources.Resources.UAH
        Me.pcbUAH2.Location = New System.Drawing.Point(17, 268)
        Me.pcbUAH2.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbUAH2.Name = "pcbUAH2"
        Me.pcbUAH2.Size = New System.Drawing.Size(46, 28)
        Me.pcbUAH2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbUAH2.TabIndex = 101
        Me.pcbUAH2.TabStop = False
        '
        'pcbUAH1
        '
        Me.pcbUAH1.Image = Global.Exhanger_Unit_12.My.Resources.Resources.UAH
        Me.pcbUAH1.Location = New System.Drawing.Point(415, 41)
        Me.pcbUAH1.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbUAH1.Name = "pcbUAH1"
        Me.pcbUAH1.Size = New System.Drawing.Size(46, 28)
        Me.pcbUAH1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbUAH1.TabIndex = 100
        Me.pcbUAH1.TabStop = False
        '
        'pcbCAD2
        '
        Me.pcbCAD2.Image = Global.Exhanger_Unit_12.My.Resources.Resources.CAD
        Me.pcbCAD2.Location = New System.Drawing.Point(19, 176)
        Me.pcbCAD2.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbCAD2.Name = "pcbCAD2"
        Me.pcbCAD2.Size = New System.Drawing.Size(44, 28)
        Me.pcbCAD2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbCAD2.TabIndex = 99
        Me.pcbCAD2.TabStop = False
        '
        'pcbCAD1
        '
        Me.pcbCAD1.Image = Global.Exhanger_Unit_12.My.Resources.Resources.CAD
        Me.pcbCAD1.Location = New System.Drawing.Point(238, 41)
        Me.pcbCAD1.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbCAD1.Name = "pcbCAD1"
        Me.pcbCAD1.Size = New System.Drawing.Size(44, 28)
        Me.pcbCAD1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbCAD1.TabIndex = 98
        Me.pcbCAD1.TabStop = False
        '
        'pcbUSD2
        '
        Me.pcbUSD2.Image = Global.Exhanger_Unit_12.My.Resources.Resources.USD
        Me.pcbUSD2.Location = New System.Drawing.Point(17, 134)
        Me.pcbUSD2.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbUSD2.Name = "pcbUSD2"
        Me.pcbUSD2.Size = New System.Drawing.Size(44, 31)
        Me.pcbUSD2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbUSD2.TabIndex = 97
        Me.pcbUSD2.TabStop = False
        '
        'pcbUSD1
        '
        Me.pcbUSD1.Image = Global.Exhanger_Unit_12.My.Resources.Resources.USD
        Me.pcbUSD1.Location = New System.Drawing.Point(160, 41)
        Me.pcbUSD1.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbUSD1.Name = "pcbUSD1"
        Me.pcbUSD1.Size = New System.Drawing.Size(44, 31)
        Me.pcbUSD1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbUSD1.TabIndex = 96
        Me.pcbUSD1.TabStop = False
        '
        'txtBRLtoBGN
        '
        Me.txtBRLtoBGN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBRLtoBGN.Location = New System.Drawing.Point(740, 488)
        Me.txtBRLtoBGN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBRLtoBGN.MaxLength = 15
        Me.txtBRLtoBGN.Multiline = True
        Me.txtBRLtoBGN.Name = "txtBRLtoBGN"
        Me.txtBRLtoBGN.Size = New System.Drawing.Size(55, 30)
        Me.txtBRLtoBGN.TabIndex = 95
        Me.txtBRLtoBGN.Text = "0.36"
        '
        'txtBRLtoTRY
        '
        Me.txtBRLtoTRY.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBRLtoTRY.Location = New System.Drawing.Point(657, 489)
        Me.txtBRLtoTRY.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBRLtoTRY.MaxLength = 15
        Me.txtBRLtoTRY.Multiline = True
        Me.txtBRLtoTRY.Name = "txtBRLtoTRY"
        Me.txtBRLtoTRY.Size = New System.Drawing.Size(55, 30)
        Me.txtBRLtoTRY.TabIndex = 94
        Me.txtBRLtoTRY.Text = "3.67"
        '
        'txtBRLtoPLN
        '
        Me.txtBRLtoPLN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBRLtoPLN.Location = New System.Drawing.Point(584, 491)
        Me.txtBRLtoPLN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBRLtoPLN.MaxLength = 15
        Me.txtBRLtoPLN.Multiline = True
        Me.txtBRLtoPLN.Name = "txtBRLtoPLN"
        Me.txtBRLtoPLN.Size = New System.Drawing.Size(55, 30)
        Me.txtBRLtoPLN.TabIndex = 93
        Me.txtBRLtoPLN.Text = "0.85"
        '
        'txtBRLtoMDL
        '
        Me.txtBRLtoMDL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBRLtoMDL.Location = New System.Drawing.Point(497, 492)
        Me.txtBRLtoMDL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBRLtoMDL.MaxLength = 15
        Me.txtBRLtoMDL.Multiline = True
        Me.txtBRLtoMDL.Name = "txtBRLtoMDL"
        Me.txtBRLtoMDL.Size = New System.Drawing.Size(55, 30)
        Me.txtBRLtoMDL.TabIndex = 92
        Me.txtBRLtoMDL.Text = "3.66"
        '
        'txtBRLtoUAH
        '
        Me.txtBRLtoUAH.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBRLtoUAH.Location = New System.Drawing.Point(415, 492)
        Me.txtBRLtoUAH.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBRLtoUAH.MaxLength = 15
        Me.txtBRLtoUAH.Multiline = True
        Me.txtBRLtoUAH.Name = "txtBRLtoUAH"
        Me.txtBRLtoUAH.Size = New System.Drawing.Size(55, 30)
        Me.txtBRLtoUAH.TabIndex = 91
        Me.txtBRLtoUAH.Text = "7.15"
        '
        'txtBRLtoEUR
        '
        Me.txtBRLtoEUR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBRLtoEUR.Location = New System.Drawing.Point(328, 491)
        Me.txtBRLtoEUR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBRLtoEUR.MaxLength = 15
        Me.txtBRLtoEUR.Multiline = True
        Me.txtBRLtoEUR.Name = "txtBRLtoEUR"
        Me.txtBRLtoEUR.Size = New System.Drawing.Size(55, 30)
        Me.txtBRLtoEUR.TabIndex = 90
        Me.txtBRLtoEUR.Text = "0.18"
        '
        'txtBRLtoCAD
        '
        Me.txtBRLtoCAD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBRLtoCAD.Location = New System.Drawing.Point(242, 491)
        Me.txtBRLtoCAD.MaxLength = 15
        Me.txtBRLtoCAD.Multiline = True
        Me.txtBRLtoCAD.Name = "txtBRLtoCAD"
        Me.txtBRLtoCAD.Size = New System.Drawing.Size(55, 30)
        Me.txtBRLtoCAD.TabIndex = 89
        Me.txtBRLtoCAD.Text = "0.26"
        '
        'txtBRLtoUSD
        '
        Me.txtBRLtoUSD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBRLtoUSD.Location = New System.Drawing.Point(163, 491)
        Me.txtBRLtoUSD.MaxLength = 15
        Me.txtBRLtoUSD.Multiline = True
        Me.txtBRLtoUSD.Name = "txtBRLtoUSD"
        Me.txtBRLtoUSD.Size = New System.Drawing.Size(55, 30)
        Me.txtBRLtoUSD.TabIndex = 88
        Me.txtBRLtoUSD.Text = "0.19"
        '
        'txtBGNtoBGN
        '
        Me.txtBGNtoBGN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBGNtoBGN.Location = New System.Drawing.Point(740, 444)
        Me.txtBGNtoBGN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBGNtoBGN.MaxLength = 15
        Me.txtBGNtoBGN.Multiline = True
        Me.txtBGNtoBGN.Name = "txtBGNtoBGN"
        Me.txtBGNtoBGN.Size = New System.Drawing.Size(55, 30)
        Me.txtBGNtoBGN.TabIndex = 87
        Me.txtBGNtoBGN.Text = "1"
        '
        'txtBGNtoTRY
        '
        Me.txtBGNtoTRY.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBGNtoTRY.Location = New System.Drawing.Point(657, 443)
        Me.txtBGNtoTRY.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBGNtoTRY.MaxLength = 15
        Me.txtBGNtoTRY.Multiline = True
        Me.txtBGNtoTRY.Name = "txtBGNtoTRY"
        Me.txtBGNtoTRY.Size = New System.Drawing.Size(55, 30)
        Me.txtBGNtoTRY.TabIndex = 86
        Me.txtBGNtoTRY.Text = "10.37"
        '
        'txtBGNtoPLN
        '
        Me.txtBGNtoPLN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBGNtoPLN.Location = New System.Drawing.Point(584, 443)
        Me.txtBGNtoPLN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBGNtoPLN.MaxLength = 15
        Me.txtBGNtoPLN.Multiline = True
        Me.txtBGNtoPLN.Name = "txtBGNtoPLN"
        Me.txtBGNtoPLN.Size = New System.Drawing.Size(55, 30)
        Me.txtBGNtoPLN.TabIndex = 85
        Me.txtBGNtoPLN.Text = "2.42"
        '
        'txtBGNtoMDL
        '
        Me.txtBGNtoMDL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBGNtoMDL.Location = New System.Drawing.Point(497, 444)
        Me.txtBGNtoMDL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBGNtoMDL.MaxLength = 15
        Me.txtBGNtoMDL.Multiline = True
        Me.txtBGNtoMDL.Name = "txtBGNtoMDL"
        Me.txtBGNtoMDL.Size = New System.Drawing.Size(55, 30)
        Me.txtBGNtoMDL.TabIndex = 84
        Me.txtBGNtoMDL.Text = "10.18"
        '
        'txtBGNtoUAH
        '
        Me.txtBGNtoUAH.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBGNtoUAH.Location = New System.Drawing.Point(415, 444)
        Me.txtBGNtoUAH.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBGNtoUAH.MaxLength = 15
        Me.txtBGNtoUAH.Multiline = True
        Me.txtBGNtoUAH.Name = "txtBGNtoUAH"
        Me.txtBGNtoUAH.Size = New System.Drawing.Size(55, 30)
        Me.txtBGNtoUAH.TabIndex = 83
        Me.txtBGNtoUAH.Text = "19.90"
        '
        'txtBGNtoEUR
        '
        Me.txtBGNtoEUR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBGNtoEUR.Location = New System.Drawing.Point(328, 443)
        Me.txtBGNtoEUR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBGNtoEUR.MaxLength = 15
        Me.txtBGNtoEUR.Multiline = True
        Me.txtBGNtoEUR.Name = "txtBGNtoEUR"
        Me.txtBGNtoEUR.Size = New System.Drawing.Size(55, 30)
        Me.txtBGNtoEUR.TabIndex = 82
        Me.txtBGNtoEUR.Text = "0.51"
        '
        'txtBGNtoCAD
        '
        Me.txtBGNtoCAD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBGNtoCAD.Location = New System.Drawing.Point(242, 443)
        Me.txtBGNtoCAD.MaxLength = 15
        Me.txtBGNtoCAD.Multiline = True
        Me.txtBGNtoCAD.Name = "txtBGNtoCAD"
        Me.txtBGNtoCAD.Size = New System.Drawing.Size(55, 30)
        Me.txtBGNtoCAD.TabIndex = 81
        Me.txtBGNtoCAD.Text = "0.73"
        '
        'txtBGNtoUSD
        '
        Me.txtBGNtoUSD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBGNtoUSD.Location = New System.Drawing.Point(163, 443)
        Me.txtBGNtoUSD.MaxLength = 15
        Me.txtBGNtoUSD.Multiline = True
        Me.txtBGNtoUSD.Name = "txtBGNtoUSD"
        Me.txtBGNtoUSD.Size = New System.Drawing.Size(55, 30)
        Me.txtBGNtoUSD.TabIndex = 80
        Me.txtBGNtoUSD.Text = "0.54"
        '
        'txtTRYtoBGN
        '
        Me.txtTRYtoBGN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTRYtoBGN.Location = New System.Drawing.Point(740, 395)
        Me.txtTRYtoBGN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTRYtoBGN.MaxLength = 15
        Me.txtTRYtoBGN.Multiline = True
        Me.txtTRYtoBGN.Name = "txtTRYtoBGN"
        Me.txtTRYtoBGN.Size = New System.Drawing.Size(55, 30)
        Me.txtTRYtoBGN.TabIndex = 79
        Me.txtTRYtoBGN.Text = "0.098"
        '
        'txtTRYtoTRY
        '
        Me.txtTRYtoTRY.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTRYtoTRY.Location = New System.Drawing.Point(657, 396)
        Me.txtTRYtoTRY.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTRYtoTRY.MaxLength = 15
        Me.txtTRYtoTRY.Multiline = True
        Me.txtTRYtoTRY.Name = "txtTRYtoTRY"
        Me.txtTRYtoTRY.Size = New System.Drawing.Size(55, 30)
        Me.txtTRYtoTRY.TabIndex = 78
        Me.txtTRYtoTRY.Text = "1"
        '
        'txtTRYtoPLN
        '
        Me.txtTRYtoPLN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTRYtoPLN.Location = New System.Drawing.Point(584, 394)
        Me.txtTRYtoPLN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTRYtoPLN.MaxLength = 15
        Me.txtTRYtoPLN.Multiline = True
        Me.txtTRYtoPLN.Name = "txtTRYtoPLN"
        Me.txtTRYtoPLN.Size = New System.Drawing.Size(55, 30)
        Me.txtTRYtoPLN.TabIndex = 77
        Me.txtTRYtoPLN.Text = "0.24"
        '
        'txtTRYtoMDL
        '
        Me.txtTRYtoMDL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTRYtoMDL.Location = New System.Drawing.Point(497, 395)
        Me.txtTRYtoMDL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTRYtoMDL.MaxLength = 15
        Me.txtTRYtoMDL.Multiline = True
        Me.txtTRYtoMDL.Name = "txtTRYtoMDL"
        Me.txtTRYtoMDL.Size = New System.Drawing.Size(55, 30)
        Me.txtTRYtoMDL.TabIndex = 76
        Me.txtTRYtoMDL.Text = "0.996"
        '
        'txtTRYtoUAH
        '
        Me.txtTRYtoUAH.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTRYtoUAH.Location = New System.Drawing.Point(415, 396)
        Me.txtTRYtoUAH.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTRYtoUAH.MaxLength = 15
        Me.txtTRYtoUAH.Multiline = True
        Me.txtTRYtoUAH.Name = "txtTRYtoUAH"
        Me.txtTRYtoUAH.Size = New System.Drawing.Size(55, 30)
        Me.txtTRYtoUAH.TabIndex = 75
        Me.txtTRYtoUAH.Text = "1.95"
        '
        'txtTRYtoEUR
        '
        Me.txtTRYtoEUR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTRYtoEUR.Location = New System.Drawing.Point(328, 394)
        Me.txtTRYtoEUR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTRYtoEUR.MaxLength = 15
        Me.txtTRYtoEUR.Multiline = True
        Me.txtTRYtoEUR.Name = "txtTRYtoEUR"
        Me.txtTRYtoEUR.Size = New System.Drawing.Size(55, 30)
        Me.txtTRYtoEUR.TabIndex = 74
        Me.txtTRYtoEUR.Text = "0.050"
        '
        'txtTRYtoCAD
        '
        Me.txtTRYtoCAD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTRYtoCAD.Location = New System.Drawing.Point(242, 394)
        Me.txtTRYtoCAD.MaxLength = 15
        Me.txtTRYtoCAD.Multiline = True
        Me.txtTRYtoCAD.Name = "txtTRYtoCAD"
        Me.txtTRYtoCAD.Size = New System.Drawing.Size(55, 30)
        Me.txtTRYtoCAD.TabIndex = 73
        Me.txtTRYtoCAD.Text = "0.071"
        '
        'txtTRYtoUSD
        '
        Me.txtTRYtoUSD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTRYtoUSD.Location = New System.Drawing.Point(163, 394)
        Me.txtTRYtoUSD.MaxLength = 15
        Me.txtTRYtoUSD.Multiline = True
        Me.txtTRYtoUSD.Name = "txtTRYtoUSD"
        Me.txtTRYtoUSD.Size = New System.Drawing.Size(55, 30)
        Me.txtTRYtoUSD.TabIndex = 72
        Me.txtTRYtoUSD.Text = "0.053"
        '
        'txtPLNtoBGN
        '
        Me.txtPLNtoBGN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPLNtoBGN.Location = New System.Drawing.Point(740, 352)
        Me.txtPLNtoBGN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPLNtoBGN.MaxLength = 15
        Me.txtPLNtoBGN.Multiline = True
        Me.txtPLNtoBGN.Name = "txtPLNtoBGN"
        Me.txtPLNtoBGN.Size = New System.Drawing.Size(55, 30)
        Me.txtPLNtoBGN.TabIndex = 71
        Me.txtPLNtoBGN.Text = "0.41"
        '
        'txtPLNtoTRY
        '
        Me.txtPLNtoTRY.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPLNtoTRY.Location = New System.Drawing.Point(657, 352)
        Me.txtPLNtoTRY.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPLNtoTRY.MaxLength = 15
        Me.txtPLNtoTRY.Multiline = True
        Me.txtPLNtoTRY.Name = "txtPLNtoTRY"
        Me.txtPLNtoTRY.Size = New System.Drawing.Size(55, 30)
        Me.txtPLNtoTRY.TabIndex = 70
        Me.txtPLNtoTRY.Text = "4.22"
        '
        'txtPLNtoPLN
        '
        Me.txtPLNtoPLN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPLNtoPLN.Location = New System.Drawing.Point(584, 351)
        Me.txtPLNtoPLN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPLNtoPLN.MaxLength = 15
        Me.txtPLNtoPLN.Multiline = True
        Me.txtPLNtoPLN.Name = "txtPLNtoPLN"
        Me.txtPLNtoPLN.Size = New System.Drawing.Size(55, 30)
        Me.txtPLNtoPLN.TabIndex = 69
        Me.txtPLNtoPLN.Text = "1"
        '
        'txtPLNtoMDL
        '
        Me.txtPLNtoMDL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPLNtoMDL.Location = New System.Drawing.Point(497, 352)
        Me.txtPLNtoMDL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPLNtoMDL.MaxLength = 15
        Me.txtPLNtoMDL.Multiline = True
        Me.txtPLNtoMDL.Name = "txtPLNtoMDL"
        Me.txtPLNtoMDL.Size = New System.Drawing.Size(55, 30)
        Me.txtPLNtoMDL.TabIndex = 68
        Me.txtPLNtoMDL.Text = "4.20"
        '
        'txtPLNtoUAH
        '
        Me.txtPLNtoUAH.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPLNtoUAH.Location = New System.Drawing.Point(415, 353)
        Me.txtPLNtoUAH.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPLNtoUAH.Multiline = True
        Me.txtPLNtoUAH.Name = "txtPLNtoUAH"
        Me.txtPLNtoUAH.Size = New System.Drawing.Size(55, 30)
        Me.txtPLNtoUAH.TabIndex = 67
        Me.txtPLNtoUAH.Text = "8.35"
        '
        'txtPLNtoEUR
        '
        Me.txtPLNtoEUR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPLNtoEUR.Location = New System.Drawing.Point(328, 351)
        Me.txtPLNtoEUR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPLNtoEUR.MaxLength = 15
        Me.txtPLNtoEUR.Multiline = True
        Me.txtPLNtoEUR.Name = "txtPLNtoEUR"
        Me.txtPLNtoEUR.Size = New System.Drawing.Size(55, 30)
        Me.txtPLNtoEUR.TabIndex = 66
        Me.txtPLNtoEUR.Text = "0.21"
        '
        'txtPLNtoCAD
        '
        Me.txtPLNtoCAD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPLNtoCAD.Location = New System.Drawing.Point(242, 351)
        Me.txtPLNtoCAD.MaxLength = 15
        Me.txtPLNtoCAD.Multiline = True
        Me.txtPLNtoCAD.Name = "txtPLNtoCAD"
        Me.txtPLNtoCAD.Size = New System.Drawing.Size(55, 30)
        Me.txtPLNtoCAD.TabIndex = 65
        Me.txtPLNtoCAD.Text = "0.30"
        '
        'txtPLNtoUSD
        '
        Me.txtPLNtoUSD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPLNtoUSD.Location = New System.Drawing.Point(163, 351)
        Me.txtPLNtoUSD.MaxLength = 15
        Me.txtPLNtoUSD.Multiline = True
        Me.txtPLNtoUSD.Name = "txtPLNtoUSD"
        Me.txtPLNtoUSD.Size = New System.Drawing.Size(55, 30)
        Me.txtPLNtoUSD.TabIndex = 64
        Me.txtPLNtoUSD.Text = "0.22"
        '
        'txtMDLtoBGN
        '
        Me.txtMDLtoBGN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMDLtoBGN.Location = New System.Drawing.Point(740, 309)
        Me.txtMDLtoBGN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMDLtoBGN.MaxLength = 15
        Me.txtMDLtoBGN.Multiline = True
        Me.txtMDLtoBGN.Name = "txtMDLtoBGN"
        Me.txtMDLtoBGN.Size = New System.Drawing.Size(55, 30)
        Me.txtMDLtoBGN.TabIndex = 63
        Me.txtMDLtoBGN.Text = "0.098"
        '
        'txtMDLtoTRY
        '
        Me.txtMDLtoTRY.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMDLtoTRY.Location = New System.Drawing.Point(657, 307)
        Me.txtMDLtoTRY.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMDLtoTRY.MaxLength = 15
        Me.txtMDLtoTRY.Multiline = True
        Me.txtMDLtoTRY.Name = "txtMDLtoTRY"
        Me.txtMDLtoTRY.Size = New System.Drawing.Size(55, 30)
        Me.txtMDLtoTRY.TabIndex = 62
        Me.txtMDLtoTRY.Text = "1.004"
        '
        'txtMDLtoPLN
        '
        Me.txtMDLtoPLN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMDLtoPLN.Location = New System.Drawing.Point(584, 308)
        Me.txtMDLtoPLN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMDLtoPLN.MaxLength = 15
        Me.txtMDLtoPLN.Multiline = True
        Me.txtMDLtoPLN.Name = "txtMDLtoPLN"
        Me.txtMDLtoPLN.Size = New System.Drawing.Size(55, 30)
        Me.txtMDLtoPLN.TabIndex = 61
        Me.txtMDLtoPLN.Text = "0.23"
        '
        'txtMDLtoMDL
        '
        Me.txtMDLtoMDL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMDLtoMDL.Location = New System.Drawing.Point(497, 309)
        Me.txtMDLtoMDL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMDLtoMDL.MaxLength = 15
        Me.txtMDLtoMDL.Multiline = True
        Me.txtMDLtoMDL.Name = "txtMDLtoMDL"
        Me.txtMDLtoMDL.Size = New System.Drawing.Size(55, 30)
        Me.txtMDLtoMDL.TabIndex = 60
        Me.txtMDLtoMDL.Text = "1"
        '
        'txtMDLtoUAH
        '
        Me.txtMDLtoUAH.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMDLtoUAH.Location = New System.Drawing.Point(415, 310)
        Me.txtMDLtoUAH.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMDLtoUAH.MaxLength = 15
        Me.txtMDLtoUAH.Multiline = True
        Me.txtMDLtoUAH.Name = "txtMDLtoUAH"
        Me.txtMDLtoUAH.Size = New System.Drawing.Size(55, 30)
        Me.txtMDLtoUAH.TabIndex = 59
        Me.txtMDLtoUAH.Text = "1.95"
        '
        'txtMDLtoEUR
        '
        Me.txtMDLtoEUR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMDLtoEUR.Location = New System.Drawing.Point(328, 308)
        Me.txtMDLtoEUR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMDLtoEUR.MaxLength = 15
        Me.txtMDLtoEUR.Multiline = True
        Me.txtMDLtoEUR.Name = "txtMDLtoEUR"
        Me.txtMDLtoEUR.Size = New System.Drawing.Size(55, 30)
        Me.txtMDLtoEUR.TabIndex = 58
        Me.txtMDLtoEUR.Text = "0.050"
        '
        'txtMDLtoCAD
        '
        Me.txtMDLtoCAD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMDLtoCAD.Location = New System.Drawing.Point(242, 308)
        Me.txtMDLtoCAD.MaxLength = 15
        Me.txtMDLtoCAD.Multiline = True
        Me.txtMDLtoCAD.Name = "txtMDLtoCAD"
        Me.txtMDLtoCAD.Size = New System.Drawing.Size(55, 30)
        Me.txtMDLtoCAD.TabIndex = 57
        Me.txtMDLtoCAD.Text = "0.072"
        '
        'txtMDLtoUSD
        '
        Me.txtMDLtoUSD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMDLtoUSD.Location = New System.Drawing.Point(163, 308)
        Me.txtMDLtoUSD.MaxLength = 15
        Me.txtMDLtoUSD.Multiline = True
        Me.txtMDLtoUSD.Name = "txtMDLtoUSD"
        Me.txtMDLtoUSD.Size = New System.Drawing.Size(55, 30)
        Me.txtMDLtoUSD.TabIndex = 56
        Me.txtMDLtoUSD.Text = "0.053"
        '
        'txtUAHtoBGN
        '
        Me.txtUAHtoBGN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUAHtoBGN.Location = New System.Drawing.Point(740, 265)
        Me.txtUAHtoBGN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUAHtoBGN.MaxLength = 15
        Me.txtUAHtoBGN.Multiline = True
        Me.txtUAHtoBGN.Name = "txtUAHtoBGN"
        Me.txtUAHtoBGN.Size = New System.Drawing.Size(55, 30)
        Me.txtUAHtoBGN.TabIndex = 55
        Me.txtUAHtoBGN.Text = "0.050"
        '
        'txtUAHtoTRY
        '
        Me.txtUAHtoTRY.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUAHtoTRY.Location = New System.Drawing.Point(657, 263)
        Me.txtUAHtoTRY.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUAHtoTRY.MaxLength = 15
        Me.txtUAHtoTRY.Multiline = True
        Me.txtUAHtoTRY.Name = "txtUAHtoTRY"
        Me.txtUAHtoTRY.Size = New System.Drawing.Size(55, 30)
        Me.txtUAHtoTRY.TabIndex = 54
        Me.txtUAHtoTRY.Text = "0.51"
        '
        'txtUAHtoPLN
        '
        Me.txtUAHtoPLN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUAHtoPLN.Location = New System.Drawing.Point(584, 264)
        Me.txtUAHtoPLN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUAHtoPLN.MaxLength = 15
        Me.txtUAHtoPLN.Multiline = True
        Me.txtUAHtoPLN.Name = "txtUAHtoPLN"
        Me.txtUAHtoPLN.Size = New System.Drawing.Size(55, 30)
        Me.txtUAHtoPLN.TabIndex = 53
        Me.txtUAHtoPLN.Text = "0.12"
        '
        'txtUAHtoMDL
        '
        Me.txtUAHtoMDL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUAHtoMDL.Location = New System.Drawing.Point(497, 265)
        Me.txtUAHtoMDL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUAHtoMDL.MaxLength = 15
        Me.txtUAHtoMDL.Multiline = True
        Me.txtUAHtoMDL.Name = "txtUAHtoMDL"
        Me.txtUAHtoMDL.Size = New System.Drawing.Size(55, 30)
        Me.txtUAHtoMDL.TabIndex = 52
        Me.txtUAHtoMDL.Text = "0.51"
        '
        'txtUAHtoUAH
        '
        Me.txtUAHtoUAH.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUAHtoUAH.Location = New System.Drawing.Point(415, 266)
        Me.txtUAHtoUAH.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUAHtoUAH.MaxLength = 15
        Me.txtUAHtoUAH.Multiline = True
        Me.txtUAHtoUAH.Name = "txtUAHtoUAH"
        Me.txtUAHtoUAH.Size = New System.Drawing.Size(55, 30)
        Me.txtUAHtoUAH.TabIndex = 51
        Me.txtUAHtoUAH.Text = "1"
        '
        'txtUAHtoEUR
        '
        Me.txtUAHtoEUR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUAHtoEUR.Location = New System.Drawing.Point(328, 264)
        Me.txtUAHtoEUR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUAHtoEUR.MaxLength = 15
        Me.txtUAHtoEUR.Multiline = True
        Me.txtUAHtoEUR.Name = "txtUAHtoEUR"
        Me.txtUAHtoEUR.Size = New System.Drawing.Size(55, 30)
        Me.txtUAHtoEUR.TabIndex = 50
        Me.txtUAHtoEUR.Text = "0.025"
        '
        'txtUAHtoCAD
        '
        Me.txtUAHtoCAD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUAHtoCAD.Location = New System.Drawing.Point(242, 264)
        Me.txtUAHtoCAD.MaxLength = 15
        Me.txtUAHtoCAD.Multiline = True
        Me.txtUAHtoCAD.Name = "txtUAHtoCAD"
        Me.txtUAHtoCAD.Size = New System.Drawing.Size(55, 30)
        Me.txtUAHtoCAD.TabIndex = 49
        Me.txtUAHtoCAD.Text = "0.037"
        '
        'txtUAHtoUSD
        '
        Me.txtUAHtoUSD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUAHtoUSD.Location = New System.Drawing.Point(163, 264)
        Me.txtUAHtoUSD.MaxLength = 15
        Me.txtUAHtoUSD.Multiline = True
        Me.txtUAHtoUSD.Name = "txtUAHtoUSD"
        Me.txtUAHtoUSD.Size = New System.Drawing.Size(55, 30)
        Me.txtUAHtoUSD.TabIndex = 48
        Me.txtUAHtoUSD.Text = "0.027"
        '
        'txtEURtoBGN
        '
        Me.txtEURtoBGN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEURtoBGN.Location = New System.Drawing.Point(740, 222)
        Me.txtEURtoBGN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEURtoBGN.MaxLength = 15
        Me.txtEURtoBGN.Multiline = True
        Me.txtEURtoBGN.Name = "txtEURtoBGN"
        Me.txtEURtoBGN.Size = New System.Drawing.Size(55, 30)
        Me.txtEURtoBGN.TabIndex = 47
        Me.txtEURtoBGN.Text = "1.95"
        '
        'txtEURtoTRY
        '
        Me.txtEURtoTRY.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEURtoTRY.Location = New System.Drawing.Point(657, 220)
        Me.txtEURtoTRY.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEURtoTRY.MaxLength = 15
        Me.txtEURtoTRY.Multiline = True
        Me.txtEURtoTRY.Name = "txtEURtoTRY"
        Me.txtEURtoTRY.Size = New System.Drawing.Size(55, 30)
        Me.txtEURtoTRY.TabIndex = 46
        Me.txtEURtoTRY.Text = "19.98"
        '
        'txtEURtoPLN
        '
        Me.txtEURtoPLN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEURtoPLN.Location = New System.Drawing.Point(584, 221)
        Me.txtEURtoPLN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEURtoPLN.MaxLength = 15
        Me.txtEURtoPLN.Multiline = True
        Me.txtEURtoPLN.Name = "txtEURtoPLN"
        Me.txtEURtoPLN.Size = New System.Drawing.Size(55, 30)
        Me.txtEURtoPLN.TabIndex = 45
        Me.txtEURtoPLN.Text = "4.73"
        '
        'txtEURtoMDL
        '
        Me.txtEURtoMDL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEURtoMDL.Location = New System.Drawing.Point(497, 222)
        Me.txtEURtoMDL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEURtoMDL.MaxLength = 15
        Me.txtEURtoMDL.Multiline = True
        Me.txtEURtoMDL.Name = "txtEURtoMDL"
        Me.txtEURtoMDL.Size = New System.Drawing.Size(55, 30)
        Me.txtEURtoMDL.TabIndex = 44
        Me.txtEURtoMDL.Text = "20.23"
        '
        'txtEURtoUAH
        '
        Me.txtEURtoUAH.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEURtoUAH.Location = New System.Drawing.Point(415, 223)
        Me.txtEURtoUAH.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEURtoUAH.MaxLength = 15
        Me.txtEURtoUAH.Multiline = True
        Me.txtEURtoUAH.Name = "txtEURtoUAH"
        Me.txtEURtoUAH.Size = New System.Drawing.Size(55, 30)
        Me.txtEURtoUAH.TabIndex = 43
        Me.txtEURtoUAH.Text = "38.89"
        '
        'txtEURtoEUR
        '
        Me.txtEURtoEUR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEURtoEUR.Location = New System.Drawing.Point(328, 221)
        Me.txtEURtoEUR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEURtoEUR.MaxLength = 15
        Me.txtEURtoEUR.Multiline = True
        Me.txtEURtoEUR.Name = "txtEURtoEUR"
        Me.txtEURtoEUR.Size = New System.Drawing.Size(55, 30)
        Me.txtEURtoEUR.TabIndex = 42
        Me.txtEURtoEUR.Text = "1"
        '
        'txtEURtoCAD
        '
        Me.txtEURtoCAD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEURtoCAD.Location = New System.Drawing.Point(242, 221)
        Me.txtEURtoCAD.MaxLength = 15
        Me.txtEURtoCAD.Multiline = True
        Me.txtEURtoCAD.Name = "txtEURtoCAD"
        Me.txtEURtoCAD.Size = New System.Drawing.Size(55, 30)
        Me.txtEURtoCAD.TabIndex = 41
        Me.txtEURtoCAD.Text = "1.44"
        '
        'txtEURtoUSD
        '
        Me.txtEURtoUSD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEURtoUSD.Location = New System.Drawing.Point(163, 221)
        Me.txtEURtoUSD.MaxLength = 15
        Me.txtEURtoUSD.Multiline = True
        Me.txtEURtoUSD.Name = "txtEURtoUSD"
        Me.txtEURtoUSD.Size = New System.Drawing.Size(55, 30)
        Me.txtEURtoUSD.TabIndex = 40
        Me.txtEURtoUSD.Text = "1.06"
        '
        'txtCADtoBGN
        '
        Me.txtCADtoBGN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCADtoBGN.Location = New System.Drawing.Point(736, 176)
        Me.txtCADtoBGN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCADtoBGN.MaxLength = 15
        Me.txtCADtoBGN.Multiline = True
        Me.txtCADtoBGN.Name = "txtCADtoBGN"
        Me.txtCADtoBGN.Size = New System.Drawing.Size(55, 30)
        Me.txtCADtoBGN.TabIndex = 39
        Me.txtCADtoBGN.Text = "1.36"
        '
        'txtCADtoTRY
        '
        Me.txtCADtoTRY.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCADtoTRY.Location = New System.Drawing.Point(657, 178)
        Me.txtCADtoTRY.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCADtoTRY.MaxLength = 15
        Me.txtCADtoTRY.Multiline = True
        Me.txtCADtoTRY.Name = "txtCADtoTRY"
        Me.txtCADtoTRY.Size = New System.Drawing.Size(55, 30)
        Me.txtCADtoTRY.TabIndex = 38
        Me.txtCADtoTRY.Text = "13.91"
        '
        'txtCADtoPLN
        '
        Me.txtCADtoPLN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCADtoPLN.Location = New System.Drawing.Point(581, 176)
        Me.txtCADtoPLN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCADtoPLN.MaxLength = 15
        Me.txtCADtoPLN.Multiline = True
        Me.txtCADtoPLN.Name = "txtCADtoPLN"
        Me.txtCADtoPLN.Size = New System.Drawing.Size(55, 30)
        Me.txtCADtoPLN.TabIndex = 37
        Me.txtCADtoPLN.Text = "3.29"
        '
        'txtCADtoMDL
        '
        Me.txtCADtoMDL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCADtoMDL.Location = New System.Drawing.Point(494, 176)
        Me.txtCADtoMDL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCADtoMDL.MaxLength = 15
        Me.txtCADtoMDL.Multiline = True
        Me.txtCADtoMDL.Name = "txtCADtoMDL"
        Me.txtCADtoMDL.Size = New System.Drawing.Size(55, 30)
        Me.txtCADtoMDL.TabIndex = 36
        Me.txtCADtoMDL.Text = "13.86"
        '
        'txtCADtoUAH
        '
        Me.txtCADtoUAH.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCADtoUAH.Location = New System.Drawing.Point(412, 177)
        Me.txtCADtoUAH.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCADtoUAH.MaxLength = 15
        Me.txtCADtoUAH.Multiline = True
        Me.txtCADtoUAH.Name = "txtCADtoUAH"
        Me.txtCADtoUAH.Size = New System.Drawing.Size(55, 30)
        Me.txtCADtoUAH.TabIndex = 35
        Me.txtCADtoUAH.Text = "27.09"
        '
        'txtCADtoEUR
        '
        Me.txtCADtoEUR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCADtoEUR.Location = New System.Drawing.Point(326, 176)
        Me.txtCADtoEUR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCADtoEUR.MaxLength = 15
        Me.txtCADtoEUR.Multiline = True
        Me.txtCADtoEUR.Name = "txtCADtoEUR"
        Me.txtCADtoEUR.Size = New System.Drawing.Size(55, 30)
        Me.txtCADtoEUR.TabIndex = 34
        Me.txtCADtoEUR.Text = "0.70"
        '
        'txtUSDtoBGN
        '
        Me.txtUSDtoBGN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUSDtoBGN.Location = New System.Drawing.Point(736, 138)
        Me.txtUSDtoBGN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUSDtoBGN.MaxLength = 15
        Me.txtUSDtoBGN.Multiline = True
        Me.txtUSDtoBGN.Name = "txtUSDtoBGN"
        Me.txtUSDtoBGN.Size = New System.Drawing.Size(55, 30)
        Me.txtUSDtoBGN.TabIndex = 33
        Me.txtUSDtoBGN.Text = "1.85"
        '
        'txtUSDtoTRY
        '
        Me.txtUSDtoTRY.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUSDtoTRY.Location = New System.Drawing.Point(657, 137)
        Me.txtUSDtoTRY.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUSDtoTRY.MaxLength = 15
        Me.txtUSDtoTRY.Multiline = True
        Me.txtUSDtoTRY.Name = "txtUSDtoTRY"
        Me.txtUSDtoTRY.Size = New System.Drawing.Size(55, 30)
        Me.txtUSDtoTRY.TabIndex = 32
        Me.txtUSDtoTRY.Text = "18.88"
        '
        'txtUSDtoPLN
        '
        Me.txtUSDtoPLN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUSDtoPLN.Location = New System.Drawing.Point(581, 137)
        Me.txtUSDtoPLN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUSDtoPLN.MaxLength = 15
        Me.txtUSDtoPLN.Multiline = True
        Me.txtUSDtoPLN.Name = "txtUSDtoPLN"
        Me.txtUSDtoPLN.Size = New System.Drawing.Size(55, 30)
        Me.txtUSDtoPLN.TabIndex = 31
        Me.txtUSDtoPLN.Text = "4.47"
        '
        'txtUSDtoMDL
        '
        Me.txtUSDtoMDL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUSDtoMDL.Location = New System.Drawing.Point(494, 138)
        Me.txtUSDtoMDL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUSDtoMDL.MaxLength = 15
        Me.txtUSDtoMDL.Multiline = True
        Me.txtUSDtoMDL.Name = "txtUSDtoMDL"
        Me.txtUSDtoMDL.Size = New System.Drawing.Size(55, 30)
        Me.txtUSDtoMDL.TabIndex = 30
        Me.txtUSDtoMDL.Text = "18.80"
        '
        'txtUSDtoUAH
        '
        Me.txtUSDtoUAH.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUSDtoUAH.Location = New System.Drawing.Point(412, 139)
        Me.txtUSDtoUAH.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUSDtoUAH.MaxLength = 15
        Me.txtUSDtoUAH.Multiline = True
        Me.txtUSDtoUAH.Name = "txtUSDtoUAH"
        Me.txtUSDtoUAH.Size = New System.Drawing.Size(55, 30)
        Me.txtUSDtoUAH.TabIndex = 29
        Me.txtUSDtoUAH.Text = "36.74"
        '
        'txtUSDtoEUR
        '
        Me.txtUSDtoEUR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUSDtoEUR.Location = New System.Drawing.Point(326, 137)
        Me.txtUSDtoEUR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUSDtoEUR.MaxLength = 15
        Me.txtUSDtoEUR.Multiline = True
        Me.txtUSDtoEUR.Name = "txtUSDtoEUR"
        Me.txtUSDtoEUR.Size = New System.Drawing.Size(55, 30)
        Me.txtUSDtoEUR.TabIndex = 28
        Me.txtUSDtoEUR.Text = "0.95"
        '
        'txtBRLtoGBR
        '
        Me.txtBRLtoGBR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBRLtoGBR.Location = New System.Drawing.Point(86, 492)
        Me.txtBRLtoGBR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBRLtoGBR.MaxLength = 15
        Me.txtBRLtoGBR.Multiline = True
        Me.txtBRLtoGBR.Name = "txtBRLtoGBR"
        Me.txtBRLtoGBR.Size = New System.Drawing.Size(55, 30)
        Me.txtBRLtoGBR.TabIndex = 27
        Me.txtBRLtoGBR.Text = "0.16"
        '
        'txtBGNtoGBR
        '
        Me.txtBGNtoGBR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBGNtoGBR.Location = New System.Drawing.Point(86, 444)
        Me.txtBGNtoGBR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBGNtoGBR.MaxLength = 15
        Me.txtBGNtoGBR.Multiline = True
        Me.txtBGNtoGBR.Name = "txtBGNtoGBR"
        Me.txtBGNtoGBR.Size = New System.Drawing.Size(55, 30)
        Me.txtBGNtoGBR.TabIndex = 26
        Me.txtBGNtoGBR.Text = "0.45"
        '
        'txtTRYtoGBR
        '
        Me.txtTRYtoGBR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTRYtoGBR.Location = New System.Drawing.Point(88, 396)
        Me.txtTRYtoGBR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTRYtoGBR.MaxLength = 15
        Me.txtTRYtoGBR.Multiline = True
        Me.txtTRYtoGBR.Name = "txtTRYtoGBR"
        Me.txtTRYtoGBR.Size = New System.Drawing.Size(55, 30)
        Me.txtTRYtoGBR.TabIndex = 25
        Me.txtTRYtoGBR.Text = "0.044"
        '
        'txtPLNtoGBR
        '
        Me.txtPLNtoGBR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPLNtoGBR.Location = New System.Drawing.Point(86, 353)
        Me.txtPLNtoGBR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPLNtoGBR.MaxLength = 15
        Me.txtPLNtoGBR.Multiline = True
        Me.txtPLNtoGBR.Name = "txtPLNtoGBR"
        Me.txtPLNtoGBR.Size = New System.Drawing.Size(55, 30)
        Me.txtPLNtoGBR.TabIndex = 24
        Me.txtPLNtoGBR.Text = "0.19"
        '
        'txtMDLtoGBR
        '
        Me.txtMDLtoGBR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMDLtoGBR.Location = New System.Drawing.Point(86, 310)
        Me.txtMDLtoGBR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMDLtoGBR.MaxLength = 15
        Me.txtMDLtoGBR.Multiline = True
        Me.txtMDLtoGBR.Name = "txtMDLtoGBR"
        Me.txtMDLtoGBR.Size = New System.Drawing.Size(55, 30)
        Me.txtMDLtoGBR.TabIndex = 23
        Me.txtMDLtoGBR.Text = "0.044"
        '
        'txtUAHtoGBR
        '
        Me.txtUAHtoGBR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUAHtoGBR.Location = New System.Drawing.Point(88, 266)
        Me.txtUAHtoGBR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUAHtoGBR.MaxLength = 15
        Me.txtUAHtoGBR.Multiline = True
        Me.txtUAHtoGBR.Name = "txtUAHtoGBR"
        Me.txtUAHtoGBR.Size = New System.Drawing.Size(55, 30)
        Me.txtUAHtoGBR.TabIndex = 22
        Me.txtUAHtoGBR.Text = "0.023"
        '
        'pcbEUR2
        '
        Me.pcbEUR2.Image = Global.Exhanger_Unit_12.My.Resources.Resources.EUR
        Me.pcbEUR2.Location = New System.Drawing.Point(17, 222)
        Me.pcbEUR2.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbEUR2.Name = "pcbEUR2"
        Me.pcbEUR2.Size = New System.Drawing.Size(44, 28)
        Me.pcbEUR2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbEUR2.TabIndex = 21
        Me.pcbEUR2.TabStop = False
        '
        'pcbEUR1
        '
        Me.pcbEUR1.Image = Global.Exhanger_Unit_12.My.Resources.Resources.EUR
        Me.pcbEUR1.Location = New System.Drawing.Point(326, 41)
        Me.pcbEUR1.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbEUR1.Name = "pcbEUR1"
        Me.pcbEUR1.Size = New System.Drawing.Size(44, 28)
        Me.pcbEUR1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbEUR1.TabIndex = 20
        Me.pcbEUR1.TabStop = False
        '
        'pcbGBR2
        '
        Me.pcbGBR2.Image = Global.Exhanger_Unit_12.My.Resources.Resources.GBR
        Me.pcbGBR2.Location = New System.Drawing.Point(19, 85)
        Me.pcbGBR2.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbGBR2.Name = "pcbGBR2"
        Me.pcbGBR2.Size = New System.Drawing.Size(44, 28)
        Me.pcbGBR2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbGBR2.TabIndex = 19
        Me.pcbGBR2.TabStop = False
        '
        'pcbGBR1
        '
        Me.pcbGBR1.Image = Global.Exhanger_Unit_12.My.Resources.Resources.GBR
        Me.pcbGBR1.Location = New System.Drawing.Point(86, 41)
        Me.pcbGBR1.Margin = New System.Windows.Forms.Padding(2)
        Me.pcbGBR1.Name = "pcbGBR1"
        Me.pcbGBR1.Size = New System.Drawing.Size(44, 28)
        Me.pcbGBR1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbGBR1.TabIndex = 18
        Me.pcbGBR1.TabStop = False
        '
        'txtGBRtoBGN
        '
        Me.txtGBRtoBGN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGBRtoBGN.Location = New System.Drawing.Point(740, 84)
        Me.txtGBRtoBGN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtGBRtoBGN.MaxLength = 15
        Me.txtGBRtoBGN.Multiline = True
        Me.txtGBRtoBGN.Name = "txtGBRtoBGN"
        Me.txtGBRtoBGN.Size = New System.Drawing.Size(55, 30)
        Me.txtGBRtoBGN.TabIndex = 17
        Me.txtGBRtoBGN.Text = "2.21"
        '
        'txtGBRtoTRY
        '
        Me.txtGBRtoTRY.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGBRtoTRY.Location = New System.Drawing.Point(657, 82)
        Me.txtGBRtoTRY.Margin = New System.Windows.Forms.Padding(2)
        Me.txtGBRtoTRY.MaxLength = 15
        Me.txtGBRtoTRY.Multiline = True
        Me.txtGBRtoTRY.Name = "txtGBRtoTRY"
        Me.txtGBRtoTRY.Size = New System.Drawing.Size(55, 30)
        Me.txtGBRtoTRY.TabIndex = 16
        Me.txtGBRtoTRY.Text = "22.63"
        '
        'txtGBPtoPLN
        '
        Me.txtGBPtoPLN.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGBPtoPLN.Location = New System.Drawing.Point(584, 84)
        Me.txtGBPtoPLN.Margin = New System.Windows.Forms.Padding(2)
        Me.txtGBPtoPLN.MaxLength = 15
        Me.txtGBPtoPLN.Multiline = True
        Me.txtGBPtoPLN.Name = "txtGBPtoPLN"
        Me.txtGBPtoPLN.Size = New System.Drawing.Size(55, 30)
        Me.txtGBPtoPLN.TabIndex = 15
        Me.txtGBPtoPLN.Text = "5.36"
        '
        'txtGBPtoMDL
        '
        Me.txtGBPtoMDL.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGBPtoMDL.Location = New System.Drawing.Point(497, 84)
        Me.txtGBPtoMDL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtGBPtoMDL.MaxLength = 15
        Me.txtGBPtoMDL.Multiline = True
        Me.txtGBPtoMDL.Name = "txtGBPtoMDL"
        Me.txtGBPtoMDL.Size = New System.Drawing.Size(55, 30)
        Me.txtGBPtoMDL.TabIndex = 14
        Me.txtGBPtoMDL.Text = "22.91"
        '
        'txtGBPtoUAH
        '
        Me.txtGBPtoUAH.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGBPtoUAH.Location = New System.Drawing.Point(415, 85)
        Me.txtGBPtoUAH.Margin = New System.Windows.Forms.Padding(2)
        Me.txtGBPtoUAH.MaxLength = 15
        Me.txtGBPtoUAH.Multiline = True
        Me.txtGBPtoUAH.Name = "txtGBPtoUAH"
        Me.txtGBPtoUAH.Size = New System.Drawing.Size(55, 30)
        Me.txtGBPtoUAH.TabIndex = 13
        Me.txtGBPtoUAH.Text = "44.09"
        '
        'txtGBPtoEUR
        '
        Me.txtGBPtoEUR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGBPtoEUR.Location = New System.Drawing.Point(328, 84)
        Me.txtGBPtoEUR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtGBPtoEUR.MaxLength = 15
        Me.txtGBPtoEUR.Multiline = True
        Me.txtGBPtoEUR.Name = "txtGBPtoEUR"
        Me.txtGBPtoEUR.Size = New System.Drawing.Size(55, 30)
        Me.txtGBPtoEUR.TabIndex = 12
        Me.txtGBPtoEUR.Text = "1.13"
        '
        'txtEURtoGBR
        '
        Me.txtEURtoGBR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEURtoGBR.Location = New System.Drawing.Point(86, 223)
        Me.txtEURtoGBR.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEURtoGBR.MaxLength = 15
        Me.txtEURtoGBR.Multiline = True
        Me.txtEURtoGBR.Name = "txtEURtoGBR"
        Me.txtEURtoGBR.Size = New System.Drawing.Size(55, 30)
        Me.txtEURtoGBR.TabIndex = 11
        Me.txtEURtoGBR.Text = "0.88"
        '
        'btnCloseRate
        '
        Me.btnCloseRate.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnCloseRate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCloseRate.Font = New System.Drawing.Font("Nirmala UI", 28.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCloseRate.Location = New System.Drawing.Point(372, 538)
        Me.btnCloseRate.Name = "btnCloseRate"
        Me.btnCloseRate.Size = New System.Drawing.Size(148, 64)
        Me.btnCloseRate.TabIndex = 2
        Me.btnCloseRate.Text = "Close"
        Me.btnCloseRate.UseVisualStyleBackColor = False
        '
        'txtCADtoCAD
        '
        Me.txtCADtoCAD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCADtoCAD.Location = New System.Drawing.Point(239, 176)
        Me.txtCADtoCAD.MaxLength = 15
        Me.txtCADtoCAD.Multiline = True
        Me.txtCADtoCAD.Name = "txtCADtoCAD"
        Me.txtCADtoCAD.Size = New System.Drawing.Size(55, 30)
        Me.txtCADtoCAD.TabIndex = 10
        Me.txtCADtoCAD.Text = "1"
        '
        'txtCADtoUSD
        '
        Me.txtCADtoUSD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCADtoUSD.Location = New System.Drawing.Point(160, 176)
        Me.txtCADtoUSD.MaxLength = 15
        Me.txtCADtoUSD.Multiline = True
        Me.txtCADtoUSD.Name = "txtCADtoUSD"
        Me.txtCADtoUSD.Size = New System.Drawing.Size(55, 30)
        Me.txtCADtoUSD.TabIndex = 9
        Me.txtCADtoUSD.Text = "0.74"
        '
        'txtCADtoGBR
        '
        Me.txtCADtoGBR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCADtoGBR.Location = New System.Drawing.Point(88, 176)
        Me.txtCADtoGBR.MaxLength = 15
        Me.txtCADtoGBR.Multiline = True
        Me.txtCADtoGBR.Name = "txtCADtoGBR"
        Me.txtCADtoGBR.Size = New System.Drawing.Size(55, 30)
        Me.txtCADtoGBR.TabIndex = 8
        Me.txtCADtoGBR.Text = "0.61"
        '
        'txtUSDtoCAD
        '
        Me.txtUSDtoCAD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUSDtoCAD.Location = New System.Drawing.Point(239, 137)
        Me.txtUSDtoCAD.MaxLength = 15
        Me.txtUSDtoCAD.Multiline = True
        Me.txtUSDtoCAD.Name = "txtUSDtoCAD"
        Me.txtUSDtoCAD.Size = New System.Drawing.Size(55, 30)
        Me.txtUSDtoCAD.TabIndex = 7
        Me.txtUSDtoCAD.Text = "1.36"
        '
        'txtUSDtoUSD
        '
        Me.txtUSDtoUSD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUSDtoUSD.Location = New System.Drawing.Point(160, 135)
        Me.txtUSDtoUSD.MaxLength = 15
        Me.txtUSDtoUSD.Multiline = True
        Me.txtUSDtoUSD.Name = "txtUSDtoUSD"
        Me.txtUSDtoUSD.Size = New System.Drawing.Size(55, 30)
        Me.txtUSDtoUSD.TabIndex = 6
        Me.txtUSDtoUSD.Text = "1"
        '
        'txtUSDtoGBR
        '
        Me.txtUSDtoGBR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUSDtoGBR.Location = New System.Drawing.Point(89, 135)
        Me.txtUSDtoGBR.MaxLength = 15
        Me.txtUSDtoGBR.Multiline = True
        Me.txtUSDtoGBR.Name = "txtUSDtoGBR"
        Me.txtUSDtoGBR.Size = New System.Drawing.Size(55, 30)
        Me.txtUSDtoGBR.TabIndex = 5
        Me.txtUSDtoGBR.Text = "0.83"
        Me.txtUSDtoGBR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtGBPtoCAD
        '
        Me.txtGBPtoCAD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGBPtoCAD.Location = New System.Drawing.Point(239, 84)
        Me.txtGBPtoCAD.MaxLength = 15
        Me.txtGBPtoCAD.Multiline = True
        Me.txtGBPtoCAD.Name = "txtGBPtoCAD"
        Me.txtGBPtoCAD.Size = New System.Drawing.Size(55, 30)
        Me.txtGBPtoCAD.TabIndex = 4
        Me.txtGBPtoCAD.Text = "1.63"
        '
        'txtGBPtoUSD
        '
        Me.txtGBPtoUSD.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGBPtoUSD.Location = New System.Drawing.Point(160, 84)
        Me.txtGBPtoUSD.MaxLength = 15
        Me.txtGBPtoUSD.Multiline = True
        Me.txtGBPtoUSD.Name = "txtGBPtoUSD"
        Me.txtGBPtoUSD.Size = New System.Drawing.Size(55, 30)
        Me.txtGBPtoUSD.TabIndex = 3
        Me.txtGBPtoUSD.Text = "1.20"
        '
        'txtGBPtoGBR
        '
        Me.txtGBPtoGBR.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGBPtoGBR.Location = New System.Drawing.Point(88, 84)
        Me.txtGBPtoGBR.MaxLength = 15
        Me.txtGBPtoGBR.Multiline = True
        Me.txtGBPtoGBR.Name = "txtGBPtoGBR"
        Me.txtGBPtoGBR.Size = New System.Drawing.Size(55, 30)
        Me.txtGBPtoGBR.TabIndex = 1
        Me.txtGBPtoGBR.Text = "1"
        '
        'pnlFAQ
        '
        Me.pnlFAQ.Controls.Add(Me.txtCountriesCurrencies)
        Me.pnlFAQ.Controls.Add(Me.PictureBox1)
        Me.pnlFAQ.Controls.Add(Me.txtTextForFAQ)
        Me.pnlFAQ.Controls.Add(Me.lblTextToFAQ)
        Me.pnlFAQ.Controls.Add(Me.btnCloseFAQ)
        Me.pnlFAQ.Location = New System.Drawing.Point(1, -4)
        Me.pnlFAQ.Name = "pnlFAQ"
        Me.pnlFAQ.Size = New System.Drawing.Size(898, 613)
        Me.pnlFAQ.TabIndex = 13
        Me.pnlFAQ.Visible = False
        '
        'txtCountriesCurrencies
        '
        Me.txtCountriesCurrencies.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.txtCountriesCurrencies.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCountriesCurrencies.Font = New System.Drawing.Font("Nirmala UI", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCountriesCurrencies.Location = New System.Drawing.Point(434, 127)
        Me.txtCountriesCurrencies.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCountriesCurrencies.Multiline = True
        Me.txtCountriesCurrencies.Name = "txtCountriesCurrencies"
        Me.txtCountriesCurrencies.ReadOnly = True
        Me.txtCountriesCurrencies.Size = New System.Drawing.Size(448, 384)
        Me.txtCountriesCurrencies.TabIndex = 5
        Me.txtCountriesCurrencies.Text = resources.GetString("txtCountriesCurrencies.Text")
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Exhanger_Unit_12.My.Resources.Resources.FAQ
        Me.PictureBox1.Location = New System.Drawing.Point(375, 9)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(130, 110)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'txtTextForFAQ
        '
        Me.txtTextForFAQ.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.txtTextForFAQ.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtTextForFAQ.Font = New System.Drawing.Font("Nirmala UI", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTextForFAQ.Location = New System.Drawing.Point(17, 105)
        Me.txtTextForFAQ.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTextForFAQ.Multiline = True
        Me.txtTextForFAQ.Name = "txtTextForFAQ"
        Me.txtTextForFAQ.ReadOnly = True
        Me.txtTextForFAQ.Size = New System.Drawing.Size(429, 412)
        Me.txtTextForFAQ.TabIndex = 3
        Me.txtTextForFAQ.Text = resources.GetString("txtTextForFAQ.Text")
        '
        'lblTextToFAQ
        '
        Me.lblTextToFAQ.AutoSize = True
        Me.lblTextToFAQ.Font = New System.Drawing.Font("Microsoft Sans Serif", 28.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTextToFAQ.Location = New System.Drawing.Point(-254, 224)
        Me.lblTextToFAQ.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTextToFAQ.Name = "lblTextToFAQ"
        Me.lblTextToFAQ.Size = New System.Drawing.Size(0, 44)
        Me.lblTextToFAQ.TabIndex = 2
        '
        'btnCloseFAQ
        '
        Me.btnCloseFAQ.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnCloseFAQ.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnCloseFAQ.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCloseFAQ.Font = New System.Drawing.Font("Nirmala UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCloseFAQ.Location = New System.Drawing.Point(364, 520)
        Me.btnCloseFAQ.Name = "btnCloseFAQ"
        Me.btnCloseFAQ.Size = New System.Drawing.Size(158, 85)
        Me.btnCloseFAQ.TabIndex = 0
        Me.btnCloseFAQ.Text = "Close"
        Me.btnCloseFAQ.UseVisualStyleBackColor = False
        '
        'pcbCurrencyFrom
        '
        Me.pcbCurrencyFrom.Location = New System.Drawing.Point(276, 169)
        Me.pcbCurrencyFrom.Name = "pcbCurrencyFrom"
        Me.pcbCurrencyFrom.Size = New System.Drawing.Size(76, 52)
        Me.pcbCurrencyFrom.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbCurrencyFrom.TabIndex = 15
        Me.pcbCurrencyFrom.TabStop = False
        '
        'pcbCurrencyTo
        '
        Me.pcbCurrencyTo.Location = New System.Drawing.Point(276, 320)
        Me.pcbCurrencyTo.Name = "pcbCurrencyTo"
        Me.pcbCurrencyTo.Size = New System.Drawing.Size(76, 53)
        Me.pcbCurrencyTo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbCurrencyTo.TabIndex = 14
        Me.pcbCurrencyTo.TabStop = False
        '
        'pcbLogoExchanger
        '
        Me.pcbLogoExchanger.Image = Global.Exhanger_Unit_12.My.Resources.Resources.Logo
        Me.pcbLogoExchanger.Location = New System.Drawing.Point(189, 11)
        Me.pcbLogoExchanger.Name = "pcbLogoExchanger"
        Me.pcbLogoExchanger.Size = New System.Drawing.Size(96, 84)
        Me.pcbLogoExchanger.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbLogoExchanger.TabIndex = 0
        Me.pcbLogoExchanger.TabStop = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(902, 610)
        Me.Controls.Add(Me.pnlRates)
        Me.Controls.Add(Me.pnlFAQ)
        Me.Controls.Add(Me.txtConvertTo)
        Me.Controls.Add(Me.txtConvertFrom)
        Me.Controls.Add(Me.btnFAQ)
        Me.Controls.Add(Me.btnConvert)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnRates)
        Me.Controls.Add(Me.cboCurrencyTo)
        Me.Controls.Add(Me.cboCurrencyFrom)
        Me.Controls.Add(Me.lblTo)
        Me.Controls.Add(Me.lblFrom)
        Me.Controls.Add(Me.lblTitleForMain)
        Me.Controls.Add(Me.pcbLogoExchanger)
        Me.Controls.Add(Me.pcbCurrencyFrom)
        Me.Controls.Add(Me.pcbCurrencyTo)
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main program"
        Me.pnlRates.ResumeLayout(False)
        Me.pnlRates.PerformLayout()
        CType(Me.pcbBRL2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbBRL1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbTRY2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbBGN2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbBGN1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbTRY1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbPLN2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbPLN1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbMDL2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbMDL1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbUAH2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbUAH1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbCAD2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbCAD1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbUSD2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbUSD1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbEUR2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbEUR1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbGBR2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbGBR1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlFAQ.ResumeLayout(False)
        Me.pnlFAQ.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbCurrencyFrom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbCurrencyTo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbLogoExchanger, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pcbLogoExchanger As PictureBox
    Friend WithEvents lblTitleForMain As Label
    Friend WithEvents lblFrom As Label
    Friend WithEvents lblTo As Label
    Friend WithEvents cboCurrencyFrom As ComboBox
    Friend WithEvents cboCurrencyTo As ComboBox
    Friend WithEvents btnRates As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnConvert As Button
    Friend WithEvents btnFAQ As Button
    Friend WithEvents txtConvertFrom As TextBox
    Friend WithEvents txtConvertTo As TextBox
    Friend WithEvents pnlRates As Panel
    Friend WithEvents txtGBPtoGBR As TextBox
    Friend WithEvents btnCloseRate As Button
    Friend WithEvents txtGBPtoCAD As TextBox
    Friend WithEvents txtGBPtoUSD As TextBox
    Friend WithEvents txtCADtoCAD As TextBox
    Friend WithEvents txtCADtoUSD As TextBox
    Friend WithEvents txtCADtoGBR As TextBox
    Friend WithEvents txtUSDtoCAD As TextBox
    Friend WithEvents txtUSDtoUSD As TextBox
    Friend WithEvents txtUSDtoGBR As TextBox
    Friend WithEvents pnlFAQ As Panel
    Friend WithEvents btnCloseFAQ As Button
    Friend WithEvents lblTextToFAQ As Label
    Friend WithEvents txtTextForFAQ As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txtGBRtoBGN As TextBox
    Friend WithEvents txtGBRtoTRY As TextBox
    Friend WithEvents txtGBPtoPLN As TextBox
    Friend WithEvents txtGBPtoMDL As TextBox
    Friend WithEvents txtGBPtoUAH As TextBox
    Friend WithEvents txtGBPtoEUR As TextBox
    Friend WithEvents txtEURtoGBR As TextBox
    Friend WithEvents pcbGBR1 As PictureBox
    Friend WithEvents pcbGBR2 As PictureBox
    Friend WithEvents pcbEUR1 As PictureBox
    Friend WithEvents pcbEUR2 As PictureBox
    Friend WithEvents txtBGNtoGBR As TextBox
    Friend WithEvents txtTRYtoGBR As TextBox
    Friend WithEvents txtPLNtoGBR As TextBox
    Friend WithEvents txtMDLtoGBR As TextBox
    Friend WithEvents txtUAHtoGBR As TextBox
    Friend WithEvents pcbUSD1 As PictureBox
    Friend WithEvents txtBRLtoBGN As TextBox
    Friend WithEvents txtBRLtoTRY As TextBox
    Friend WithEvents txtBRLtoPLN As TextBox
    Friend WithEvents txtBRLtoMDL As TextBox
    Friend WithEvents txtBRLtoUAH As TextBox
    Friend WithEvents txtBRLtoEUR As TextBox
    Friend WithEvents txtBRLtoCAD As TextBox
    Friend WithEvents txtBRLtoUSD As TextBox
    Friend WithEvents txtBGNtoBGN As TextBox
    Friend WithEvents txtBGNtoTRY As TextBox
    Friend WithEvents txtBGNtoPLN As TextBox
    Friend WithEvents txtBGNtoMDL As TextBox
    Friend WithEvents txtBGNtoUAH As TextBox
    Friend WithEvents txtBGNtoEUR As TextBox
    Friend WithEvents txtBGNtoCAD As TextBox
    Friend WithEvents txtBGNtoUSD As TextBox
    Friend WithEvents txtTRYtoBGN As TextBox
    Friend WithEvents txtTRYtoTRY As TextBox
    Friend WithEvents txtTRYtoPLN As TextBox
    Friend WithEvents txtTRYtoMDL As TextBox
    Friend WithEvents txtTRYtoUAH As TextBox
    Friend WithEvents txtTRYtoEUR As TextBox
    Friend WithEvents txtTRYtoCAD As TextBox
    Friend WithEvents txtTRYtoUSD As TextBox
    Friend WithEvents txtPLNtoBGN As TextBox
    Friend WithEvents txtPLNtoTRY As TextBox
    Friend WithEvents txtPLNtoPLN As TextBox
    Friend WithEvents txtPLNtoMDL As TextBox
    Friend WithEvents txtPLNtoUAH As TextBox
    Friend WithEvents txtPLNtoEUR As TextBox
    Friend WithEvents txtPLNtoCAD As TextBox
    Friend WithEvents txtPLNtoUSD As TextBox
    Friend WithEvents txtMDLtoBGN As TextBox
    Friend WithEvents txtMDLtoTRY As TextBox
    Friend WithEvents txtMDLtoPLN As TextBox
    Friend WithEvents txtMDLtoMDL As TextBox
    Friend WithEvents txtMDLtoUAH As TextBox
    Friend WithEvents txtMDLtoEUR As TextBox
    Friend WithEvents txtMDLtoCAD As TextBox
    Friend WithEvents txtMDLtoUSD As TextBox
    Friend WithEvents txtUAHtoBGN As TextBox
    Friend WithEvents txtUAHtoTRY As TextBox
    Friend WithEvents txtUAHtoPLN As TextBox
    Friend WithEvents txtUAHtoMDL As TextBox
    Friend WithEvents txtUAHtoUAH As TextBox
    Friend WithEvents txtUAHtoEUR As TextBox
    Friend WithEvents txtUAHtoCAD As TextBox
    Friend WithEvents txtUAHtoUSD As TextBox
    Friend WithEvents txtEURtoBGN As TextBox
    Friend WithEvents txtEURtoTRY As TextBox
    Friend WithEvents txtEURtoMDL As TextBox
    Friend WithEvents txtEURtoUAH As TextBox
    Friend WithEvents txtEURtoEUR As TextBox
    Friend WithEvents txtEURtoCAD As TextBox
    Friend WithEvents txtEURtoUSD As TextBox
    Friend WithEvents txtCADtoBGN As TextBox
    Friend WithEvents txtCADtoTRY As TextBox
    Friend WithEvents txtCADtoPLN As TextBox
    Friend WithEvents txtCADtoMDL As TextBox
    Friend WithEvents txtCADtoUAH As TextBox
    Friend WithEvents txtCADtoEUR As TextBox
    Friend WithEvents txtUSDtoBGN As TextBox
    Friend WithEvents txtUSDtoTRY As TextBox
    Friend WithEvents txtUSDtoPLN As TextBox
    Friend WithEvents txtUSDtoMDL As TextBox
    Friend WithEvents txtUSDtoUAH As TextBox
    Friend WithEvents txtUSDtoEUR As TextBox
    Friend WithEvents txtBRLtoGBR As TextBox
    Friend WithEvents pcbCAD1 As PictureBox
    Friend WithEvents pcbUSD2 As PictureBox
    Friend WithEvents pcbUAH1 As PictureBox
    Friend WithEvents pcbCAD2 As PictureBox
    Friend WithEvents pcbMDL1 As PictureBox
    Friend WithEvents pcbUAH2 As PictureBox
    Friend WithEvents pcbPLN1 As PictureBox
    Friend WithEvents pcbMDL2 As PictureBox
    Friend WithEvents pcbTRY1 As PictureBox
    Friend WithEvents pcbPLN2 As PictureBox
    Friend WithEvents txtBRLtoBRL As TextBox
    Friend WithEvents txtBGNtoBRL As TextBox
    Friend WithEvents txtTRYtoBRL As TextBox
    Friend WithEvents txtPLNtoBRL As TextBox
    Friend WithEvents txtMDLtoBRL As TextBox
    Friend WithEvents txtUAHtoBRL As TextBox
    Friend WithEvents txtEURtoBRL As TextBox
    Friend WithEvents txtCADtoBRL As TextBox
    Friend WithEvents txtUSDtoBRL As TextBox
    Friend WithEvents txtGBRtoBRL As TextBox
    Friend WithEvents pcbBGN1 As PictureBox
    Friend WithEvents pcbTRY2 As PictureBox
    Friend WithEvents pcbBGN2 As PictureBox
    Friend WithEvents pcbBRL1 As PictureBox
    Friend WithEvents lblBRL As Label
    Friend WithEvents lblBGN As Label
    Friend WithEvents lblTRY As Label
    Friend WithEvents lblPLN As Label
    Friend WithEvents lblMDL As Label
    Friend WithEvents lblUAH As Label
    Friend WithEvents lblEUR As Label
    Friend WithEvents lblCAD As Label
    Friend WithEvents lblUSD As Label
    Friend WithEvents lblGBP As Label
    Friend WithEvents pcbBRL2 As PictureBox
    Friend WithEvents txtEURtoPLN As TextBox
    Friend WithEvents txtCountriesCurrencies As TextBox
    Friend WithEvents pcbCurrencyTo As PictureBox
    Friend WithEvents pcbCurrencyFrom As PictureBox
End Class
