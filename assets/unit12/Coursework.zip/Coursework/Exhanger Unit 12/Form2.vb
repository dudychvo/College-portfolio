﻿Public Class Form2
    'Decrate all local variables
    Dim amountToConvert As Double
    Dim amountToRecieve As Double
    Dim rate As Double

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        If (txtConvertFrom.Text = "") Then
            'Check if the amount field is empty; if yes show a message box with an error
            MsgBox("Please enter amonut of money you want to convert")

        ElseIf (cboCurrencyFrom.SelectedIndex = 0 And cboCurrencyTo.SelectedIndex = 0) Then
            'Convering from GBR to GBR
            MsgBox("Please choose proper currencies")

        ElseIf (cboCurrencyFrom.SelectedIndex = 0 And cboCurrencyTo.SelectedIndex = 1) Then
            'Converting from GBR to USD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            'Converting the text from the textbox into the double(number)
            rate = Val(txtGBPtoUSD.Text)
            'Converting the text from the rate textbox
            amountToRecieve = amountToConvert * rate
            'Calcuate the amount to convert by the rate
            txtConvertTo.Text = "$" & amountToRecieve
            'Display the converted amount with the symbol in the textbox

        ElseIf (cboCurrencyFrom.SelectedIndex = 0 And cboCurrencyTo.SelectedIndex = 2) Then
            'Converting from GBR to CAD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtGBPtoCAD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "C$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 0 And cboCurrencyTo.SelectedIndex = 3) Then
            'Converting from GBR to EUR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtGBPtoEUR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "€" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 0 And cboCurrencyTo.SelectedIndex = 4) Then
            'Converting from GBR to UAH
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtGBPtoUAH.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₴" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 0 And cboCurrencyTo.SelectedIndex = 5) Then
            'Converting from GBR to MDL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtGBPtoMDL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "L" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 0 And cboCurrencyTo.SelectedIndex = 6) Then
            'Converting from GBR to PLN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtGBPtoPLN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "zł" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 0 And cboCurrencyTo.SelectedIndex = 7) Then
            'Converting from GBR to TRY
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtGBRtoTRY.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₺" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 0 And cboCurrencyTo.SelectedIndex = 8) Then
            'Converting from GBR to BGN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtGBRtoBGN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "Лв." & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 0 And cboCurrencyTo.SelectedIndex = 9) Then
            'Converting from GBR to BRL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtGBRtoBRL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "R$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 1 And cboCurrencyTo.SelectedIndex = 0) Then
            'Converting from USD to GBR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUSDtoGBR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "£" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 1 And cboCurrencyTo.SelectedIndex = 1) Then
            'Convering from USD to USD
            MsgBox("Please choose proper currencies")

        ElseIf (cboCurrencyFrom.SelectedIndex = 1 And cboCurrencyTo.SelectedIndex = 2) Then
            'Converting from USD to CAD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUSDtoCAD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "C$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 1 And cboCurrencyTo.SelectedIndex = 3) Then
            'Converting from USD to EUR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUSDtoEUR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "€" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 1 And cboCurrencyTo.SelectedIndex = 4) Then
            'Converting from USD to UAH
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUSDtoUAH.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₴" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 1 And cboCurrencyTo.SelectedIndex = 5) Then
            'Converting from USD to MDL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUSDtoMDL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "L" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 1 And cboCurrencyTo.SelectedIndex = 6) Then
            'Converting from USD to PLN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUSDtoPLN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "zł" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 1 And cboCurrencyTo.SelectedIndex = 7) Then
            'Converting from USD to TRY
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUSDtoTRY.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₺" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 1 And cboCurrencyTo.SelectedIndex = 8) Then
            'Converting from USD to BGN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUSDtoBGN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "Лв." & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 1 And cboCurrencyTo.SelectedIndex = 9) Then
            'Converting from USD to BRL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUSDtoBRL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "R$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 2 And cboCurrencyTo.SelectedIndex = 0) Then
            'Convering from CAD to GBR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtCADtoGBR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "£" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 2 And cboCurrencyTo.SelectedIndex = 1) Then
            'Converting from CAD to USD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtCADtoUSD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 2 And cboCurrencyTo.SelectedIndex = 2) Then
            'Converting from CAD to CAD
            MsgBox("Please choose proper currencies")

        ElseIf (cboCurrencyFrom.SelectedIndex = 2 And cboCurrencyTo.SelectedIndex = 3) Then
            'Converting from CAD to EUR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtCADtoEUR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "€" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 2 And cboCurrencyTo.SelectedIndex = 4) Then
            'Converting from CAD to UAH
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtCADtoUAH.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₴" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 2 And cboCurrencyTo.SelectedIndex = 5) Then
            'Converting from CAD to MDL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtCADtoMDL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "L" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 2 And cboCurrencyTo.SelectedIndex = 6) Then
            'Converting from CAD to PLN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtCADtoPLN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "zł" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 2 And cboCurrencyTo.SelectedIndex = 7) Then
            'Converting from CAD to TRY
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtCADtoTRY.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₺" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 2 And cboCurrencyTo.SelectedIndex = 8) Then
            'Converting from CAD to BGN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtCADtoBGN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "Лв." & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 2 And cboCurrencyTo.SelectedIndex = 9) Then
            'Converting from CAD to BRL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtCADtoBRL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "R$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 3 And cboCurrencyTo.SelectedIndex = 0) Then
            'Converting from EUR to GBR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtEURtoGBR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "£" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 3 And cboCurrencyTo.SelectedIndex = 1) Then
            'Converting from EUR to USD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtEURtoUSD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 3 And cboCurrencyTo.SelectedIndex = 2) Then
            'Converting from EUR to CAD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtEURtoCAD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "C$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 3 And cboCurrencyTo.SelectedIndex = 3) Then
            'Converting from EUR to EUR
            MsgBox("Please choose proper currencies")

        ElseIf (cboCurrencyFrom.SelectedIndex = 3 And cboCurrencyTo.SelectedIndex = 4) Then
            'Converting from EUR to UAH
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtEURtoUAH.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₴" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 3 And cboCurrencyTo.SelectedIndex = 5) Then
            'Converting from EUR to MDL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtEURtoMDL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "L" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 3 And cboCurrencyTo.SelectedIndex = 6) Then
            'Converting from EUR to PLN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtEURtoPLN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "zł" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 3 And cboCurrencyTo.SelectedIndex = 7) Then
            'Converting from EUR to TRY
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtEURtoTRY.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₺" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 3 And cboCurrencyTo.SelectedIndex = 8) Then
            'Converting from EUR to BGN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtEURtoBGN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "Лв." & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 3 And cboCurrencyTo.SelectedIndex = 9) Then
            'Converting from EUR to BRL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtEURtoBRL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "R$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 4 And cboCurrencyTo.SelectedIndex = 0) Then
            'Converting from UAH to GBR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUAHtoGBR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "£" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 4 And cboCurrencyTo.SelectedIndex = 1) Then
            'Converting from UAH to USD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUAHtoUSD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 4 And cboCurrencyTo.SelectedIndex = 2) Then
            'Converting from UAH to CAD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUAHtoCAD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "C$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 4 And cboCurrencyTo.SelectedIndex = 3) Then
            'Converting from UAH to EUR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUAHtoEUR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "€" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 4 And cboCurrencyTo.SelectedIndex = 4) Then
            'Converting from UAH to UAH
            MsgBox("Please choose proper currencies")

        ElseIf (cboCurrencyFrom.SelectedIndex = 4 And cboCurrencyTo.SelectedIndex = 5) Then
            'Converting from UAH to MDL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUAHtoMDL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "L" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 4 And cboCurrencyTo.SelectedIndex = 6) Then
            'Converting from UAH to PLN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUAHtoPLN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "zł" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 4 And cboCurrencyTo.SelectedIndex = 7) Then
            'Converting from UAH to TRY
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUAHtoTRY.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₺" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 4 And cboCurrencyTo.SelectedIndex = 8) Then
            'Converting from UAH to BGN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUAHtoBGN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "Лв." & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 4 And cboCurrencyTo.SelectedIndex = 9) Then
            'Converting from UAH to BRL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtUAHtoBRL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "R$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 5 And cboCurrencyTo.SelectedIndex = 0) Then
            'Converting from MDL to GBR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtMDLtoGBR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "£" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 5 And cboCurrencyTo.SelectedIndex = 1) Then
            'Converting from MDL to USD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtMDLtoUSD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 5 And cboCurrencyTo.SelectedIndex = 2) Then
            'Converting from MDL to CAD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtMDLtoCAD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "C$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 5 And cboCurrencyTo.SelectedIndex = 3) Then
            'Converting from MDL to EUR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtMDLtoEUR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "€" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 5 And cboCurrencyTo.SelectedIndex = 4) Then
            'Converting from MDL to UAH
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtMDLtoUAH.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₴" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 5 And cboCurrencyTo.SelectedIndex = 5) Then
            'Converting from MDL to MDL
            MsgBox("Please choose proper currencies")

        ElseIf (cboCurrencyFrom.SelectedIndex = 5 And cboCurrencyTo.SelectedIndex = 6) Then
            'Converting from MDL to PLN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtMDLtoPLN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "zł" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 5 And cboCurrencyTo.SelectedIndex = 7) Then
            'Converting from MDL to TRY
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtMDLtoTRY.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₺" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 5 And cboCurrencyTo.SelectedIndex = 8) Then
            'Converting from MDL to BGN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtMDLtoBGN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "Лв." & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 5 And cboCurrencyTo.SelectedIndex = 9) Then
            'Converting from MDL to BRL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtMDLtoBRL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "R$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 6 And cboCurrencyTo.SelectedIndex = 0) Then
            'Converting from PLN to GBR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtPLNtoGBR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "£" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 6 And cboCurrencyTo.SelectedIndex = 1) Then
            'Converting from PLN to USD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtPLNtoUSD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 6 And cboCurrencyTo.SelectedIndex = 2) Then
            'Converting from PLN to CAD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtPLNtoCAD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "C$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 6 And cboCurrencyTo.SelectedIndex = 3) Then
            'Converting from PLN to EUR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtPLNtoEUR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "€" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 6 And cboCurrencyTo.SelectedIndex = 4) Then
            'Converting from PLN to UAH
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtPLNtoUAH.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₴" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 6 And cboCurrencyTo.SelectedIndex = 5) Then
            'Converting from PLN to MDL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtPLNtoMDL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "L" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 6 And cboCurrencyTo.SelectedIndex = 6) Then
            'Converting from PLN to PLN
            MsgBox("Please choose proper currencies")

        ElseIf (cboCurrencyFrom.SelectedIndex = 6 And cboCurrencyTo.SelectedIndex = 7) Then
            'Converting from PLN to TRY
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtPLNtoTRY.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₺" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 6 And cboCurrencyTo.SelectedIndex = 8) Then
            'Converting from PLN to BGN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtPLNtoBGN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "Лв." & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 6 And cboCurrencyTo.SelectedIndex = 9) Then
            'Converting from PLN to BRL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtPLNtoBRL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "R$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 7 And cboCurrencyTo.SelectedIndex = 0) Then
            'Converting from TRY to GBR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtTRYtoGBR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "£" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 7 And cboCurrencyTo.SelectedIndex = 1) Then
            'Converting from TRY to USD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtTRYtoUSD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 7 And cboCurrencyTo.SelectedIndex = 2) Then
            'Converting from TRY to CAD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtTRYtoCAD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "C$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 7 And cboCurrencyTo.SelectedIndex = 3) Then
            'Converting from TRY to EUR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtTRYtoEUR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "€" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 7 And cboCurrencyTo.SelectedIndex = 4) Then
            'Converting from TRY to UAH
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtTRYtoUAH.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₴" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 7 And cboCurrencyTo.SelectedIndex = 5) Then
            'Converting from TRY to MDL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtTRYtoMDL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "L" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 7 And cboCurrencyTo.SelectedIndex = 6) Then
            'Converting from TRY to PLN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtTRYtoPLN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "zł" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 7 And cboCurrencyTo.SelectedIndex = 7) Then
            'Converting from TRY to TRY
            MsgBox("Please choose proper currencies")

        ElseIf (cboCurrencyFrom.SelectedIndex = 7 And cboCurrencyTo.SelectedIndex = 8) Then
            'Converting from TRY to BGN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtTRYtoBGN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "Лв." & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 7 And cboCurrencyTo.SelectedIndex = 9) Then
            'Converting from TRY to BRL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtTRYtoBRL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "R$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 8 And cboCurrencyTo.SelectedIndex = 0) Then
            'Converting from BGN to GBR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBGNtoGBR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "£" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 8 And cboCurrencyTo.SelectedIndex = 1) Then
            'Converting from BGN to USD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBGNtoUSD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 8 And cboCurrencyTo.SelectedIndex = 2) Then
            'Converting from BGN to CAD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBGNtoCAD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "C$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 8 And cboCurrencyTo.SelectedIndex = 3) Then
            'Converting from BGN to EUR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBGNtoEUR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "€" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 8 And cboCurrencyTo.SelectedIndex = 4) Then
            'Converting from BGN to UAH
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBGNtoUAH.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₴" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 8 And cboCurrencyTo.SelectedIndex = 5) Then
            'Converting from BGN to MDL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBGNtoMDL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "L" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 8 And cboCurrencyTo.SelectedIndex = 6) Then
            'Converting from BGN to PLN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBGNtoPLN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "zł" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 8 And cboCurrencyTo.SelectedIndex = 7) Then
            'Converting from BGN to TRY
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBGNtoTRY.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₺" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 8 And cboCurrencyTo.SelectedIndex = 8) Then
            'Converting from BGN to BGN
            MsgBox("Please choose proper currencies")

        ElseIf (cboCurrencyFrom.SelectedIndex = 8 And cboCurrencyTo.SelectedIndex = 9) Then
            'Converting from BGN to BRL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBGNtoBRL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "R$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 9 And cboCurrencyTo.SelectedIndex = 0) Then
            'Converting from BRL to GBR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBRLtoGBR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "£" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 9 And cboCurrencyTo.SelectedIndex = 1) Then
            'Converting from BRL to USD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBRLtoUSD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 9 And cboCurrencyTo.SelectedIndex = 2) Then
            'Converting from BRL to CAD
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBRLtoCAD.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "C$" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 9 And cboCurrencyTo.SelectedIndex = 3) Then
            'Converting from BRL to EUR
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBRLtoEUR.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "€" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 9 And cboCurrencyTo.SelectedIndex = 4) Then
            'Converting from BRL to UAH
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBRLtoUAH.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₴" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 9 And cboCurrencyTo.SelectedIndex = 5) Then
            'Converting from BRL to MDL
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBRLtoMDL.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "L" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 9 And cboCurrencyTo.SelectedIndex = 6) Then
            'Converting from BRL to PLN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBRLtoPLN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "zł" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 9 And cboCurrencyTo.SelectedIndex = 7) Then
            'Converting from BRL to TRY
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBRLtoTRY.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "₺" & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 9 And cboCurrencyTo.SelectedIndex = 8) Then
            'Converting from BRL to BGN
            amountToConvert = System.Convert.ToDouble(txtConvertFrom.Text)
            rate = Val(txtBRLtoBGN.Text)
            amountToRecieve = amountToConvert * rate
            txtConvertTo.Text = "Лв." & amountToRecieve

        ElseIf (cboCurrencyFrom.SelectedIndex = 9 And cboCurrencyTo.SelectedIndex = 9) Then
            'Converting from BRL to BRL
            MsgBox("Please choose proper currencies")
        End If

    End Sub

    Private Sub cboCurrencyFrom_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboCurrencyFrom.SelectedIndexChanged
        'Change the flag next to the first combobox when the currency is selected
        If (cboCurrencyFrom.SelectedIndex = 0) Then
            pcbCurrencyFrom.Image = My.Resources.GBR
        ElseIf (cboCurrencyFrom.SelectedIndex = 1) Then
            pcbCurrencyFrom.Image = My.Resources.USD
        ElseIf (cboCurrencyFrom.SelectedIndex = 2) Then
            pcbCurrencyFrom.Image = My.Resources.CAD
        ElseIf (cboCurrencyFrom.SelectedIndex = 3) Then
            pcbCurrencyFrom.Image = My.Resources.EUR
        ElseIf (cboCurrencyFrom.SelectedIndex = 4) Then
            pcbCurrencyFrom.Image = My.Resources.UAH
        ElseIf (cboCurrencyFrom.SelectedIndex = 5) Then
            pcbCurrencyFrom.Image = My.Resources.MDL
        ElseIf (cboCurrencyFrom.SelectedIndex = 6) Then
            pcbCurrencyFrom.Image = My.Resources.PLN
        ElseIf (cboCurrencyFrom.SelectedIndex = 7) Then
            pcbCurrencyFrom.Image = My.Resources._TRY
        ElseIf (cboCurrencyFrom.SelectedIndex = 8) Then
            pcbCurrencyFrom.Image = My.Resources.BGN
        ElseIf (cboCurrencyFrom.SelectedIndex = 9) Then
            pcbCurrencyFrom.Image = My.Resources.BRL
        End If
    End Sub
    Private Sub cboCurrenryTo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboCurrencyTo.SelectedIndexChanged
        'Change the flag next to the second combobox when the currency is selected
        If (cboCurrencyTo.SelectedIndex = 0) Then
            pcbCurrencyTo.Image = My.Resources.GBR
        ElseIf (cboCurrencyTo.SelectedIndex = 1) Then
            pcbCurrencyTo.Image = My.Resources.USD
        ElseIf (cboCurrencyTo.SelectedIndex = 2) Then
            pcbCurrencyTo.Image = My.Resources.CAD
        ElseIf (cboCurrencyTo.SelectedIndex = 3) Then
            pcbCurrencyTo.Image = My.Resources.EUR
        ElseIf (cboCurrencyTo.SelectedIndex = 4) Then
            pcbCurrencyTo.Image = My.Resources.UAH
        ElseIf (cboCurrencyTo.SelectedIndex = 5) Then
            pcbCurrencyTo.Image = My.Resources.MDL
        ElseIf (cboCurrencyTo.SelectedIndex = 6) Then
            pcbCurrencyTo.Image = My.Resources.PLN
        ElseIf (cboCurrencyTo.SelectedIndex = 7) Then
            pcbCurrencyTo.Image = My.Resources._TRY
        ElseIf (cboCurrencyTo.SelectedIndex = 8) Then
            pcbCurrencyTo.Image = My.Resources.BGN
        ElseIf (cboCurrencyTo.SelectedIndex = 9) Then
            pcbCurrencyTo.Image = My.Resources.BRL
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnRates.Click
        'Variable for the value from the inputbox
        Dim ratesPassword As String = InputBox("Please, enter the password for the rates page")
        'Check if the inputbox is empty
        If ratesPassword = Nothing Then
            Return
        End If
        'check if the password is incorrect, if yes show message box with an error text
        If ratesPassword <> "qwerty12345" Then
            MsgBox("Password was incorrect!")
        End If
        'Check if the password is correct, if yes show panel
        If ratesPassword = "qwerty12345" Then
            pnlRates.Show()
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles btnCloseRate.Click
        'Hide the rates form when the button "Close" is clicked
        pnlRates.Hide()
    End Sub

    Private Sub pnlFAQ_Click(sender As Object, e As EventArgs) Handles btnFAQ.Click
        'Show the FAQ form when the button "FAQ" is clicked
        pnlFAQ.Show()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles btnCloseFAQ.Click
        'Hide the FAQ form when the button "Close" is clicked
        pnlFAQ.Hide()
    End Sub

    Private Sub Clear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clear textboxes when "Clear" button is clicked
        txtConvertFrom.Clear()
        txtConvertTo.Clear()
        cboCurrencyFrom.Text = ""
        cboCurrencyTo.Text = ""
    End Sub

    Private Sub txtConvertFrom_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtConvertFrom.KeyPress
        'Check the users input. If the input is not the number or the backspace, don't allow to write it
        Dim ch As Char = e.KeyChar

        If Not Char.IsDigit(ch) AndAlso Asc(ch) <> 8 Then
            e.Handled = True
        End If
    End Sub

    Private Sub Form2_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        'when the main progrma is closing close the whole program
        Application.Exit()
        End
    End Sub
End Class