﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.txtPasswordField = New System.Windows.Forms.TextBox()
        Me.txtNameField = New System.Windows.Forms.TextBox()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblTitleForLogin = New System.Windows.Forms.Label()
        Me.pcbLock = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtAttempts = New System.Windows.Forms.TextBox()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        CType(Me.pcbLock, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnLogin
        '
        Me.btnLogin.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogin.Font = New System.Drawing.Font("Nirmala UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogin.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnLogin.Location = New System.Drawing.Point(279, 468)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(228, 80)
        Me.btnLogin.TabIndex = 11
        Me.btnLogin.Text = "Login"
        Me.btnLogin.UseVisualStyleBackColor = False
        '
        'txtPasswordField
        '
        Me.txtPasswordField.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.txtPasswordField.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtPasswordField.Font = New System.Drawing.Font("Nirmala UI", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPasswordField.Location = New System.Drawing.Point(350, 310)
        Me.txtPasswordField.MaxLength = 20
        Me.txtPasswordField.Multiline = True
        Me.txtPasswordField.Name = "txtPasswordField"
        Me.txtPasswordField.PasswordChar = Global.Microsoft.VisualBasic.ChrW(8226)
        Me.txtPasswordField.Size = New System.Drawing.Size(269, 56)
        Me.txtPasswordField.TabIndex = 10
        '
        'txtNameField
        '
        Me.txtNameField.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.txtNameField.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNameField.Font = New System.Drawing.Font("Nirmala UI", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNameField.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtNameField.Location = New System.Drawing.Point(350, 156)
        Me.txtNameField.MaxLength = 20
        Me.txtNameField.Multiline = True
        Me.txtNameField.Name = "txtNameField"
        Me.txtNameField.Size = New System.Drawing.Size(315, 57)
        Me.txtNameField.TabIndex = 9
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Font = New System.Drawing.Font("Nirmala UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPassword.Location = New System.Drawing.Point(51, 301)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(238, 65)
        Me.lblPassword.TabIndex = 8
        Me.lblPassword.Text = "Password"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Nirmala UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(82, 148)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(162, 65)
        Me.lblName.TabIndex = 7
        Me.lblName.Text = "Name"
        '
        'lblTitleForLogin
        '
        Me.lblTitleForLogin.AutoSize = True
        Me.lblTitleForLogin.Font = New System.Drawing.Font("Nirmala UI", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitleForLogin.Location = New System.Drawing.Point(300, 9)
        Me.lblTitleForLogin.Name = "lblTitleForLogin"
        Me.lblTitleForLogin.Size = New System.Drawing.Size(206, 86)
        Me.lblTitleForLogin.TabIndex = 6
        Me.lblTitleForLogin.Text = "Login"
        '
        'pcbLock
        '
        Me.pcbLock.Image = CType(resources.GetObject("pcbLock.Image"), System.Drawing.Image)
        Me.pcbLock.Location = New System.Drawing.Point(614, 310)
        Me.pcbLock.Name = "pcbLock"
        Me.pcbLock.Size = New System.Drawing.Size(51, 56)
        Me.pcbLock.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbLock.TabIndex = 13
        Me.pcbLock.TabStop = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(691, 38)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "test"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtAttempts
        '
        Me.txtAttempts.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.txtAttempts.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtAttempts.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAttempts.Location = New System.Drawing.Point(446, 131)
        Me.txtAttempts.Name = "txtAttempts"
        Me.txtAttempts.Size = New System.Drawing.Size(112, 19)
        Me.txtAttempts.TabIndex = 15
        Me.txtAttempts.Text = "Attempts: 3"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(843, 558)
        Me.Controls.Add(Me.txtAttempts)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.pcbLock)
        Me.Controls.Add(Me.btnLogin)
        Me.Controls.Add(Me.txtPasswordField)
        Me.Controls.Add(Me.txtNameField)
        Me.Controls.Add(Me.lblPassword)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.lblTitleForLogin)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Login"
        CType(Me.pcbLock, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnLogin As Button
    Friend WithEvents txtPasswordField As TextBox
    Friend WithEvents txtNameField As TextBox
    Friend WithEvents lblPassword As Label
    Friend WithEvents lblName As Label
    Friend WithEvents lblTitleForLogin As Label
    Friend WithEvents pcbLock As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents txtAttempts As TextBox
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
End Class
