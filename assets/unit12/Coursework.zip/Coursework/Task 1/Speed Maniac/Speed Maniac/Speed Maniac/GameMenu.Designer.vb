﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GameMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GameMenu))
        Me.cmdLevel1 = New System.Windows.Forms.Button()
        Me.picPlay1 = New System.Windows.Forms.PictureBox()
        Me.cmdLevel2 = New System.Windows.Forms.Button()
        Me.picPlay2 = New System.Windows.Forms.PictureBox()
        Me.picPlay3 = New System.Windows.Forms.PictureBox()
        Me.cmdLevel3 = New System.Windows.Forms.Button()
        Me.lblMainMenu = New System.Windows.Forms.Label()
        Me.cmdOptions = New System.Windows.Forms.Button()
        Me.picOptions = New System.Windows.Forms.PictureBox()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.picExit = New System.Windows.Forms.PictureBox()
        CType(Me.picPlay1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPlay2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPlay3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picOptions, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picExit, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdLevel1
        '
        Me.cmdLevel1.BackColor = System.Drawing.Color.Black
        Me.cmdLevel1.Font = New System.Drawing.Font("SimSun", 19.8!, System.Drawing.FontStyle.Bold)
        Me.cmdLevel1.ForeColor = System.Drawing.Color.White
        Me.cmdLevel1.Location = New System.Drawing.Point(38, 79)
        Me.cmdLevel1.Margin = New System.Windows.Forms.Padding(2)
        Me.cmdLevel1.Name = "cmdLevel1"
        Me.cmdLevel1.Size = New System.Drawing.Size(129, 32)
        Me.cmdLevel1.TabIndex = 0
        Me.cmdLevel1.Text = "Level 1"
        Me.cmdLevel1.UseVisualStyleBackColor = False
        '
        'picPlay1
        '
        Me.picPlay1.Image = CType(resources.GetObject("picPlay1.Image"), System.Drawing.Image)
        Me.picPlay1.Location = New System.Drawing.Point(-1, 79)
        Me.picPlay1.Margin = New System.Windows.Forms.Padding(2)
        Me.picPlay1.Name = "picPlay1"
        Me.picPlay1.Size = New System.Drawing.Size(35, 32)
        Me.picPlay1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picPlay1.TabIndex = 1
        Me.picPlay1.TabStop = False
        '
        'cmdLevel2
        '
        Me.cmdLevel2.BackColor = System.Drawing.Color.Black
        Me.cmdLevel2.Font = New System.Drawing.Font("SimSun", 19.8!, System.Drawing.FontStyle.Bold)
        Me.cmdLevel2.ForeColor = System.Drawing.Color.White
        Me.cmdLevel2.Location = New System.Drawing.Point(38, 115)
        Me.cmdLevel2.Margin = New System.Windows.Forms.Padding(2)
        Me.cmdLevel2.Name = "cmdLevel2"
        Me.cmdLevel2.Size = New System.Drawing.Size(129, 32)
        Me.cmdLevel2.TabIndex = 2
        Me.cmdLevel2.Text = "Level 2"
        Me.cmdLevel2.UseVisualStyleBackColor = False
        '
        'picPlay2
        '
        Me.picPlay2.Image = CType(resources.GetObject("picPlay2.Image"), System.Drawing.Image)
        Me.picPlay2.Location = New System.Drawing.Point(-1, 115)
        Me.picPlay2.Margin = New System.Windows.Forms.Padding(2)
        Me.picPlay2.Name = "picPlay2"
        Me.picPlay2.Size = New System.Drawing.Size(35, 32)
        Me.picPlay2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picPlay2.TabIndex = 3
        Me.picPlay2.TabStop = False
        '
        'picPlay3
        '
        Me.picPlay3.Image = CType(resources.GetObject("picPlay3.Image"), System.Drawing.Image)
        Me.picPlay3.Location = New System.Drawing.Point(-1, 151)
        Me.picPlay3.Margin = New System.Windows.Forms.Padding(2)
        Me.picPlay3.Name = "picPlay3"
        Me.picPlay3.Size = New System.Drawing.Size(35, 32)
        Me.picPlay3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picPlay3.TabIndex = 4
        Me.picPlay3.TabStop = False
        '
        'cmdLevel3
        '
        Me.cmdLevel3.BackColor = System.Drawing.Color.Black
        Me.cmdLevel3.Font = New System.Drawing.Font("SimSun", 19.8!, System.Drawing.FontStyle.Bold)
        Me.cmdLevel3.ForeColor = System.Drawing.Color.White
        Me.cmdLevel3.Location = New System.Drawing.Point(38, 151)
        Me.cmdLevel3.Margin = New System.Windows.Forms.Padding(2)
        Me.cmdLevel3.Name = "cmdLevel3"
        Me.cmdLevel3.Size = New System.Drawing.Size(129, 32)
        Me.cmdLevel3.TabIndex = 5
        Me.cmdLevel3.Text = "Level 3"
        Me.cmdLevel3.UseVisualStyleBackColor = False
        '
        'lblMainMenu
        '
        Me.lblMainMenu.AutoSize = True
        Me.lblMainMenu.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.lblMainMenu.Font = New System.Drawing.Font("Gabriola", 16.2!, System.Drawing.FontStyle.Bold)
        Me.lblMainMenu.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblMainMenu.Location = New System.Drawing.Point(263, 6)
        Me.lblMainMenu.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblMainMenu.Name = "lblMainMenu"
        Me.lblMainMenu.Size = New System.Drawing.Size(252, 40)
        Me.lblMainMenu.TabIndex = 6
        Me.lblMainMenu.Text = "Welcome to the Speed Maniac!"
        Me.lblMainMenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmdOptions
        '
        Me.cmdOptions.BackColor = System.Drawing.Color.Black
        Me.cmdOptions.Font = New System.Drawing.Font("SimSun", 19.8!, System.Drawing.FontStyle.Bold)
        Me.cmdOptions.ForeColor = System.Drawing.Color.White
        Me.cmdOptions.Location = New System.Drawing.Point(38, 187)
        Me.cmdOptions.Margin = New System.Windows.Forms.Padding(2)
        Me.cmdOptions.Name = "cmdOptions"
        Me.cmdOptions.Size = New System.Drawing.Size(129, 32)
        Me.cmdOptions.TabIndex = 7
        Me.cmdOptions.Text = "Options"
        Me.cmdOptions.UseVisualStyleBackColor = False
        '
        'picOptions
        '
        Me.picOptions.BackgroundImage = CType(resources.GetObject("picOptions.BackgroundImage"), System.Drawing.Image)
        Me.picOptions.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.picOptions.Location = New System.Drawing.Point(-1, 187)
        Me.picOptions.Margin = New System.Windows.Forms.Padding(2)
        Me.picOptions.Name = "picOptions"
        Me.picOptions.Size = New System.Drawing.Size(35, 32)
        Me.picOptions.TabIndex = 8
        Me.picOptions.TabStop = False
        '
        'cmdExit
        '
        Me.cmdExit.BackColor = System.Drawing.Color.Black
        Me.cmdExit.Font = New System.Drawing.Font("SimSun", 19.8!, System.Drawing.FontStyle.Bold)
        Me.cmdExit.ForeColor = System.Drawing.Color.White
        Me.cmdExit.Location = New System.Drawing.Point(38, 223)
        Me.cmdExit.Margin = New System.Windows.Forms.Padding(2)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(129, 32)
        Me.cmdExit.TabIndex = 9
        Me.cmdExit.Text = "Exit"
        Me.cmdExit.UseVisualStyleBackColor = False
        '
        'picExit
        '
        Me.picExit.BackgroundImage = CType(resources.GetObject("picExit.BackgroundImage"), System.Drawing.Image)
        Me.picExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picExit.Location = New System.Drawing.Point(-1, 223)
        Me.picExit.Margin = New System.Windows.Forms.Padding(2)
        Me.picExit.Name = "picExit"
        Me.picExit.Size = New System.Drawing.Size(35, 32)
        Me.picExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picExit.TabIndex = 10
        Me.picExit.TabStop = False
        '
        'GameMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(548, 266)
        Me.Controls.Add(Me.picExit)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.picOptions)
        Me.Controls.Add(Me.cmdOptions)
        Me.Controls.Add(Me.lblMainMenu)
        Me.Controls.Add(Me.cmdLevel3)
        Me.Controls.Add(Me.picPlay3)
        Me.Controls.Add(Me.picPlay2)
        Me.Controls.Add(Me.cmdLevel2)
        Me.Controls.Add(Me.picPlay1)
        Me.Controls.Add(Me.cmdLevel1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "GameMenu"
        Me.Text = "GameMenu"
        CType(Me.picPlay1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPlay2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPlay3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picOptions, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picExit, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cmdLevel1 As Button
    Friend WithEvents picPlay1 As PictureBox
    Friend WithEvents cmdLevel2 As Button
    Friend WithEvents picPlay2 As PictureBox
    Friend WithEvents picPlay3 As PictureBox
    Friend WithEvents cmdLevel3 As Button
    Friend WithEvents lblMainMenu As Label
    Friend WithEvents cmdOptions As Button
    Friend WithEvents picOptions As PictureBox
    Friend WithEvents cmdExit As Button
    Friend WithEvents picExit As PictureBox
End Class
