﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.tmrRoadLvl3 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrSpeedManiacLeftLvl3 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrSpeedManiacRightLvl3 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrLvl3Enemy1 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrLvl3Enemy2 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrLvl3Enemy3 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrLvl3Enemy4 = New System.Windows.Forms.Timer(Me.components)
        Me.picLvl3_7 = New System.Windows.Forms.PictureBox()
        Me.picLvl3_5 = New System.Windows.Forms.PictureBox()
        Me.picLvl3_8 = New System.Windows.Forms.PictureBox()
        Me.picLvl3_3 = New System.Windows.Forms.PictureBox()
        Me.picLvl3_6 = New System.Windows.Forms.PictureBox()
        Me.picLvl3_2 = New System.Windows.Forms.PictureBox()
        Me.picLvl3_1 = New System.Windows.Forms.PictureBox()
        Me.picLvl3_4 = New System.Windows.Forms.PictureBox()
        Me.picMainCarLvl3 = New System.Windows.Forms.PictureBox()
        Me.picLvl3Enemy5 = New System.Windows.Forms.PictureBox()
        Me.picLvl3Enemy1 = New System.Windows.Forms.PictureBox()
        Me.picLvl3Enemy2 = New System.Windows.Forms.PictureBox()
        Me.picLvl3Enemy3 = New System.Windows.Forms.PictureBox()
        Me.picLvl3Enemy4 = New System.Windows.Forms.PictureBox()
        Me.cmdRestartLvl3 = New System.Windows.Forms.Button()
        Me.lblGameOverLvl3 = New System.Windows.Forms.Label()
        Me.lblGameScoreLvl3 = New System.Windows.Forms.Label()
        Me.tmrLvl3Enemy5 = New System.Windows.Forms.Timer(Me.components)
        Me.lblGameWonLvl3 = New System.Windows.Forms.Label()
        Me.cmdGoBack = New System.Windows.Forms.Button()
        CType(Me.picLvl3_7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl3_5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl3_8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl3_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl3_6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl3_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl3_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl3_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMainCarLvl3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl3Enemy5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl3Enemy1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl3Enemy2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl3Enemy3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl3Enemy4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tmrRoadLvl3
        '
        Me.tmrRoadLvl3.Enabled = True
        Me.tmrRoadLvl3.Interval = 10
        '
        'tmrSpeedManiacLeftLvl3
        '
        Me.tmrSpeedManiacLeftLvl3.Interval = 10
        '
        'tmrSpeedManiacRightLvl3
        '
        Me.tmrSpeedManiacRightLvl3.Interval = 10
        '
        'tmrLvl3Enemy1
        '
        Me.tmrLvl3Enemy1.Enabled = True
        Me.tmrLvl3Enemy1.Interval = 10
        '
        'tmrLvl3Enemy2
        '
        Me.tmrLvl3Enemy2.Enabled = True
        Me.tmrLvl3Enemy2.Interval = 10
        '
        'tmrLvl3Enemy3
        '
        Me.tmrLvl3Enemy3.Enabled = True
        Me.tmrLvl3Enemy3.Interval = 10
        '
        'tmrLvl3Enemy4
        '
        Me.tmrLvl3Enemy4.Enabled = True
        Me.tmrLvl3Enemy4.Interval = 10
        '
        'picLvl3_7
        '
        Me.picLvl3_7.BackColor = System.Drawing.Color.Black
        Me.picLvl3_7.Location = New System.Drawing.Point(57, 0)
        Me.picLvl3_7.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl3_7.Name = "picLvl3_7"
        Me.picLvl3_7.Size = New System.Drawing.Size(8, 49)
        Me.picLvl3_7.TabIndex = 6
        Me.picLvl3_7.TabStop = False
        '
        'picLvl3_5
        '
        Me.picLvl3_5.BackColor = System.Drawing.Color.Black
        Me.picLvl3_5.Location = New System.Drawing.Point(57, 75)
        Me.picLvl3_5.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl3_5.Name = "picLvl3_5"
        Me.picLvl3_5.Size = New System.Drawing.Size(8, 49)
        Me.picLvl3_5.TabIndex = 7
        Me.picLvl3_5.TabStop = False
        '
        'picLvl3_8
        '
        Me.picLvl3_8.BackColor = System.Drawing.Color.Black
        Me.picLvl3_8.Location = New System.Drawing.Point(113, 0)
        Me.picLvl3_8.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl3_8.Name = "picLvl3_8"
        Me.picLvl3_8.Size = New System.Drawing.Size(8, 49)
        Me.picLvl3_8.TabIndex = 8
        Me.picLvl3_8.TabStop = False
        '
        'picLvl3_3
        '
        Me.picLvl3_3.BackColor = System.Drawing.Color.Black
        Me.picLvl3_3.Location = New System.Drawing.Point(57, 163)
        Me.picLvl3_3.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl3_3.Name = "picLvl3_3"
        Me.picLvl3_3.Size = New System.Drawing.Size(8, 49)
        Me.picLvl3_3.TabIndex = 9
        Me.picLvl3_3.TabStop = False
        '
        'picLvl3_6
        '
        Me.picLvl3_6.BackColor = System.Drawing.Color.Black
        Me.picLvl3_6.Location = New System.Drawing.Point(113, 75)
        Me.picLvl3_6.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl3_6.Name = "picLvl3_6"
        Me.picLvl3_6.Size = New System.Drawing.Size(8, 49)
        Me.picLvl3_6.TabIndex = 10
        Me.picLvl3_6.TabStop = False
        '
        'picLvl3_2
        '
        Me.picLvl3_2.BackColor = System.Drawing.Color.Black
        Me.picLvl3_2.Location = New System.Drawing.Point(113, 245)
        Me.picLvl3_2.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl3_2.Name = "picLvl3_2"
        Me.picLvl3_2.Size = New System.Drawing.Size(8, 49)
        Me.picLvl3_2.TabIndex = 11
        Me.picLvl3_2.TabStop = False
        '
        'picLvl3_1
        '
        Me.picLvl3_1.BackColor = System.Drawing.Color.Black
        Me.picLvl3_1.Location = New System.Drawing.Point(57, 245)
        Me.picLvl3_1.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl3_1.Name = "picLvl3_1"
        Me.picLvl3_1.Size = New System.Drawing.Size(8, 49)
        Me.picLvl3_1.TabIndex = 12
        Me.picLvl3_1.TabStop = False
        '
        'picLvl3_4
        '
        Me.picLvl3_4.BackColor = System.Drawing.Color.Black
        Me.picLvl3_4.Location = New System.Drawing.Point(113, 163)
        Me.picLvl3_4.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl3_4.Name = "picLvl3_4"
        Me.picLvl3_4.Size = New System.Drawing.Size(8, 49)
        Me.picLvl3_4.TabIndex = 13
        Me.picLvl3_4.TabStop = False
        '
        'picMainCarLvl3
        '
        Me.picMainCarLvl3.Image = CType(resources.GetObject("picMainCarLvl3.Image"), System.Drawing.Image)
        Me.picMainCarLvl3.Location = New System.Drawing.Point(69, 245)
        Me.picMainCarLvl3.Margin = New System.Windows.Forms.Padding(2)
        Me.picMainCarLvl3.Name = "picMainCarLvl3"
        Me.picMainCarLvl3.Size = New System.Drawing.Size(30, 40)
        Me.picMainCarLvl3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picMainCarLvl3.TabIndex = 14
        Me.picMainCarLvl3.TabStop = False
        '
        'picLvl3Enemy5
        '
        Me.picLvl3Enemy5.Image = CType(resources.GetObject("picLvl3Enemy5.Image"), System.Drawing.Image)
        Me.picLvl3Enemy5.Location = New System.Drawing.Point(11, 11)
        Me.picLvl3Enemy5.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl3Enemy5.Name = "picLvl3Enemy5"
        Me.picLvl3Enemy5.Size = New System.Drawing.Size(30, 40)
        Me.picLvl3Enemy5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLvl3Enemy5.TabIndex = 15
        Me.picLvl3Enemy5.TabStop = False
        '
        'picLvl3Enemy1
        '
        Me.picLvl3Enemy1.Image = CType(resources.GetObject("picLvl3Enemy1.Image"), System.Drawing.Image)
        Me.picLvl3Enemy1.Location = New System.Drawing.Point(135, 70)
        Me.picLvl3Enemy1.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl3Enemy1.Name = "picLvl3Enemy1"
        Me.picLvl3Enemy1.Size = New System.Drawing.Size(30, 40)
        Me.picLvl3Enemy1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLvl3Enemy1.TabIndex = 16
        Me.picLvl3Enemy1.TabStop = False
        '
        'picLvl3Enemy2
        '
        Me.picLvl3Enemy2.Image = CType(resources.GetObject("picLvl3Enemy2.Image"), System.Drawing.Image)
        Me.picLvl3Enemy2.Location = New System.Drawing.Point(69, 27)
        Me.picLvl3Enemy2.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl3Enemy2.Name = "picLvl3Enemy2"
        Me.picLvl3Enemy2.Size = New System.Drawing.Size(30, 40)
        Me.picLvl3Enemy2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLvl3Enemy2.TabIndex = 17
        Me.picLvl3Enemy2.TabStop = False
        '
        'picLvl3Enemy3
        '
        Me.picLvl3Enemy3.Image = CType(resources.GetObject("picLvl3Enemy3.Image"), System.Drawing.Image)
        Me.picLvl3Enemy3.Location = New System.Drawing.Point(33, 70)
        Me.picLvl3Enemy3.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl3Enemy3.Name = "picLvl3Enemy3"
        Me.picLvl3Enemy3.Size = New System.Drawing.Size(30, 40)
        Me.picLvl3Enemy3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLvl3Enemy3.TabIndex = 18
        Me.picLvl3Enemy3.TabStop = False
        '
        'picLvl3Enemy4
        '
        Me.picLvl3Enemy4.Image = CType(resources.GetObject("picLvl3Enemy4.Image"), System.Drawing.Image)
        Me.picLvl3Enemy4.Location = New System.Drawing.Point(125, 11)
        Me.picLvl3Enemy4.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl3Enemy4.Name = "picLvl3Enemy4"
        Me.picLvl3Enemy4.Size = New System.Drawing.Size(30, 40)
        Me.picLvl3Enemy4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLvl3Enemy4.TabIndex = 19
        Me.picLvl3Enemy4.TabStop = False
        '
        'cmdRestartLvl3
        '
        Me.cmdRestartLvl3.BackColor = System.Drawing.Color.Blue
        Me.cmdRestartLvl3.Font = New System.Drawing.Font("Segoe UI", 16.2!, System.Drawing.FontStyle.Bold)
        Me.cmdRestartLvl3.ForeColor = System.Drawing.Color.White
        Me.cmdRestartLvl3.Location = New System.Drawing.Point(42, 163)
        Me.cmdRestartLvl3.Margin = New System.Windows.Forms.Padding(2)
        Me.cmdRestartLvl3.Name = "cmdRestartLvl3"
        Me.cmdRestartLvl3.Size = New System.Drawing.Size(100, 35)
        Me.cmdRestartLvl3.TabIndex = 20
        Me.cmdRestartLvl3.Text = "Restart"
        Me.cmdRestartLvl3.UseVisualStyleBackColor = False
        Me.cmdRestartLvl3.Visible = False
        '
        'lblGameOverLvl3
        '
        Me.lblGameOverLvl3.AutoSize = True
        Me.lblGameOverLvl3.BackColor = System.Drawing.Color.Blue
        Me.lblGameOverLvl3.Font = New System.Drawing.Font("Segoe UI", 16.2!, System.Drawing.FontStyle.Bold)
        Me.lblGameOverLvl3.ForeColor = System.Drawing.Color.White
        Me.lblGameOverLvl3.Location = New System.Drawing.Point(28, 94)
        Me.lblGameOverLvl3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblGameOverLvl3.Name = "lblGameOverLvl3"
        Me.lblGameOverLvl3.Size = New System.Drawing.Size(136, 30)
        Me.lblGameOverLvl3.TabIndex = 21
        Me.lblGameOverLvl3.Text = "Game Over!"
        Me.lblGameOverLvl3.Visible = False
        '
        'lblGameScoreLvl3
        '
        Me.lblGameScoreLvl3.AutoSize = True
        Me.lblGameScoreLvl3.BackColor = System.Drawing.Color.Blue
        Me.lblGameScoreLvl3.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold)
        Me.lblGameScoreLvl3.ForeColor = System.Drawing.Color.White
        Me.lblGameScoreLvl3.Location = New System.Drawing.Point(81, 0)
        Me.lblGameScoreLvl3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblGameScoreLvl3.Name = "lblGameScoreLvl3"
        Me.lblGameScoreLvl3.Size = New System.Drawing.Size(83, 25)
        Me.lblGameScoreLvl3.TabIndex = 22
        Me.lblGameScoreLvl3.Text = "Points:0"
        '
        'tmrLvl3Enemy5
        '
        Me.tmrLvl3Enemy5.Enabled = True
        Me.tmrLvl3Enemy5.Interval = 10
        '
        'lblGameWonLvl3
        '
        Me.lblGameWonLvl3.AutoSize = True
        Me.lblGameWonLvl3.BackColor = System.Drawing.Color.Blue
        Me.lblGameWonLvl3.Font = New System.Drawing.Font("SimSun", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGameWonLvl3.ForeColor = System.Drawing.Color.White
        Me.lblGameWonLvl3.Location = New System.Drawing.Point(38, 103)
        Me.lblGameWonLvl3.Name = "lblGameWonLvl3"
        Me.lblGameWonLvl3.Size = New System.Drawing.Size(106, 21)
        Me.lblGameWonLvl3.TabIndex = 23
        Me.lblGameWonLvl3.Text = "You Won!"
        Me.lblGameWonLvl3.Visible = False
        '
        'cmdGoBack
        '
        Me.cmdGoBack.BackColor = System.Drawing.Color.Blue
        Me.cmdGoBack.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdGoBack.ForeColor = System.Drawing.Color.White
        Me.cmdGoBack.Location = New System.Drawing.Point(-1, 203)
        Me.cmdGoBack.Name = "cmdGoBack"
        Me.cmdGoBack.Size = New System.Drawing.Size(175, 37)
        Me.cmdGoBack.TabIndex = 24
        Me.cmdGoBack.Text = "Go back to main menu"
        Me.cmdGoBack.UseVisualStyleBackColor = False
        Me.cmdGoBack.Visible = False
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(174, 294)
        Me.Controls.Add(Me.cmdGoBack)
        Me.Controls.Add(Me.lblGameWonLvl3)
        Me.Controls.Add(Me.lblGameScoreLvl3)
        Me.Controls.Add(Me.lblGameOverLvl3)
        Me.Controls.Add(Me.cmdRestartLvl3)
        Me.Controls.Add(Me.picLvl3Enemy4)
        Me.Controls.Add(Me.picLvl3Enemy3)
        Me.Controls.Add(Me.picLvl3Enemy2)
        Me.Controls.Add(Me.picLvl3Enemy1)
        Me.Controls.Add(Me.picLvl3Enemy5)
        Me.Controls.Add(Me.picMainCarLvl3)
        Me.Controls.Add(Me.picLvl3_4)
        Me.Controls.Add(Me.picLvl3_1)
        Me.Controls.Add(Me.picLvl3_2)
        Me.Controls.Add(Me.picLvl3_6)
        Me.Controls.Add(Me.picLvl3_3)
        Me.Controls.Add(Me.picLvl3_8)
        Me.Controls.Add(Me.picLvl3_5)
        Me.Controls.Add(Me.picLvl3_7)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Form3"
        Me.Text = "Form3"
        CType(Me.picLvl3_7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl3_5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl3_8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl3_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl3_6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl3_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl3_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl3_4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMainCarLvl3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl3Enemy5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl3Enemy1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl3Enemy2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl3Enemy3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl3Enemy4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents tmrRoadLvl3 As Timer
    Friend WithEvents tmrSpeedManiacLeftLvl3 As Timer
    Friend WithEvents tmrSpeedManiacRightLvl3 As Timer
    Friend WithEvents tmrLvl3Enemy1 As Timer
    Friend WithEvents tmrLvl3Enemy2 As Timer
    Friend WithEvents tmrLvl3Enemy3 As Timer
    Friend WithEvents tmrLvl3Enemy4 As Timer
    Friend WithEvents picLvl3_7 As PictureBox
    Friend WithEvents picLvl3_5 As PictureBox
    Friend WithEvents picLvl3_8 As PictureBox
    Friend WithEvents picLvl3_3 As PictureBox
    Friend WithEvents picLvl3_6 As PictureBox
    Friend WithEvents picLvl3_2 As PictureBox
    Friend WithEvents picLvl3_1 As PictureBox
    Friend WithEvents picLvl3_4 As PictureBox
    Friend WithEvents picMainCarLvl3 As PictureBox
    Friend WithEvents picLvl3Enemy5 As PictureBox
    Friend WithEvents picLvl3Enemy1 As PictureBox
    Friend WithEvents picLvl3Enemy2 As PictureBox
    Friend WithEvents picLvl3Enemy3 As PictureBox
    Friend WithEvents picLvl3Enemy4 As PictureBox
    Friend WithEvents cmdRestartLvl3 As Button
    Friend WithEvents lblGameOverLvl3 As Label
    Friend WithEvents lblGameScoreLvl3 As Label
    Friend WithEvents pic As PictureBox
    Friend WithEvents tmrLvl3Enemy5 As Timer
    Friend WithEvents lblGameWonLvl3 As Label
    Friend WithEvents cmdGoBack As Button
End Class
