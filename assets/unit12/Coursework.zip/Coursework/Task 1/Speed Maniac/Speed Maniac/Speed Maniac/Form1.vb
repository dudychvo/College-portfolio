﻿Public Class Form1

    'global variables declaration
    Dim speed As Integer
    Dim roadMarkings(7) As PictureBox 'picture box array
    Dim gamePoints As Integer = 0 'variable to store game points
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'assign each picturebox to an array position
        roadMarkings(0) = PictureBox1
        roadMarkings(1) = PictureBox2
        roadMarkings(2) = PictureBox3
        roadMarkings(3) = PictureBox4
        roadMarkings(4) = PictureBox5
        roadMarkings(5) = PictureBox6
        roadMarkings(6) = PictureBox7
        roadMarkings(7) = PictureBox8
        'PlayBackgroundSound()
    End Sub

    Private Sub roadTimer_Tick(sender As Object, e As EventArgs) Handles roadTimer.Tick
        For MoveCount As Integer = 0 To 7 'Loop to keep moving each road marking 
            roadMarkings(MoveCount).Top += 2

            'Repeat road markings movement
            If roadMarkings(MoveCount).Top >= Me.Height Then
                roadMarkings(MoveCount).Top = -roadMarkings(MoveCount).Height
            End If
        Next

        'check for collision between main car and enemy cars
        If (picRacingCar.Bounds.IntersectsWith(picEnemy1.Bounds)) Then
            endOfTheGame()
            StopBackgroundSound()
        End If
        If (picRacingCar.Bounds.IntersectsWith(picEnemy2.Bounds)) Then
            endOfTheGame()
            StopBackgroundSound()
        End If
        If (picRacingCar.Bounds.IntersectsWith(picEnemy3.Bounds)) Then
            endOfTheGame()
            StopBackgroundSound()
        End If
        If (picRacingCar.Bounds.IntersectsWith(picEnemy4.Bounds)) Then
            endOfTheGame()
            StopBackgroundSound()
        End If

        'check if the game is won
        If gamePoints = 10 Then
            GameWon()
        End If
    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        'Start right timer if right key is pressed
        If e.KeyCode = Keys.Right Then
            tmrSpeedManiacRight.Start()
        End If

        'Start left timer if left key is pressed
        If e.KeyCode = Keys.Left Then
            tmrSpeedManiacLeft.Start()
        End If
    End Sub

    Private Sub tmrSpeedManiacLeft_Tick(sender As Object, e As EventArgs) Handles tmrSpeedManiacLeft.Tick
        If (picRacingCar.Location.X > 1) Then
            picRacingCar.Left -= 5
        End If
    End Sub

    Private Sub tmrSpeedManiacRight_Tick(sender As Object, e As EventArgs) Handles tmrSpeedManiacRight.Tick
        If (picRacingCar.Location.X < 150) Then
            picRacingCar.Left += 5
        End If
    End Sub

    Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles MyBase.KeyUp
        'Stop when key is released 
        tmrSpeedManiacLeft.Stop()
        tmrSpeedManiacRight.Stop()
    End Sub

    Private Sub tmrEnemy1_Tick(sender As Object, e As EventArgs) Handles tmrEnemy1.Tick
        'move enemy cars, reposition them when they leave the form
        picEnemy1.Top += 1 'set speed of car
        If picEnemy1.Top > Me.Height Then

            gamePoints += 1 'Add a point to the game if player avoids collsiion
            lblScore.Text = "Point: " & gamePoints 'Display score in the score

            picEnemy1.Top = -picEnemy1.Height
            picEnemy1.Top = -(CInt(Math.Ceiling(Rnd() * 100)) + picEnemy1.Height)
            picEnemy1.Left = CInt(Math.Ceiling(Rnd() * 50)) + 0
        End If

    End Sub

    Private Sub tmrEnemy2_Tick(sender As Object, e As EventArgs) Handles tmrEnemy2.Tick
        picEnemy2.Top += 1.5
        If picEnemy2.Top > Me.Height Then

            gamePoints += 1 'Add a point to the game if player avoids collsiion
            lblScore.Text = "Point: " & gamePoints 'Display score in the score

            picEnemy2.Top = -picEnemy2.Height
            picEnemy2.Top = -(CInt(Math.Ceiling(Rnd() * 100)) + picEnemy2.Height)
            picEnemy2.Left = CInt(Math.Ceiling(Rnd() * 40)) + 80

        End If
    End Sub

    Private Sub tmrEnemy3_Tick(sender As Object, e As EventArgs) Handles tmrEnemy3.Tick
        picEnemy3.Top += 2.5
        If picEnemy3.Top > Me.Height Then

            gamePoints += 1 'Add a point to the game if player avoids collsiion
            lblScore.Text = "Point: " & gamePoints 'Display score in the score

            picEnemy3.Top = -picEnemy3.Height
            picEnemy3.Top = -(CInt(Math.Ceiling(Rnd() * 100)) + picEnemy2.Height)
            picEnemy3.Left = CInt(Math.Ceiling(Rnd() * 90)) + 100

        End If
    End Sub

    Private Sub tmrEnemy4_Tick(sender As Object, e As EventArgs) Handles tmrEnemy4.Tick
        picEnemy4.Top += 3
        If picEnemy4.Top > Me.Height Then

            gamePoints += 1 'Add a point to the game if player avoids collsiion
            lblScore.Text = "Point: " & gamePoints 'Display score in the score

            picEnemy4.Top = -picEnemy4.Height
            picEnemy4.Top = -(CInt(Math.Ceiling(Rnd() * 100)) + picEnemy4.Height)
            picEnemy4.Left = CInt(Math.Ceiling(Rnd() * 50)) + 20

        End If
    End Sub

    'Game over function
    Private Sub endOfTheGame()
        lblEndOfTheGame.Visible = True
        roadTimer.Stop()
        tmrSpeedManiacRight.Stop()
        tmrSpeedManiacLeft.Stop()
        tmrEnemy1.Stop()
        tmrEnemy2.Stop()
        tmrEnemy3.Stop()
        tmrEnemy4.Stop()
        cmdRestart.Visible = True
    End Sub

    Private Sub cmdRestart_Click(sender As Object, e As EventArgs) Handles cmdRestart.Click
        gamePoints = 0 'reset game points to 0
        Me.Controls.Clear() 'clear all controls on the form
        InitializeComponent()
        Form1_Load(e, e)
    End Sub

    Private Sub PlayBackgroundSound()
        My.Computer.Audio.Play("H:\Unit 8\Speed Maniac\Speed Maniac\Resources\GameMusic.wav")
    End Sub

    Sub StopBackgroundSound()
        My.Computer.Audio.Stop()
    End Sub

    Private Sub GameWon()
        lblGameWon.Visible = True
        roadTimer.Stop()
        tmrSpeedManiacRight.Stop()
        tmrSpeedManiacLeft.Stop()
        tmrEnemy1.Stop()
        tmrEnemy2.Stop()
        tmrEnemy3.Stop()
        tmrEnemy4.Stop()
        cmdNextLevel.Visible = True
    End Sub

    Private Sub cmdNextLevel_Click(sender As Object, e As EventArgs) Handles cmdNextLevel.Click
        Me.Controls.Clear()
        InitializeComponent()
        Dim NextLevel As New Form2
        NextLevel.Show()
        Me.Close()
    End Sub
End Class
