﻿Public Class Form3

    'global variables declaration
    Dim speedLvl3 As Integer
    Dim roadMarkingsLvl3(7) As PictureBox 'picture box array
    Dim gamePointsLvl3 As Integer = 0 'variable to store game points
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'assign each picturebox to an array position
        roadMarkingsLvl3(0) = picLvl3_1
        roadMarkingsLvl3(1) = picLvl3_2
        roadMarkingsLvl3(2) = picLvl3_3
        roadMarkingsLvl3(3) = picLvl3_4
        roadMarkingsLvl3(4) = picLvl3_5
        roadMarkingsLvl3(5) = picLvl3_6
        roadMarkingsLvl3(6) = picLvl3_7
        roadMarkingsLvl3(7) = picLvl3_8
        PlayBackgroundSoundLvl3()
    End Sub

    Private Sub tmrRoadLvl3_Tick(sender As Object, e As EventArgs) Handles tmrRoadLvl3.Tick
        For MoveCountLvl3 As Integer = 0 To 7 'Loop to keep moving each road marking 
            roadMarkingsLvl3(MoveCountLvl3).Top += 2

            'Repeat road markings movement
            If roadMarkingsLvl3(MoveCountLvl3).Top >= Me.Height Then
                roadMarkingsLvl3(MoveCountLvl3).Top = -roadMarkingsLvl3(MoveCountLvl3).Height
            End If
        Next

        'check for collision between main car and enemy cars
        If (picMainCarLvl3.Bounds.IntersectsWith(picLvl3Enemy1.Bounds)) Then
            endOfTheGameLvl3()
            StopBackgroundSoundLvl3()
        End If
        If (picMainCarLvl3.Bounds.IntersectsWith(picLvl3Enemy2.Bounds)) Then
            endOfTheGameLvl3()
            StopBackgroundSoundLvl3()
        End If
        If (picMainCarLvl3.Bounds.IntersectsWith(picLvl3Enemy3.Bounds)) Then
            endOfTheGameLvl3()
            StopBackgroundSoundLvl3()
        End If
        If (picMainCarLvl3.Bounds.IntersectsWith(picLvl3Enemy4.Bounds)) Then
            endOfTheGameLvl3()
            StopBackgroundSoundLvl3()
        End If
        If (picMainCarLvl3.Bounds.IntersectsWith(picLvl3Enemy5.Bounds)) Then
            endOfTheGameLvl3()
        End If

        'check if the game is won
        If gamePointsLvl3 = 30 Then
            GameWonLvl3()
        End If
    End Sub

    Private Sub Form3_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        'Start right timer if right key is pressed
        If e.KeyCode = Keys.Right Then
            tmrSpeedManiacRightLvl3.Start()
        End If

        'Start left timer if left key is pressed
        If e.KeyCode = Keys.Left Then
            tmrSpeedManiacLeftLvl3.Start()
        End If
    End Sub

    Private Sub tmrSpeedManiacLeftLvl3_Tick(sender As Object, e As EventArgs) Handles tmrSpeedManiacLeftLvl3.Tick
        If (picMainCarLvl3.Location.X > 1) Then
            picMainCarLvl3.Left -= 5
        End If
    End Sub

    Private Sub tmrSpeedManiacRightLvl3_Tick(sender As Object, e As EventArgs) Handles tmrSpeedManiacRightLvl3.Tick
        If (picMainCarLvl3.Location.X < 150) Then
            picMainCarLvl3.Left += 5
        End If
    End Sub

    Private Sub Form3_KeyUp(sender As Object, e As KeyEventArgs) Handles MyBase.KeyUp
        'Stop when key is released 
        tmrSpeedManiacLeftLvl3.Stop()
        tmrSpeedManiacRightLvl3.Stop()
    End Sub

    Private Sub tmrLvl3Enemy1_Tick(sender As Object, e As EventArgs) Handles tmrLvl3Enemy1.Tick
        'move enemy cars, reposition them when they leave the form
        picLvl3Enemy1.Top += 3 'set speed of car
        If picLvl3Enemy1.Top > Me.Height Then

            gamePointsLvl3 += 3 'Add a point to the game if player avoids collsiion
            lblGameScoreLvl3.Text = "Point: " & gamePointsLvl3 'Display score in the score

            picLvl3Enemy1.Top = -picLvl3Enemy1.Height
            picLvl3Enemy1.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + picLvl3Enemy1.Height)
            picLvl3Enemy1.Left = CInt(Math.Ceiling(Rnd() * 50)) + 0
        End If
    End Sub

    Private Sub tmrLvl3Enemy2_Tick(sender As Object, e As EventArgs) Handles tmrLvl3Enemy2.Tick
        picLvl3Enemy2.Top += 2
        If picLvl3Enemy2.Top > Me.Height Then

            gamePointsLvl3 += 1 'Add a point to the game if player avoids collsiion
            lblGameScoreLvl3.Text = "Point: " & gamePointsLvl3 'Display score in the score

            picLvl3Enemy2.Top = -picLvl3Enemy2.Height
            picLvl3Enemy2.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + picLvl3Enemy2.Height)
            picLvl3Enemy2.Left = CInt(Math.Ceiling(Rnd() * 40)) + 80

        End If
    End Sub

    Private Sub tmrLvl3Enemy3_Tick(sender As Object, e As EventArgs) Handles tmrLvl3Enemy3.Tick
        picLvl3Enemy3.Top += 3.5
        If picLvl3Enemy3.Top > Me.Height Then

            gamePointsLvl3 += 1 'Add a point to the game if player avoids collsiion
            lblGameScoreLvl3.Text = "Point: " & gamePointsLvl3 'Display score in the score

            picLvl3Enemy3.Top = -picLvl3Enemy3.Height
            picLvl3Enemy3.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + picLvl3Enemy2.Height)
            picLvl3Enemy3.Left = CInt(Math.Ceiling(Rnd() * 90)) + 100

        End If
    End Sub

    Private Sub tmrLvl3Enemy4_Tick(sender As Object, e As EventArgs) Handles tmrLvl3Enemy4.Tick
        picLvl3Enemy4.Top += 4
        If picLvl3Enemy4.Top > Me.Height Then

            gamePointsLvl3 += 1 'Add a point to the game if player avoids collsiion
            lblGameScoreLvl3.Text = "Point: " & gamePointsLvl3 'Display score in the score

            picLvl3Enemy4.Top = -picLvl3Enemy4.Height
            picLvl3Enemy4.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + picLvl3Enemy4.Height)
            picLvl3Enemy4.Left = CInt(Math.Ceiling(Rnd() * 50)) + 20

        End If
    End Sub

    'Game over function
    Private Sub endOfTheGameLvl3()
        lblGameOverLvl3.Visible = True
        tmrRoadLvl3.Stop()
        tmrSpeedManiacRightLvl3.Stop()
        tmrSpeedManiacLeftLvl3.Stop()
        tmrLvl3Enemy1.Stop()
        tmrLvl3Enemy2.Stop()
        tmrLvl3Enemy3.Stop()
        tmrLvl3Enemy4.Stop()
        tmrLvl3Enemy5.Stop()
        cmdRestartLvl3.Visible = True
    End Sub

    Private Sub cmdRestartLvl3_Click(sender As Object, e As EventArgs) Handles cmdRestartLvl3.Click
        gamePointsLvl3 = 0 'reset game points to 0
        Me.Controls.Clear() 'clear all controls on the form
        InitializeComponent()
        Form3_Load(e, e)
    End Sub

    Private Sub tmrLvl3Enemy5_Tick(sender As Object, e As EventArgs) Handles tmrLvl3Enemy5.Tick
        picLvl3Enemy5.Top += 4
        If picLvl3Enemy5.Top > Me.Height Then

            gamePointsLvl3 += 1 'Add a point to the game if player avoids collsiion
            lblGameScoreLvl3.Text = "Point: " & gamePointsLvl3 'Display score in the score

            picLvl3Enemy5.Top = -picLvl3Enemy5.Height
            picLvl3Enemy5.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + picLvl3Enemy5.Height)
            picLvl3Enemy5.Left = CInt(Math.Ceiling(Rnd() * 50)) + 20

        End If
    End Sub
    Private Sub PlayBackgroundSoundLvl3()
        ' My.Computer.Audio.Play("H:\Unit 8\Speed Maniac\Speed Maniac\Resources\GameMusic.wav")
    End Sub

    Sub StopBackgroundSoundLvl3()
        My.Computer.Audio.Stop()
    End Sub

    Private Sub GameWonLvl3()
        lblGameWonLvl3.Visible = True
        tmrRoadLvl3.Stop()
        tmrSpeedManiacRightLvl3.Stop()
        tmrSpeedManiacLeftLvl3.Stop()
        tmrLvl3Enemy1.Stop()
        tmrLvl3Enemy2.Stop()
        tmrLvl3Enemy3.Stop()
        tmrLvl3Enemy4.Stop()
        cmdGoBack.Visible = True
    End Sub

    Private Sub cmdGoBack_Click(sender As Object, e As EventArgs) Handles cmdGoBack.Click
        Me.Controls.Clear()
        InitializeComponent()
        Dim Menu As New GameMenu
        Menu.Show()
        Me.Close()
    End Sub
End Class