﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.roadTimer = New System.Windows.Forms.Timer(Me.components)
        Me.picRacingCar = New System.Windows.Forms.PictureBox()
        Me.tmrSpeedManiacLeft = New System.Windows.Forms.Timer(Me.components)
        Me.tmrSpeedManiacRight = New System.Windows.Forms.Timer(Me.components)
        Me.picEnemy1 = New System.Windows.Forms.PictureBox()
        Me.picEnemy3 = New System.Windows.Forms.PictureBox()
        Me.picEnemy2 = New System.Windows.Forms.PictureBox()
        Me.picEnemy4 = New System.Windows.Forms.PictureBox()
        Me.tmrEnemy1 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrEnemy2 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrEnemy3 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrEnemy4 = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblEndOfTheGame = New System.Windows.Forms.Label()
        Me.cmdRestart = New System.Windows.Forms.Button()
        Me.lblScore = New System.Windows.Forms.Label()
        Me.lblGameWon = New System.Windows.Forms.Label()
        Me.cmdNextLevel = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRacingCar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEnemy1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEnemy3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEnemy2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEnemy4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.Location = New System.Drawing.Point(118, 63)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(8, 47)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.White
        Me.PictureBox2.Location = New System.Drawing.Point(118, 253)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(8, 50)
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.White
        Me.PictureBox3.Location = New System.Drawing.Point(118, -14)
        Me.PictureBox3.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(8, 44)
        Me.PictureBox3.TabIndex = 2
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.White
        Me.PictureBox4.Location = New System.Drawing.Point(58, -14)
        Me.PictureBox4.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(8, 44)
        Me.PictureBox4.TabIndex = 3
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.White
        Me.PictureBox5.Location = New System.Drawing.Point(58, 253)
        Me.PictureBox5.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(8, 50)
        Me.PictureBox5.TabIndex = 4
        Me.PictureBox5.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.White
        Me.PictureBox6.Location = New System.Drawing.Point(118, 155)
        Me.PictureBox6.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(8, 51)
        Me.PictureBox6.TabIndex = 5
        Me.PictureBox6.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.BackColor = System.Drawing.Color.White
        Me.PictureBox7.Location = New System.Drawing.Point(58, 63)
        Me.PictureBox7.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(8, 47)
        Me.PictureBox7.TabIndex = 6
        Me.PictureBox7.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.White
        Me.PictureBox8.Location = New System.Drawing.Point(58, 155)
        Me.PictureBox8.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(8, 51)
        Me.PictureBox8.TabIndex = 7
        Me.PictureBox8.TabStop = False
        '
        'roadTimer
        '
        Me.roadTimer.Enabled = True
        Me.roadTimer.Interval = 20
        '
        'picRacingCar
        '
        Me.picRacingCar.BackColor = System.Drawing.Color.Green
        Me.picRacingCar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.picRacingCar.Image = CType(resources.GetObject("picRacingCar.Image"), System.Drawing.Image)
        Me.picRacingCar.Location = New System.Drawing.Point(70, 242)
        Me.picRacingCar.Margin = New System.Windows.Forms.Padding(2)
        Me.picRacingCar.Name = "picRacingCar"
        Me.picRacingCar.Size = New System.Drawing.Size(30, 40)
        Me.picRacingCar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picRacingCar.TabIndex = 8
        Me.picRacingCar.TabStop = False
        '
        'tmrSpeedManiacLeft
        '
        Me.tmrSpeedManiacLeft.Interval = 10
        '
        'tmrSpeedManiacRight
        '
        Me.tmrSpeedManiacRight.Interval = 10
        '
        'picEnemy1
        '
        Me.picEnemy1.Image = CType(resources.GetObject("picEnemy1.Image"), System.Drawing.Image)
        Me.picEnemy1.Location = New System.Drawing.Point(9, 38)
        Me.picEnemy1.Margin = New System.Windows.Forms.Padding(2)
        Me.picEnemy1.Name = "picEnemy1"
        Me.picEnemy1.Size = New System.Drawing.Size(30, 40)
        Me.picEnemy1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picEnemy1.TabIndex = 9
        Me.picEnemy1.TabStop = False
        '
        'picEnemy3
        '
        Me.picEnemy3.Image = CType(resources.GetObject("picEnemy3.Image"), System.Drawing.Image)
        Me.picEnemy3.Location = New System.Drawing.Point(145, 8)
        Me.picEnemy3.Margin = New System.Windows.Forms.Padding(2)
        Me.picEnemy3.Name = "picEnemy3"
        Me.picEnemy3.Size = New System.Drawing.Size(30, 40)
        Me.picEnemy3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picEnemy3.TabIndex = 10
        Me.picEnemy3.TabStop = False
        '
        'picEnemy2
        '
        Me.picEnemy2.Image = CType(resources.GetObject("picEnemy2.Image"), System.Drawing.Image)
        Me.picEnemy2.Location = New System.Drawing.Point(70, 8)
        Me.picEnemy2.Margin = New System.Windows.Forms.Padding(2)
        Me.picEnemy2.Name = "picEnemy2"
        Me.picEnemy2.Size = New System.Drawing.Size(30, 40)
        Me.picEnemy2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picEnemy2.TabIndex = 11
        Me.picEnemy2.TabStop = False
        '
        'picEnemy4
        '
        Me.picEnemy4.BackColor = System.Drawing.Color.Green
        Me.picEnemy4.Image = CType(resources.GetObject("picEnemy4.Image"), System.Drawing.Image)
        Me.picEnemy4.Location = New System.Drawing.Point(70, 72)
        Me.picEnemy4.Margin = New System.Windows.Forms.Padding(2)
        Me.picEnemy4.Name = "picEnemy4"
        Me.picEnemy4.Size = New System.Drawing.Size(30, 40)
        Me.picEnemy4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picEnemy4.TabIndex = 12
        Me.picEnemy4.TabStop = False
        '
        'tmrEnemy1
        '
        Me.tmrEnemy1.Enabled = True
        Me.tmrEnemy1.Interval = 10
        '
        'tmrEnemy2
        '
        Me.tmrEnemy2.Enabled = True
        Me.tmrEnemy2.Interval = 10
        '
        'tmrEnemy3
        '
        Me.tmrEnemy3.Enabled = True
        Me.tmrEnemy3.Interval = 10
        '
        'tmrEnemy4
        '
        Me.tmrEnemy4.Enabled = True
        Me.tmrEnemy4.Interval = 10
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(-90, 63)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Label1"
        '
        'lblEndOfTheGame
        '
        Me.lblEndOfTheGame.AutoSize = True
        Me.lblEndOfTheGame.BackColor = System.Drawing.Color.Yellow
        Me.lblEndOfTheGame.Font = New System.Drawing.Font("Segoe UI", 16.2!, System.Drawing.FontStyle.Bold)
        Me.lblEndOfTheGame.ForeColor = System.Drawing.Color.Red
        Me.lblEndOfTheGame.Location = New System.Drawing.Point(26, 81)
        Me.lblEndOfTheGame.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEndOfTheGame.Name = "lblEndOfTheGame"
        Me.lblEndOfTheGame.Size = New System.Drawing.Size(136, 30)
        Me.lblEndOfTheGame.TabIndex = 14
        Me.lblEndOfTheGame.Text = "Game Over!"
        Me.lblEndOfTheGame.Visible = False
        '
        'cmdRestart
        '
        Me.cmdRestart.BackColor = System.Drawing.Color.Yellow
        Me.cmdRestart.Font = New System.Drawing.Font("Segoe UI", 16.2!, System.Drawing.FontStyle.Bold)
        Me.cmdRestart.ForeColor = System.Drawing.Color.Red
        Me.cmdRestart.Location = New System.Drawing.Point(44, 203)
        Me.cmdRestart.Margin = New System.Windows.Forms.Padding(2)
        Me.cmdRestart.Name = "cmdRestart"
        Me.cmdRestart.Size = New System.Drawing.Size(100, 35)
        Me.cmdRestart.TabIndex = 15
        Me.cmdRestart.Text = "Restart"
        Me.cmdRestart.UseVisualStyleBackColor = False
        Me.cmdRestart.Visible = False
        '
        'lblScore
        '
        Me.lblScore.AutoSize = True
        Me.lblScore.BackColor = System.Drawing.Color.Yellow
        Me.lblScore.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold)
        Me.lblScore.ForeColor = System.Drawing.Color.Red
        Me.lblScore.Location = New System.Drawing.Point(96, 6)
        Me.lblScore.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblScore.Name = "lblScore"
        Me.lblScore.Size = New System.Drawing.Size(88, 25)
        Me.lblScore.TabIndex = 16
        Me.lblScore.Text = "Points: 0"
        '
        'lblGameWon
        '
        Me.lblGameWon.AutoSize = True
        Me.lblGameWon.BackColor = System.Drawing.Color.Yellow
        Me.lblGameWon.Font = New System.Drawing.Font("SimSun", 21.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGameWon.ForeColor = System.Drawing.Color.Red
        Me.lblGameWon.Location = New System.Drawing.Point(30, 144)
        Me.lblGameWon.Name = "lblGameWon"
        Me.lblGameWon.Size = New System.Drawing.Size(132, 28)
        Me.lblGameWon.TabIndex = 17
        Me.lblGameWon.Text = "You won!"
        Me.lblGameWon.Visible = False
        '
        'cmdNextLevel
        '
        Me.cmdNextLevel.BackColor = System.Drawing.Color.Yellow
        Me.cmdNextLevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdNextLevel.ForeColor = System.Drawing.Color.Red
        Me.cmdNextLevel.Location = New System.Drawing.Point(0, 206)
        Me.cmdNextLevel.Name = "cmdNextLevel"
        Me.cmdNextLevel.Size = New System.Drawing.Size(184, 30)
        Me.cmdNextLevel.TabIndex = 18
        Me.cmdNextLevel.Text = "Next Level"
        Me.cmdNextLevel.UseVisualStyleBackColor = False
        Me.cmdNextLevel.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Green
        Me.ClientSize = New System.Drawing.Size(179, 293)
        Me.Controls.Add(Me.cmdNextLevel)
        Me.Controls.Add(Me.lblGameWon)
        Me.Controls.Add(Me.lblScore)
        Me.Controls.Add(Me.cmdRestart)
        Me.Controls.Add(Me.lblEndOfTheGame)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.picEnemy4)
        Me.Controls.Add(Me.picEnemy2)
        Me.Controls.Add(Me.picEnemy3)
        Me.Controls.Add(Me.picEnemy1)
        Me.Controls.Add(Me.picRacingCar)
        Me.Controls.Add(Me.PictureBox8)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.MaximumSize = New System.Drawing.Size(195, 332)
        Me.MinimumSize = New System.Drawing.Size(195, 332)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRacingCar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEnemy1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEnemy3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEnemy2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEnemy4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents roadTimer As Timer
    Friend WithEvents picRacingCar As PictureBox
    Friend WithEvents tmrSpeedManiacLeft As Timer
    Friend WithEvents tmrSpeedManiacRight As Timer
    Friend WithEvents picEnemy1 As PictureBox
    Friend WithEvents picEnemy3 As PictureBox
    Friend WithEvents picEnemy2 As PictureBox
    Friend WithEvents picEnemy4 As PictureBox
    Friend WithEvents tmrEnemy1 As Timer
    Friend WithEvents tmrEnemy2 As Timer
    Friend WithEvents tmrEnemy3 As Timer
    Friend WithEvents tmrEnemy4 As Timer
    Friend WithEvents Label1 As Label
    Friend WithEvents lblEndOfTheGame As Label
    Friend WithEvents cmdRestart As Button
    Friend WithEvents lblScore As Label
    Friend WithEvents lblGameWon As Label
    Friend WithEvents cmdNextLevel As Button
End Class
