﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.picLvl2_6 = New System.Windows.Forms.PictureBox()
        Me.picLvl2_8 = New System.Windows.Forms.PictureBox()
        Me.picLvl2_4 = New System.Windows.Forms.PictureBox()
        Me.picLvl2_5 = New System.Windows.Forms.PictureBox()
        Me.picLvl2_1 = New System.Windows.Forms.PictureBox()
        Me.picLvl2_3 = New System.Windows.Forms.PictureBox()
        Me.picLvl2_2 = New System.Windows.Forms.PictureBox()
        Me.picLvl2_7 = New System.Windows.Forms.PictureBox()
        Me.picMainCarLvl2 = New System.Windows.Forms.PictureBox()
        Me.picLvl2Enemy4 = New System.Windows.Forms.PictureBox()
        Me.picLvl2Enemy1 = New System.Windows.Forms.PictureBox()
        Me.picLvl2Enemy3 = New System.Windows.Forms.PictureBox()
        Me.picLvl2Enemy2 = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblGameScoreLvl2 = New System.Windows.Forms.Label()
        Me.lblGameOverLvl2 = New System.Windows.Forms.Label()
        Me.cmdRestartLvl2 = New System.Windows.Forms.Button()
        Me.tmrRoadLvl2 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrSpeedManiacLeftLvl2 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrSpeedManiacRightLvl2 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrLvl2Enemy1 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrLvl2Enemy2 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrLvl2Enemy3 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrLvl2Enemy4 = New System.Windows.Forms.Timer(Me.components)
        Me.lblGameWonLvl2 = New System.Windows.Forms.Label()
        Me.cmdNextLevel2 = New System.Windows.Forms.Button()
        CType(Me.picLvl2_6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl2_8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl2_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl2_5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl2_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl2_7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMainCarLvl2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl2Enemy4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl2Enemy1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl2Enemy3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLvl2Enemy2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picLvl2_6
        '
        Me.picLvl2_6.BackColor = System.Drawing.Color.White
        Me.picLvl2_6.Location = New System.Drawing.Point(52, 81)
        Me.picLvl2_6.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl2_6.Name = "picLvl2_6"
        Me.picLvl2_6.Size = New System.Drawing.Size(8, 49)
        Me.picLvl2_6.TabIndex = 0
        Me.picLvl2_6.TabStop = False
        '
        'picLvl2_8
        '
        Me.picLvl2_8.BackColor = System.Drawing.Color.White
        Me.picLvl2_8.Location = New System.Drawing.Point(52, -4)
        Me.picLvl2_8.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl2_8.Name = "picLvl2_8"
        Me.picLvl2_8.Size = New System.Drawing.Size(8, 49)
        Me.picLvl2_8.TabIndex = 1
        Me.picLvl2_8.TabStop = False
        '
        'picLvl2_4
        '
        Me.picLvl2_4.BackColor = System.Drawing.Color.White
        Me.picLvl2_4.Location = New System.Drawing.Point(52, 158)
        Me.picLvl2_4.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl2_4.Name = "picLvl2_4"
        Me.picLvl2_4.Size = New System.Drawing.Size(8, 49)
        Me.picLvl2_4.TabIndex = 2
        Me.picLvl2_4.TabStop = False
        '
        'picLvl2_5
        '
        Me.picLvl2_5.BackColor = System.Drawing.Color.White
        Me.picLvl2_5.Location = New System.Drawing.Point(111, 81)
        Me.picLvl2_5.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl2_5.Name = "picLvl2_5"
        Me.picLvl2_5.Size = New System.Drawing.Size(8, 49)
        Me.picLvl2_5.TabIndex = 3
        Me.picLvl2_5.TabStop = False
        '
        'picLvl2_1
        '
        Me.picLvl2_1.BackColor = System.Drawing.Color.White
        Me.picLvl2_1.Location = New System.Drawing.Point(111, 243)
        Me.picLvl2_1.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl2_1.Name = "picLvl2_1"
        Me.picLvl2_1.Size = New System.Drawing.Size(8, 49)
        Me.picLvl2_1.TabIndex = 4
        Me.picLvl2_1.TabStop = False
        '
        'picLvl2_3
        '
        Me.picLvl2_3.BackColor = System.Drawing.Color.White
        Me.picLvl2_3.Location = New System.Drawing.Point(111, 158)
        Me.picLvl2_3.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl2_3.Name = "picLvl2_3"
        Me.picLvl2_3.Size = New System.Drawing.Size(8, 49)
        Me.picLvl2_3.TabIndex = 5
        Me.picLvl2_3.TabStop = False
        '
        'picLvl2_2
        '
        Me.picLvl2_2.BackColor = System.Drawing.Color.White
        Me.picLvl2_2.Location = New System.Drawing.Point(52, 243)
        Me.picLvl2_2.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl2_2.Name = "picLvl2_2"
        Me.picLvl2_2.Size = New System.Drawing.Size(8, 49)
        Me.picLvl2_2.TabIndex = 6
        Me.picLvl2_2.TabStop = False
        '
        'picLvl2_7
        '
        Me.picLvl2_7.BackColor = System.Drawing.Color.White
        Me.picLvl2_7.Location = New System.Drawing.Point(111, -4)
        Me.picLvl2_7.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl2_7.Name = "picLvl2_7"
        Me.picLvl2_7.Size = New System.Drawing.Size(8, 49)
        Me.picLvl2_7.TabIndex = 7
        Me.picLvl2_7.TabStop = False
        '
        'picMainCarLvl2
        '
        Me.picMainCarLvl2.Image = CType(resources.GetObject("picMainCarLvl2.Image"), System.Drawing.Image)
        Me.picMainCarLvl2.Location = New System.Drawing.Point(73, 243)
        Me.picMainCarLvl2.Margin = New System.Windows.Forms.Padding(2)
        Me.picMainCarLvl2.Name = "picMainCarLvl2"
        Me.picMainCarLvl2.Size = New System.Drawing.Size(30, 40)
        Me.picMainCarLvl2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picMainCarLvl2.TabIndex = 8
        Me.picMainCarLvl2.TabStop = False
        '
        'picLvl2Enemy4
        '
        Me.picLvl2Enemy4.Image = CType(resources.GetObject("picLvl2Enemy4.Image"), System.Drawing.Image)
        Me.picLvl2Enemy4.Location = New System.Drawing.Point(64, 5)
        Me.picLvl2Enemy4.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl2Enemy4.Name = "picLvl2Enemy4"
        Me.picLvl2Enemy4.Size = New System.Drawing.Size(30, 40)
        Me.picLvl2Enemy4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLvl2Enemy4.TabIndex = 9
        Me.picLvl2Enemy4.TabStop = False
        '
        'picLvl2Enemy1
        '
        Me.picLvl2Enemy1.Image = CType(resources.GetObject("picLvl2Enemy1.Image"), System.Drawing.Image)
        Me.picLvl2Enemy1.Location = New System.Drawing.Point(73, 91)
        Me.picLvl2Enemy1.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl2Enemy1.Name = "picLvl2Enemy1"
        Me.picLvl2Enemy1.Size = New System.Drawing.Size(30, 40)
        Me.picLvl2Enemy1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLvl2Enemy1.TabIndex = 10
        Me.picLvl2Enemy1.TabStop = False
        '
        'picLvl2Enemy3
        '
        Me.picLvl2Enemy3.Image = CType(resources.GetObject("picLvl2Enemy3.Image"), System.Drawing.Image)
        Me.picLvl2Enemy3.Location = New System.Drawing.Point(9, 46)
        Me.picLvl2Enemy3.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl2Enemy3.Name = "picLvl2Enemy3"
        Me.picLvl2Enemy3.Size = New System.Drawing.Size(30, 40)
        Me.picLvl2Enemy3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLvl2Enemy3.TabIndex = 11
        Me.picLvl2Enemy3.TabStop = False
        '
        'picLvl2Enemy2
        '
        Me.picLvl2Enemy2.Image = CType(resources.GetObject("picLvl2Enemy2.Image"), System.Drawing.Image)
        Me.picLvl2Enemy2.Location = New System.Drawing.Point(135, 58)
        Me.picLvl2Enemy2.Margin = New System.Windows.Forms.Padding(2)
        Me.picLvl2Enemy2.Name = "picLvl2Enemy2"
        Me.picLvl2Enemy2.Size = New System.Drawing.Size(30, 40)
        Me.picLvl2Enemy2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLvl2Enemy2.TabIndex = 12
        Me.picLvl2Enemy2.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold)
        Me.Label3.ForeColor = System.Drawing.Color.Red
        Me.Label3.Location = New System.Drawing.Point(-58, -72)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 25)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Points:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(-20, -63)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 13)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "Label4"
        '
        'lblGameScoreLvl2
        '
        Me.lblGameScoreLvl2.AutoSize = True
        Me.lblGameScoreLvl2.BackColor = System.Drawing.Color.White
        Me.lblGameScoreLvl2.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold)
        Me.lblGameScoreLvl2.ForeColor = System.Drawing.Color.Black
        Me.lblGameScoreLvl2.Location = New System.Drawing.Point(89, 5)
        Me.lblGameScoreLvl2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblGameScoreLvl2.Name = "lblGameScoreLvl2"
        Me.lblGameScoreLvl2.Size = New System.Drawing.Size(88, 25)
        Me.lblGameScoreLvl2.TabIndex = 17
        Me.lblGameScoreLvl2.Text = "Points: 0"
        '
        'lblGameOverLvl2
        '
        Me.lblGameOverLvl2.AutoSize = True
        Me.lblGameOverLvl2.BackColor = System.Drawing.Color.White
        Me.lblGameOverLvl2.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold)
        Me.lblGameOverLvl2.Location = New System.Drawing.Point(36, 58)
        Me.lblGameOverLvl2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblGameOverLvl2.Name = "lblGameOverLvl2"
        Me.lblGameOverLvl2.Size = New System.Drawing.Size(116, 25)
        Me.lblGameOverLvl2.TabIndex = 18
        Me.lblGameOverLvl2.Text = "Game Over!"
        Me.lblGameOverLvl2.Visible = False
        '
        'cmdRestartLvl2
        '
        Me.cmdRestartLvl2.BackColor = System.Drawing.Color.White
        Me.cmdRestartLvl2.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold)
        Me.cmdRestartLvl2.Location = New System.Drawing.Point(41, 175)
        Me.cmdRestartLvl2.Margin = New System.Windows.Forms.Padding(2)
        Me.cmdRestartLvl2.Name = "cmdRestartLvl2"
        Me.cmdRestartLvl2.Size = New System.Drawing.Size(100, 35)
        Me.cmdRestartLvl2.TabIndex = 19
        Me.cmdRestartLvl2.Text = "Restart"
        Me.cmdRestartLvl2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdRestartLvl2.UseVisualStyleBackColor = False
        Me.cmdRestartLvl2.Visible = False
        '
        'tmrRoadLvl2
        '
        Me.tmrRoadLvl2.Enabled = True
        Me.tmrRoadLvl2.Interval = 10
        '
        'tmrSpeedManiacLeftLvl2
        '
        Me.tmrSpeedManiacLeftLvl2.Interval = 10
        '
        'tmrSpeedManiacRightLvl2
        '
        Me.tmrSpeedManiacRightLvl2.Interval = 10
        '
        'tmrLvl2Enemy1
        '
        Me.tmrLvl2Enemy1.Enabled = True
        Me.tmrLvl2Enemy1.Interval = 10
        '
        'tmrLvl2Enemy2
        '
        Me.tmrLvl2Enemy2.Enabled = True
        Me.tmrLvl2Enemy2.Interval = 10
        '
        'tmrLvl2Enemy3
        '
        Me.tmrLvl2Enemy3.Enabled = True
        Me.tmrLvl2Enemy3.Interval = 10
        '
        'tmrLvl2Enemy4
        '
        Me.tmrLvl2Enemy4.Enabled = True
        Me.tmrLvl2Enemy4.Interval = 10
        '
        'lblGameWonLvl2
        '
        Me.lblGameWonLvl2.AutoSize = True
        Me.lblGameWonLvl2.BackColor = System.Drawing.Color.White
        Me.lblGameWonLvl2.Font = New System.Drawing.Font("SimSun", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGameWonLvl2.Location = New System.Drawing.Point(37, 123)
        Me.lblGameWonLvl2.Name = "lblGameWonLvl2"
        Me.lblGameWonLvl2.Size = New System.Drawing.Size(106, 21)
        Me.lblGameWonLvl2.TabIndex = 20
        Me.lblGameWonLvl2.Text = "You won!"
        Me.lblGameWonLvl2.Visible = False
        '
        'cmdNextLevel2
        '
        Me.cmdNextLevel2.BackColor = System.Drawing.Color.White
        Me.cmdNextLevel2.Font = New System.Drawing.Font("SimSun", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdNextLevel2.Location = New System.Drawing.Point(9, 183)
        Me.cmdNextLevel2.Name = "cmdNextLevel2"
        Me.cmdNextLevel2.Size = New System.Drawing.Size(163, 27)
        Me.cmdNextLevel2.TabIndex = 21
        Me.cmdNextLevel2.Text = "Next Level"
        Me.cmdNextLevel2.UseVisualStyleBackColor = False
        Me.cmdNextLevel2.Visible = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(178, 288)
        Me.Controls.Add(Me.cmdNextLevel2)
        Me.Controls.Add(Me.lblGameWonLvl2)
        Me.Controls.Add(Me.cmdRestartLvl2)
        Me.Controls.Add(Me.lblGameOverLvl2)
        Me.Controls.Add(Me.lblGameScoreLvl2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.picLvl2Enemy2)
        Me.Controls.Add(Me.picLvl2Enemy3)
        Me.Controls.Add(Me.picLvl2Enemy1)
        Me.Controls.Add(Me.picLvl2Enemy4)
        Me.Controls.Add(Me.picMainCarLvl2)
        Me.Controls.Add(Me.picLvl2_7)
        Me.Controls.Add(Me.picLvl2_2)
        Me.Controls.Add(Me.picLvl2_3)
        Me.Controls.Add(Me.picLvl2_1)
        Me.Controls.Add(Me.picLvl2_5)
        Me.Controls.Add(Me.picLvl2_4)
        Me.Controls.Add(Me.picLvl2_8)
        Me.Controls.Add(Me.picLvl2_6)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Form2"
        Me.Text = "Form2"
        CType(Me.picLvl2_6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl2_8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl2_4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl2_5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl2_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl2_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl2_7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMainCarLvl2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl2Enemy4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl2Enemy1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl2Enemy3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLvl2Enemy2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picLvl2_6 As PictureBox
    Friend WithEvents picLvl2_8 As PictureBox
    Friend WithEvents picLvl2_4 As PictureBox
    Friend WithEvents picLvl2_5 As PictureBox
    Friend WithEvents picLvl2_1 As PictureBox
    Friend WithEvents picLvl2_3 As PictureBox
    Friend WithEvents picLvl2_2 As PictureBox
    Friend WithEvents picLvl2_7 As PictureBox
    Friend WithEvents picMainCarLvl2 As PictureBox
    Friend WithEvents picLvl2Enemy4 As PictureBox
    Friend WithEvents picLvl2Enemy1 As PictureBox
    Friend WithEvents picLvl2Enemy3 As PictureBox
    Friend WithEvents picLvl2Enemy2 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblGameScoreLvl2 As Label
    Friend WithEvents cmd As Label
    Friend WithEvents cmdRestartLvl2 As Button
    Friend WithEvents lblGameOverLvl2 As Label
    Friend WithEvents tmrRoadLvl2 As Timer
    Friend WithEvents tmrSpeedManiacLeftLvl2 As Timer
    Friend WithEvents tmrSpeedManiacRightLvl2 As Timer
    Friend WithEvents tmrLvl2Enemy1 As Timer
    Friend WithEvents tmrLvl2Enemy2 As Timer
    Friend WithEvents tmrLvl2Enemy3 As Timer
    Friend WithEvents tmrLvl2Enemy4 As Timer
    Friend WithEvents lblGameWonLvl2 As Label
    Friend WithEvents cmdNextLevel2 As Button
End Class
