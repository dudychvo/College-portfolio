﻿Public Class GameMenu
    Private Sub cmdLevel1_Click(sender As Object, e As EventArgs) Handles cmdLevel1.Click
        Dim gameLevel1 As New Form1
        gameLevel1.Show()
    End Sub

    Private Sub cmdLevel2_Click(sender As Object, e As EventArgs) Handles cmdLevel2.Click
        Dim gameLevel2 As New Form2
        gameLevel2.Show()
    End Sub

    Private Sub cmdLevel3_Click(sender As Object, e As EventArgs) Handles cmdLevel3.Click
        Dim gameLevel3 As New Form3
        gameLevel3.Show()
    End Sub

    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        GameMenu.ActiveForm.Close()
    End Sub

End Class