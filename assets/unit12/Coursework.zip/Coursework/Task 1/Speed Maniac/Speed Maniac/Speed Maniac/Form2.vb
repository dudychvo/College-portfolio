﻿Public Class Form2
    'global variables declaration
    Dim speedLvl2 As Integer
    Dim roadMarkingsLvl2(7) As PictureBox 'picture box array
    Dim gamePointsLvl2 As Integer = 0 'variable to store game points
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'assign each picturebox to an array position
        roadMarkingsLvl2(0) = picLvl2_1
        roadMarkingsLvl2(1) = picLvl2_2
        roadMarkingsLvl2(2) = picLvl2_3
        roadMarkingsLvl2(3) = picLvl2_4
        roadMarkingsLvl2(4) = picLvl2_5
        roadMarkingsLvl2(5) = picLvl2_6
        roadMarkingsLvl2(6) = picLvl2_7
        roadMarkingsLvl2(7) = picLvl2_8
        PlayBackgroundSoundLvl2()
    End Sub

    Private Sub tmrRoadLvl2_Tick(sender As Object, e As EventArgs) Handles tmrRoadLvl2.Tick
        For MoveCountLvl2 As Integer = 0 To 7 'Loop to keep moving each road marking 
            roadMarkingsLvl2(MoveCountLvl2).Top += 2

            'Repeat road markings movement
            If roadMarkingsLvl2(MoveCountLvl2).Top >= Me.Height Then
                roadMarkingsLvl2(MoveCountLvl2).Top = -roadMarkingsLvl2(MoveCountLvl2).Height
            End If
        Next

        'check for collision between main car and enemy cars
        If (picMainCarLvl2.Bounds.IntersectsWith(picLvl2Enemy1.Bounds)) Then
            endOfTheGameLvl2()
            StopBackgroundSoundLvl2()
        End If
        If (picMainCarLvl2.Bounds.IntersectsWith(picLvl2Enemy2.Bounds)) Then
            endOfTheGameLvl2()
            StopBackgroundSoundLvl2()
        End If
        If (picMainCarLvl2.Bounds.IntersectsWith(picLvl2Enemy3.Bounds)) Then
            endOfTheGameLvl2()
            StopBackgroundSoundLvl2()
        End If
        If (picMainCarLvl2.Bounds.IntersectsWith(picLvl2Enemy4.Bounds)) Then
            endOfTheGameLvl2()
            StopBackgroundSoundLvl2()
        End If

        'Check if the game is won
        If gamePointsLvl2 = 20 Then
            GameWonLvl2()
        End If

    End Sub

    Private Sub Form2_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        'Start right timer if right key is pressed
        If e.KeyCode = Keys.Right Then
            tmrSpeedManiacRightLvl2.Start()
        End If

        'Start left timer if left key is pressed
        If e.KeyCode = Keys.Left Then
            tmrSpeedManiacLeftLvl2.Start()
        End If
    End Sub

    Private Sub tmrSpeedManiacLeftLvl2_Tick(sender As Object, e As EventArgs) Handles tmrSpeedManiacLeftLvl2.Tick
        If (picMainCarLvl2.Location.X > 1) Then
            picMainCarLvl2.Left -= 5
        End If
    End Sub

    Private Sub tmrSpeedManiacRightLvl2_Tick(sender As Object, e As EventArgs) Handles tmrSpeedManiacRightLvl2.Tick
        If (picMainCarLvl2.Location.X < 150) Then
            picMainCarLvl2.Left += 5
        End If
    End Sub

    Private Sub Form2_KeyUp(sender As Object, e As KeyEventArgs) Handles MyBase.KeyUp
        'Stop when key is released 
        tmrSpeedManiacLeftLvl2.Stop()
        tmrSpeedManiacRightLvl2.Stop()
    End Sub

    Private Sub tmrLvl2Enemy1_Tick(sender As Object, e As EventArgs) Handles tmrLvl2Enemy1.Tick
        'move enemy cars, reposition them when they leave the form
        picLvl2Enemy1.Top += 3 'set speed of car
        If picLvl2Enemy1.Top > Me.Height Then

            gamePointsLvl2 += 3 'Add a point to the game if player avoids collsiion
            lblGameScoreLvl2.Text = "Point: " & gamePointsLvl2 'Display score in the score

            picLvl2Enemy1.Top = -picLvl2Enemy1.Height
            picLvl2Enemy1.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + picLvl2Enemy1.Height)
            picLvl2Enemy1.Left = CInt(Math.Ceiling(Rnd() * 50)) + 0
        End If
    End Sub

    Private Sub tmrLvl2Enemy2_Tick(sender As Object, e As EventArgs) Handles tmrLvl2Enemy2.Tick
        picLvl2Enemy2.Top += 2
        If picLvl2Enemy2.Top > Me.Height Then

            gamePointsLvl2 += 1 'Add a point to the game if player avoids collsiion
            lblGameScoreLvl2.Text = "Point: " & gamePointsLvl2 'Display score in the score

            picLvl2Enemy2.Top = -picLvl2Enemy2.Height
            picLvl2Enemy2.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + picLvl2Enemy2.Height)
            picLvl2Enemy2.Left = CInt(Math.Ceiling(Rnd() * 40)) + 80

        End If
    End Sub

    Private Sub tmrLvl2Enemy3_Tick(sender As Object, e As EventArgs) Handles tmrLvl2Enemy3.Tick
        picLvl2Enemy3.Top += 3.5
        If picLvl2Enemy3.Top > Me.Height Then

            gamePointsLvl2 += 1 'Add a point to the game if player avoids collsiion
            lblGameScoreLvl2.Text = "Point: " & gamePointsLvl2 'Display score in the score

            picLvl2Enemy3.Top = -picLvl2Enemy3.Height
            picLvl2Enemy3.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + picLvl2Enemy2.Height)
            picLvl2Enemy3.Left = CInt(Math.Ceiling(Rnd() * 90)) + 100

        End If
    End Sub

    Private Sub tmrLvl2Enemy4_Tick(sender As Object, e As EventArgs) Handles tmrLvl2Enemy4.Tick
        picLvl2Enemy4.Top += 4
        If picLvl2Enemy4.Top > Me.Height Then

            gamePointsLvl2 += 1 'Add a point to the game if player avoids collsiion
            lblGameScoreLvl2.Text = "Point: " & gamePointsLvl2 'Display score in the score

            picLvl2Enemy4.Top = -picLvl2Enemy4.Height
            picLvl2Enemy4.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + picLvl2Enemy4.Height)
            picLvl2Enemy4.Left = CInt(Math.Ceiling(Rnd() * 50)) + 20

        End If
    End Sub

    'Game over function
    Private Sub endOfTheGameLvl2()
        lblGameOverLvl2.Visible = True
        tmrRoadLvl2.Stop()
        tmrSpeedManiacRightLvl2.Stop()
        tmrSpeedManiacLeftLvl2.Stop()
        tmrLvl2Enemy1.Stop()
        tmrLvl2Enemy2.Stop()
        tmrLvl2Enemy3.Stop()
        tmrLvl2Enemy4.Stop()
        cmdRestartLvl2.Visible = True
    End Sub

    Private Sub cmdRestartLvl2_Click(sender As Object, e As EventArgs) Handles cmdRestartLvl2.Click
        gamePointsLvl2 = 0 'reset game points to 0
        Me.Controls.Clear() 'clear all controls on the form
        InitializeComponent()
        Form2_Load(e, e)
    End Sub

    Private Sub PlayBackgroundSoundLvl2()
        ' My.Computer.Audio.Play("H:\Unit 8\Speed Maniac\Speed Maniac\Resources\GameMusic.wav")
    End Sub

    Sub StopBackgroundSoundLvl2()
        My.Computer.Audio.Stop()
    End Sub
    Private Sub GameWonLvl2()
        lblGameWonLvl2.Visible = True
        tmrRoadLvl2.Stop()
        tmrSpeedManiacRightLvl2.Stop()
        tmrSpeedManiacLeftLvl2.Stop()
        tmrLvl2Enemy1.Stop()
        tmrLvl2Enemy2.Stop()
        tmrLvl2Enemy3.Stop()
        tmrLvl2Enemy4.Stop()
        cmdNextLevel2.Visible = True
    End Sub

    Private Sub cmdNextLevel2_Click(sender As Object, e As EventArgs) Handles cmdNextLevel2.Click
        Me.Controls.Clear()
        InitializeComponent()
        Dim NextLevel2 As New Form3
        NextLevel2.Show()
        Me.Close()
    End Sub
End Class