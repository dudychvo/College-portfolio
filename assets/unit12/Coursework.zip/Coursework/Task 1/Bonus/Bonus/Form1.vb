﻿Public Class Form1

    Private Sub cmdCheckBonus_Click(sender As Object, e As EventArgs) Handles cmdCheckBonus.Click

        'Variable declaration
        Dim sales As Integer
        Dim salesPersonName As String
        Dim dataReader As String
        Dim dataSaved As String

        'Create location to save data
        Dim saveData As String = "H:\ICT Level 2\Unit 12\Bonus\Bonus\Bonus.txt"


        sales = Val(txtAmount.Text) 'convert text to numeric value
        salesPersonName = txtName.Text 'Assign name of sales person to variable

        'Award £500 if sales exceed £1500
        If sales > 1500 Then
            MsgBox("Bonus earned by: " & UCase(salesPersonName & " is £500"))
            'Award £300 if sales is between £700 and £1500
        ElseIf sales >= 700 And sales <= 1500 Then
            MsgBox("Bonus earned by: " & UCase(salesPersonName & " is £300"))
            'Award £100 if sales is between £400 and less than £700
        ElseIf sales >= 400 And sales < 700 Then
            MsgBox("Bonus earned by: " & UCase(salesPersonName & " is £100"))
        Else
            'NO bonus awarded if sales is than £400
            MsgBox("Bonus earned by: " & UCase(salesPersonName & " is £0"))
        End If

        'Check file exists
        If System.IO.File.Exists(saveData) = True Then

            Dim objWriter As New System.IO.StreamWriter(saveData, True)
            'Save sales person's name and slaes
            objWriter.Write(vbNewLine & salesPersonName & "  " & sales)
            objWriter.Close()
            MsgBox(" Data SAved")

            'Display error message if file is not saved
        Else
            MsgBox("Error! File not saved")
        End If


    End Sub



    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clear texboxes
        txtAmount.Clear()
        txtName.Clear()
    End Sub
End Class
